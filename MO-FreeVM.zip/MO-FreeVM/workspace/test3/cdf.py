import matplotlib.pyplot as plt
import csv
with open('D:\\Program Files\\workspace\\test4\\fp.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    fres1 = column[1:]
    fcpu = []
    for i in range(0, len(fres1)):
        fcpu.append(float(fres1[i]))
with open('D:\\Program Files\\workspace\\test4\\fp.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[2] for row in reader]
    fres2 = column[1:]
    fmem = []
    for i in range(0, len(fres2)):
        fmem.append(float(fres2[i]))

with open('D:\\Program Files\\workspace\\test4\\fp.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    fonPM = column1[1:]
    # print onPM
    fon_pm = []
    for i in range(0, len(fonPM)):
        fon_pm.append(int(fonPM[i]))

with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    kres1 = column[1:]
    kcpu = []
    for i in range(0, len(kres1)):
        kcpu.append(float(kres1[i]))
with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[2] for row in reader]
    kres2 = column[1:]
    kmem = []
    for i in range(0, len(kres2)):
        kmem.append(float(kres2[i]))

with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    konPM = column1[1:]
    # print onPM
    kon_pm = []
    for i in range(0, len(konPM)):
        kon_pm.append(int(konPM[i]))

with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    vres1 = column[1:]
    vcpu = []
    for i in range(0, len(vres1)):
        vcpu.append(float(vres1[i]))
with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[2] for row in reader]
    vres2 = column[1:]
    vmem = []
    for i in range(0, len(vres2)):
        vmem.append(float(vres2[i]))

with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    vonPM = column1[1:]
    # print onPM
    von_pm = []
    for i in range(0, len(vonPM)):
        von_pm.append(int(vonPM[i]))



X=fon_pm
Y1=fcpu
# Y1.sort()
Y2=fmem
# Y2.sort()
cc=[]
for i in range(0,len(Y1)):
    cc.append((Y1[i]-Y2[i]))
print(cc)

X11=kon_pm
Y11=kcpu
# Y1.sort()
Y12=kmem
# Y2.sort()
bb=[]
for i in range(0,len(Y11)):
    bb.append((Y11[i]-Y12[i]))
print(bb)

X111=von_pm
Y111=vcpu
# Y1.sort()
Y112=vmem
# Y2.sort()
aa=[]
for i in range(0,len(Y111)):
    aa.append((Y111[i]-Y112[i]))
print(aa)
plt.scatter(X,cc,color='blue',linewidths=1.0,marker='+',s=150,label = '$greedy$',linewidth=5.0)
plt.scatter(X11,bb,color='green',marker='^',alpha=0.4,s=150,label = '$kubernetes$')
plt.scatter(X111,aa,color='',marker='o',linewidths=1.0,s=150,edgecolors='red',label = '$vns$')
# plt.scatter(X, Y2, c='green')



plt.xticks(fontsize=30)
plt.yticks(fontsize=30)
plt.xlabel('The ID of the opened PM',fontsize=30)
plt.ylabel('The difference between CPU \n and memory utilization(%)',fontsize=30)
plt.legend(fontsize=30)
plt.show()
