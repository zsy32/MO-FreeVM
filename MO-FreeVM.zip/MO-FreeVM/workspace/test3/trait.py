# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import random
import copy
import csv
from sqlalchemy import create_engine
import re
class Resourceprovider:

    def trait1(self,sample_count):
        sample=[]
        sample_choosed={}
        test_rate={}
        simulate_count=10000
        dic = {'A': 0.5, 'a': 0.5}

        for key,values  in dic.items():

            for i in range (int(values*sample_count)):
                sample.append(key)
            sample_choosed[key]=0
            test_rate[key]=0.0
        random.shuffle(sample)

        for i in range(simulate_count):
            key=int(random.random()*sample_count)
            try:
                sample_choosed[sample[key]] += 1
            except:
                continue
        for (key,count) in sample_choosed.items():
            test_rate[key]=count/float(simulate_count)
        return sample

    def trait2(self,sample_count):
        sample=[]
        sample_choosed={}
        test_rate={}
        simulate_count=10000
        dic = {'B': 0.5, 'b': 0.5}

        for key,values  in dic.items():

            for i in range (int(values*sample_count)):
                sample.append(key)
            sample_choosed[key]=0
            test_rate[key]=0.0
        random.shuffle(sample)

        for i in range(simulate_count):
            key=int(random.random()*sample_count)
            try:
                sample_choosed[sample[key]] += 1
            except:
                continue

        for (key,count) in sample_choosed.items():
            test_rate[key]=count/float(simulate_count)
        return sample

    def resourceSpecification(self,sample_count):
        sample=[]
        sample_choosed={}
        test_rate={}
        simulate_count=10000
        dic = {'(32,128)': 0.1,
                '(64,128)': 0.4,
                '(64,256)': 0.3,
                '(128,256)': 0.2
                }

        for key,values  in dic.items():
            for i in range (int(values*sample_count)):
                sample.append(key)
            sample_choosed[key]=0
            test_rate[key]=0.0
        random.shuffle(sample)
        for i in range(simulate_count):
            key=int(random.random()*sample_count)
            try:
                sample_choosed[sample[key]] += 1
            except:
                continue

        for (key,count) in sample_choosed.items():
            test_rate[key]=count/float(simulate_count)
        return sample

    def rpstate(self):
        RPstate = ['On', 'Off']
        RP_state = np.random.choice(RPstate, sample_count, p=[0.3, 0.7])
        return RP_state

    def resource(self):
        resourceSpecilist=self.resourceSpecification(sample_count)
        resourceSpeci= []
        for res in range(len(resourceSpecilist)):
            resourceSpeci.append(resourceSpecilist[res].strip('()').split(','))
        resource1=[]
        resource2=[]
        for res in range(len(resourceSpeci)):
            resource1.append(int(resourceSpeci[res][0]))
            resource2.append(int(resourceSpeci[res][1]))
        return [resourceSpecilist, resource1, resource2]

if __name__ == '__main__':
    sample_count = 100
    c = Resourceprovider()
    Trait1 = c.trait1(sample_count)
    Trait2 = c.trait2(sample_count)
    rp_statelist=c.rpstate()
    Resource = c.resource()
    ResourceSpecification = Resource[0]
    # print (ResourceSpecification)
    resource1 = Resource[1]
    # print(resource1)
    resource2 = Resource[2]
    # print(resource2)
    VMinPM = [[] for i in range(100)]
    # print("VMinPM",VMinPM)
    print("************8")

    data = pd.DataFrame({
        "id": np.arange(100),
        "trait1": Trait1,
        "trait2": Trait2,
        "rp_state":rp_statelist,
        "vminPM": VMinPM,
        "resourceSpecification": ResourceSpecification,
        "resource1": resource1,
        "resource2": resource2,
    })
    print (data)
    data.to_csv("resourceprovider3.csv")
