# -*- coding: utf-8 -*-


import matplotlib.pyplot as plt
#储存温度和日期
datas = {
         '1' : [2838,2785,2731,2753,2756,2758,2760],
         '3': [3003, 2979, 2927, 2903, 2893, 2880, 2885],
         '4' : [3245,3227,3249,3225,3207,3190,3194],
         '5' : [3397,3383,3370,3355,3345,3340,3334],
         '2' : ['100','200','300','400','500','600','700']
         }
#绘制出图形，大小是 (15,15)
plt.figure(figsize = (10,10))
#绘制出图形    x轴     y轴
ln1,=plt.plot(datas['2'],datas['1'],color='red',linewidth=2.0,linestyle='--')
ln3,=plt.plot(datas['2'],datas['4'],color='green',linewidth=3.0,linestyle='-')
ln2,=plt.plot(datas['2'],datas['3'],color='blue',linewidth=3.0,linestyle='-.')
# ln3,=plt.plot(datas['2'],datas['4'],color='green',linewidth=3.0,linestyle='-')
ln4,=plt.plot(datas['2'],datas['5'],color='black',linewidth=3.0,linestyle=':')
# plt.legend()  # 让图例生效
plt.legend(handles=[ln1, ln3,ln2,ln4], labels=["MO_STVNS", "GWO","SA","GA"],loc=2, prop={'size': 20})
#设置x和y轴的文字颜色
plt.xticks(size = 20,color = 'black')
plt.yticks(size = 20,color = 'black')
#设置x轴和y轴的标签
plt.xlabel('Cycle',size = 20,color = 'black')
plt.ylabel('TSF',size = 20,color = 'black')
#设置标题
# plt.title('Future Weather Chart Temperature Trend',size = 20,color = 'black')
#使用风格 bmh
plt.style.use('bmh')
#绘制出统计图
plt.savefig('D:\\TOSC\\vmplacement_time\\running_time\\TSF_ali.pdf')
plt.show()