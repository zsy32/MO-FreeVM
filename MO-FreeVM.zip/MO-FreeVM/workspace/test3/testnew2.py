#! /usr/bin/env python
# -*- coding: utf-8 -*-
import Data_pb2
import pandas as pd
import numpy as np
import random

from sqlalchemy import create_engine
import re
import predict

PM=100
COLD_SET_SIZE = 200
HOT_SET_SIZE = 500
RCOST_COEFFICIENT = 1
MCOST_COEFFICIENT = 1
BCOST_COEFFICIENT = 1
RP_CHARGE = 320  # charge for per onRP
HOT_CPU_TS = 0.9  # lower bound of cpu utilization of coldRP list
COLD_CPU_TS = 0.8  # upper bound of cpu utilization of coldRP list
BALANCE_RATIO = 1.0 # r1:r2 that considered to be balance
DISTANCE = 0.25  # abs((real_ratio - BALANCE_RATIO)/BALANCE_RATIO) distance
TRAIT1 = ['A', 'a']
TRAIT2 = ['B', 'b']
WINDOW = 2000
PRIOR_STEP = 10# prior_step
THRESH = 0.2 #thresh
ALPHA = [0.8]*8  #alpha
FIX_ALPHA = 0.8

class Allocation:

    @classmethod
    # 获得运行的RP的状况,获取所有打开的运行中的RPs
    def getRunningResourceProviders(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        try:
            rpStateList = df['rp_state']
            rpStateList_dict=rpStateList.to_dict()
            onrplist = filter(lambda k: rpStateList_dict[k] == 'On', rpStateList_dict)
            return onrplist
        except Exception as err:
            print(err)


    def turnOffResourceProviderList(self,rplist):
        try:
            #   将需要关闭的rplist包装到请求，然后发送到页面resource/halt
            #   执行关机操作
            engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
            # 查询语句，选出employee表中的所有数据
            sql = ''' select * from resourceprovider; '''
            # read_sql_query的两个参数: sql语句， 数据库连接
            df = pd.read_sql_query(sql, engine)
            rpStateList = df['rp_state']
            rpStateList_dict0 = rpStateList.to_dict()
            rp_Statevalue=rpStateList_dict0.values()
            print(rpStateList_dict0)

            resSpeciList = df['resourceSpecification']
            resSpeciList_dict = resSpeciList.to_dict()
            resSpeciListvalue = resSpeciList_dict.values()

            resource1List = df['resource1']
            resource1List_dict = resource1List.to_dict()
            resource1Listvalue = resource1List_dict.values()

            resource2List = df['resource2']
            resource2List_dict = resource2List.to_dict()
            resource2Listvalue = resource2List_dict.values()

            resourcereqlist = []
            # resource1 = []
            # resource2 = []
            # vmonDit = {}
            for res in range(len(resSpeciListvalue)):
                resourcereqlist.append(resSpeciListvalue[res].strip('()').split(','))
            # for res in range(len(resourcereqlist)):
            #     resource1.append(resourcereqlist[res][0])
            #     resource2.append(resourcereqlist[res][1])
            onrplist=filter(lambda k:rpStateList_dict0[k]=='On', rpStateList_dict0)
            print(onrplist)
            for rp in rplist:
                rp_Statevalue[rp]='Off'
                resource1Listvalue[rp]=float(resourcereqlist[rp][0])
                resource2Listvalue[rp] =float(resourcereqlist[rp][1])
            print(rpStateList_dict0)
            # aa = ['null'] * PM
            # for key, value in rpStateList_dict0.items():
            #     aa[key] = value
            # print("aa", aa)
            df.iloc[:, 5] = rp_Statevalue
            df.iloc[:, 2] = resource1Listvalue
            df.iloc[:, 3] = resource2Listvalue
            df.to_sql('resourceprovider', engine, if_exists='replace', index=False)
        except Exception as err:
            print(err)

    def turnOnResourceProviderList(self, rplist):
        try:
            #   将需要关闭的rplist包装到请求，然后发送到页面resource/halt
            #   执行关机操作
            engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
            # 查询语句，选出employee表中的所有数据
            sql = ''' select * from resourceprovider; '''
            # read_sql_query的两个参数: sql语句， 数据库连接
            df = pd.read_sql_query(sql, engine)
            rpStateList = df['rp_state']
            rpStateList_dict0 = rpStateList.to_dict()
            rp_Statevalue=rpStateList_dict0.values()
            print(rpStateList_dict0)

            resSpeciList = df['resourceSpecification']
            resSpeciList_dict = resSpeciList.to_dict()
            resSpeciListvalue = resSpeciList_dict.values()

            resource1List = df['resource1']
            resource1List_dict = resource1List.to_dict()
            resource1Listvalue = resource1List_dict.values()

            resource2List = df['resource2']
            resource2List_dict = resource2List.to_dict()
            resource2Listvalue = resource2List_dict.values()

            resourcereqlist = []
            # resource1 = []
            # resource2 = []
            # vmonDit = {}
            for res in range(len(resSpeciListvalue)):
                resourcereqlist.append(resSpeciListvalue[res].strip('()').split(','))
            # for res in range(len(resourcereqlist)):
            #     resource1.append(resourcereqlist[res][0])
            #     resource2.append(resourcereqlist[res][1])
            onrplist=filter(lambda k:rpStateList_dict0[k]=='On', rpStateList_dict0)
            print(onrplist)
            for rp in rplist:
                rp_Statevalue[rp]='Off'
                resource1Listvalue[rp]=float(resourcereqlist[rp][0])
                resource2Listvalue[rp] =float(resourcereqlist[rp][1])
            print(rpStateList_dict0)
            df.iloc[:, 5] = rp_Statevalue
            df.iloc[:, 2] = resource1Listvalue
            df.iloc[:, 3] = resource2Listvalue
            df.to_sql('resourceprovider', engine, if_exists='replace', index=False)
        except Exception as err:
            print(err)

    # 获得RP规格CUP:MEM配比   1:1；
    def getResourceSpecfication(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourceprovider; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        try:
            resSpecList = df['resourceSpecification']
            resSpecList_dict = resSpecList.to_dict()
            resSpecList_values = resSpecList_dict.values()
            num_list_new = [str(x) for x in resSpecList_values]
            resSpecListProto = Data_pb2.ResourceSpecificationListProto()
            resSpec_list= resSpecListProto.resourcespecificationProto.add()
            resSpec_list.resourcespecification.extend(num_list_new )
            aa = resSpecListProto.SerializeToString()
            resSpecListProto.ParseFromString(aa)
            return resSpecListProto
        except Exception as err:
            print(err)

        # 获得request规格，request的大小
    def getRequestSpecfication(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourcerequest; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        try:
            reqSpecList = df['requestSpecification']
            reqSpecList_dict = reqSpecList.to_dict()
            reqSpecList_values = reqSpecList_dict.values()
            num_list_new = [str(x) for x in reqSpecList_values]
            reqSpecListProto = Data_pb2.RequestSpecificationListProto()
            reqSpec_list = reqSpecListProto.requestspecificationProto.add()
            reqSpec_list.requestspecification.extend(num_list_new)
            aa = reqSpecListProto.SerializeToString()
            reqSpecListProto.ParseFromString(aa)
            return reqSpecListProto
        except Exception as err:
            print(err)

    def getvmLists(self, on_rp):

        vmListDit = {}
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourceprovider; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        vminPMList = df['vminPM']
        vminPMList_dict = vminPMList.to_dict()
        vminPMList_dictvalues = vminPMList_dict.values()
        for rp in on_rp:
            vmListDit[rp] = [vminPMList_dictvalues[rp]]
        return vmListDit

        # 每台PM的VM放置情况
    def getVMinPM(self,PM):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourceprovider; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        try:
            vmList = df['vminPM']
            vmList_dict = vmList.to_dict()
            newList=[]
            for pm in range(len(PM)):
                newList.append(int(vmList_dict.get(PM[pm])))
            # num_list_new = [str(x) for x in newList]
            # rpListProto = Data_pb2.ResourceProviderListProto()
            # rpList = rpListProto.resourceProviderProto.add()
            # rpList.vmlist.extend(num_list_new)
            # aa = rpListProto.SerializeToString()
            # rpListProto.ParseFromString(aa)
            return newList
        except Exception as e:
            print(e)

    # 发送放置一次调度后的结果  request请求分配
    def sendAllocation(self, rrList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourceprovider; '''
        # sql_res = ''' select * from resourcerequest; '''
        # # read_sql_query的两个参数: sql语句， 数据库连接
        # df_res = pd.read_sql_query(sql_res, engine)
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        return df

        # try:
        #     url = self.baseURL + self.urlMap["sendAllocation"]
        #     #rrList是上面定义的吗？
        #     #将放置信息rrList包装到请求，发送到页面request/allocate
        #     # 发送当前的分配决策
        #     req = urllib.request.Request(url, rrList.SerializeToString(),
        #                                  {'Content-Type': 'application/x-protobuf'})
        #     req.get_method = lambda: "PUT"
        #     urllib.request.urlopen(req)
        # except Exception as e:
        #     print(e)

       #找到Resource规范，返回用户id（大户或散户）和请求的资源类型
    def findResourceSpecification(self, resSpecification, resourceSpecificationList):
        resSPecilist=resourceSpecificationList.SerializeToString()
        resSPeciList= [str(s) for s in re.findall(r'[(](.*?)[)]', resSPecilist)]
        for s in range(len(resSPeciList)):
            if resSPeciList[s]==resSpecification:
                resource=resSPeciList[s].split(',')
                return resource

   #和上面的一样？
    def findRequestSpecification(self, reqSpecification, requestSpecificationList):
        reqSPecilist = requestSpecificationList.SerializeToString()
        reqSPeciList = [str(s) for s in re.findall(r'[(](.*?)[)]', reqSPecilist)]
        # print(reqSPeciList)
        for s in range(len(reqSPeciList)):
            if reqSPeciList[s] == reqSpecification:
                request = reqSPeciList[s].split(',')
                return request


    def updateByTrait(self, res, trait1, trait2, r1, r2):

        if trait1 == TRAIT1[0] and trait2 == TRAIT2[0]:  # AB
            res[0][0] += r1
            res[0][1] += r2
        elif trait1 == TRAIT1[0] and trait2 == TRAIT2[1]:  # Ab
            res[1][0] += r1
            res[1][1] += r2
        elif trait1 == TRAIT1[1] and trait2 == TRAIT2[0]:  # aB
            res[2][0] += r1
            res[2][1] += r2
        elif trait1 == TRAIT1[1] and trait2 == TRAIT2[1]:  # ab
            res[3][0] += r1
            res[3][1] += r2

    def resource1(self):#vmlist
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourceprovider; '''
        sql_req = ''' select * from resourcerequest; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        df_req=pd.read_sql_query(sql_req, engine)
        vminPMList = df['vminPM']
        vminPMList_dict =  vminPMList.to_dict()
        vminPMList_values=vminPMList_dict.values()
        reqSpecifiList=df_req['requestSpecification']
        reqSpecifiList_dict=reqSpecifiList.to_dict()
        index=[]
        vmlist=[]
        resou=[]
        key=[]
        for i in range(PM):
            key.append(i)
        resource1=[0]*PM
        for i in range(len(vminPMList_values)):
            if vminPMList_values[i]!=None:
                index.append(i)
                vmlist.append(vminPMList_values[i].strip("[]").split(' '))
        for j in range(len(vmlist)):
            for vm in range(len(vmlist[j])):
                resou.append(map(int,reqSpecifiList_dict.get(int(vmlist[j][vm])).split(':')))
        A = np.array(resou)
        Resource1=A[:, 0]
        for res in range(len(resource1)):
            for i in range(len(index)):
                if res==index[i]:
                    resource1[res]=Resource1[i]
        resource1_dict= dict(zip(key, resource1))
        return resource1_dict

    def resource2(self):#vmlist
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourceprovider; '''
        sql_req = ''' select * from resourcerequest; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        df_req=pd.read_sql_query(sql_req, engine)
        vminPMList = df['vminPM']
        vminPMList_dict =  vminPMList.to_dict()
        vminPMList_values=vminPMList_dict.values()
        reqSpecifiList=df_req['requestSpecification']
        reqSpecifiList_dict=reqSpecifiList.to_dict()
        index=[]
        vmlist=[]
        resou=[]
        key=[]
        for i in range(PM):
            key.append(i)
        resource2=[0]*PM
        for i in range(len(vminPMList_values)):
            if vminPMList_values[i]!=None:
                index.append(i)
                vmlist.append(vminPMList_values[i].strip("[]").split(' '))
        for j in range(len(vmlist)):
            for vm in range(len(vmlist[j])):
                resou.append(map(int,reqSpecifiList_dict.get(int(vmlist[j][vm])).split(':')))
        A = np.array(resou)
        Resource2=A[:,1]
        for res in range(len(resource2)):
            for i in range(len(index)):
                if res==index[i]:
                    resource2[res]=Resource2[i]
        resource2_dict= dict(zip(key, resource2))
        return resource2_dict


    def TotalResUsed(self, on_rp, resourceSpecificationList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        resSpeciList = df['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        values=resSpeciList_dict.values()
        resTrait1list=df['trait1']
        resTrait1list_dict=resTrait1list.to_dict()
        resTrait2list = df['trait2']
        resTrait2list_dict = resTrait2list.to_dict()
        resource1list=df['resource1']
        resource1list_dict = resource1list.to_dict()
        resource2list = df['resource2']
        resource2list_dict = resource2list.to_dict()
        res = [[0, 0], [0, 0], [0, 0], [0, 0]]  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
        for i in range(len(on_rp)):
            resSpecifi=resSpeciList_dict.get(on_rp[i])
            resourceSpecification=re.findall(r'[(](.*?)[)]', resSpecifi)
            resource = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
            resource1_t = resource[0]
            resource2_t = resource[1]
            resource1=resource1list_dict.get(on_rp[i])
            resource2 = resource2list_dict.get(on_rp[i])
            resTrait1 = resTrait1list_dict.get(on_rp[i])
            resTrait2 = resTrait2list_dict.get(on_rp[i])
            self.updateByTrait(res, resTrait1, resTrait2, float(resource1_t)-float(resource1), float(resource2_t)-float(resource2))
        return res

    def TotalResRem(self, on_rp, resourceSpecificationList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        resSpeciList = df['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        values = resSpeciList_dict.values()
        resTrait1list = df['trait1']
        resTrait1list_dict = resTrait1list.to_dict()
        resTrait2list = df['trait2']
        resTrait2list_dict = resTrait2list.to_dict()
        resource1list = df['resource1']
        resource1list_dict = resource1list.to_dict()
        resource2list = df['resource2']
        resource2list_dict = resource2list.to_dict()
        res = [[0, 0], [0, 0], [0, 0], [0, 0]]  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
        for i in range(len(on_rp)):
            resSpecifi=resSpeciList_dict.get(on_rp[i])
            resourceSpecification=re.findall(r'[(](.*?)[)]', resSpecifi)
            resource = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
            resource1_t = resource[0]
            resource2_t = resource[1]
            resource1=resource1list_dict.get(on_rp[i])
            resource2 = resource2list_dict.get(on_rp[i])
            resTrait1 = resTrait1list_dict.get(on_rp[i])
            resTrait2 = resTrait2list_dict.get(on_rp[i])
            self.updateByTrait(res, resTrait1, resTrait2, float(resource1), float(resource2))
        return res

    # 获得任务（未分配的resourcerequest）  获取页面request/generate返回的任务列表rrList
        #  获取每一轮的任务
    def getMission(self,k):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourcerequest; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        try:
            reqList = df['id']
            reqList_dict = reqList.to_dict()
            rr=[]
            for i in range(20):
                rr.append(reqList_dict.get(k+i))
            rr_list_new = [str(x) for x in rr]
            rrListProto = Data_pb2.ResourceRequestListProto()
            rr_list = rrListProto.resourceRequestProto.add()
            rr_list.id.extend(rr_list_new)
            aa = rrListProto.SerializeToString()
            rrListProto.ParseFromString(aa)
            return rrListProto
        except Exception as e:
            print(e)

#获得useIP,大用户
    def getVIPIds(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourcerequest; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        try:
            uerIdList = df['userId']
            uerIdList_dict = uerIdList.to_dict()
            VIPIdList = filter(lambda k:  uerIdList_dict[k] == 'VIPId',  uerIdList_dict)
            VIPIdList_new = [str(x) for x in VIPIdList]
            VIPIdListProto = Data_pb2.UserIdsProto()
            VIPId_list = VIPIdListProto.userIdsProto.extend(VIPIdList_new)
            aa = VIPIdListProto.SerializeToString()
            VIPIdListProto.ParseFromString(aa)
            return  VIPIdListProto
        except Exception as e:
            print(e)

    def separateRequest(self, rrList, vipIDs):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # 查询语句，选出employee表中的所有数据
        sql = ''' select * from resourcerequest; '''
        # read_sql_query的两个参数: sql语句， 数据库连接
        df = pd.read_sql_query(sql, engine)
        userIdList = df['userId']
        userIdList_dict = userIdList.to_dict()
        vipIDslist = vipIDs.SerializeToString()
        vipIDs_list = [int(s) for s in re.findall(r'\b\d+\b',vipIDslist )]
        vipidlist=[]
        vip_request=[]
        retailidlist=[]
        retail_request=[]
        for rr in range(len(rrList)):
                if rrList[rr] in vipIDs_list:
                    vip_request.append(rrList[rr])
                else:
                    retail_request.append(rrList[rr])
        return vip_request, retail_request

        # resourcerequest排序
    def sortReqs(self, rrList, requestSpecificationList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        df = pd.read_sql_query(sql, engine)
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        rrDict = {}
        rrId=[]
        for i in range(0, len(rrList)):  #rrList只是大户或散户
            reqSpecifi = reqSpeciList_dict.get(int(rrList[i]))
            requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
            # 定义的findRequestSpecification函数？
            resource = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
            rrDict[rrList[i]] = float(int(resource[0] )+ int(resource[1]))/2  # or with other way to count a sorter
        sortedReqs = sorted(rrDict.items(), key = lambda x:x[1], reverse=False)  # from small to large
        return sortedReqs

# 给RP排序  ，从最冷的机器到最热的机器
    def sortRPs(self,rpList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        resource1List = df['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1List_values = resource1List_dict.values()
        resource2List = df['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2List_values = resource2List_dict.values()
        rpDict = {}
        for i in range(0, len(rpList)):
            # rpId = rpList.resourceProviderProto[i].id       #获得rpId
            resource1 = float(resource1List_dict.get(rpList[i]))
            resource2 = float(resource2List_dict.get(rpList[i]))
            rpDict[rpList[i]] = float(resource1 + resource2)/2  # or with other way to count a sorter
        #     #按几种资源的平均占用量排序
        sortedRPs = sorted(rpDict.items(), key = lambda x:x[1], reverse=True)
        return sortedRPs


# 找到VM索引
    def findVMindex(self,VMId,rrList):
        try:
            for i in range(0, len(rrList)):
                if rrList[i] == VMId:
                    return i
        except Exception as e:
            print(e)


  #找到已分配request的指定的RPid
    def findRPindex(self,RPId,rpList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql, engine)
        idList = df_res['id']
        idList_dict = idList.to_dict()
        idListkeys = idList_dict.keys()
        # rplist = rpList.SerializeToString()
        # rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist)]
        for i in range(0, len(rpList)):
            if  rpList[i] == int(RPId[0]):     #判断条件怎么理解？
                    return i


#    获得有效的RP,满足一个VM的所有可用的RPlist？
    def getValidResourceProviders(self, resourceRequest):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res=''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        df_res = pd.read_sql_query(sql_res, engine)
        try:
             #     request,Request()?
           #将一个资源请求resourceRequest包装到请求，发送到页面resource/valid，
           #  接收返回的该请求的可用RP的列表
            reqSpeciList = df['requestSpecification']
            reqSpeciList_dict = reqSpeciList.to_dict()
            reqSpecifi = reqSpeciList_dict.get(resourceRequest)
            requestSpecification =reqSpecifi.strip('()').split(',')
            trait1list=df['trait1']
            trait1_dict=trait1list.to_dict()
            trait1value=trait1_dict.values()
            trait2list = df['trait2']
            trait2_dict = trait2list.to_dict()
            trait2value = trait2_dict.values()
            resource1List =df_res['resource1']
            resource1List_dict = resource1List.to_dict()
            resource1List_values = resource1List_dict.values()
            resource2List = df_res['resource2']
            resource2List_dict = resource2List.to_dict()
            resource2List_values = resource2List_dict.values()
            Trait1list = df_res['trait1']
            Trait1_dict = Trait1list.to_dict()
            Trait1value = Trait1_dict.values()
            Trait2list = df_res['trait2']
            Trait2_dict = Trait2list.to_dict()
            Trait2value = Trait2_dict.values()
            rp_statelist=df_res['rp_state']
            rp_statedict=rp_statelist.to_dict()
            rp_statevalue=rp_statedict.values()
            onrp=[]
            for rp in range(0,len(rp_statevalue)):
                if rp_statevalue[rp]=='On':
                    onrp.append(rp)
            vaildrplist=[]
            for rp in onrp:
                if (trait1value[resourceRequest]==Trait1value[rp]) and (trait2value[resourceRequest]==Trait2value[rp])\
                    and (int(resource1List_values[rp])>=int(requestSpecification[0])) and (int(resource2List_values[rp])>=int(requestSpecification[1])):
                    vaildrplist.append(rp)
            return vaildrplist
        except Exception as err:
            print(err)

    def getonValidResourceProviders(self, resourceRequest):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        df_res = pd.read_sql_query(sql_res, engine)
        try:
            #     request,Request()?
            # 将一个资源请求resourceRequest包装到请求，发送到页面resource/valid，
            #  接收返回的该请求的可用RP的列表
            reqSpeciList = df['requestSpecification']
            reqSpeciList_dict = reqSpeciList.to_dict()
            reqSpecifi = reqSpeciList_dict.get(resourceRequest)
            requestSpecification = reqSpecifi.strip('()').split(',')
            trait1list = df['trait1']
            trait1_dict = trait1list.to_dict()
            trait1value = trait1_dict.values()
            trait2list = df['trait2']
            trait2_dict = trait2list.to_dict()
            trait2value = trait2_dict.values()

            # df_res = df_res.fillna('null')
            resource1List = df_res['resource1']
            resource1List_dict = resource1List.to_dict()
            resource1List_values = resource1List_dict.values()
            resource2List = df_res['resource2']
            resource2List_dict = resource2List.to_dict()
            resource2List_values = resource2List_dict.values()
            Trait1list = df_res['trait1']
            Trait1_dict = Trait1list.to_dict()
            Trait1value = Trait1_dict.values()
            Trait2list = df_res['trait2']
            Trait2_dict = Trait2list.to_dict()
            Trait2value = Trait2_dict.values()
            rp_statelist = df_res['rp_state']
            rp_statedict = rp_statelist.to_dict()
            rp_statevalue = rp_statedict.values()

            offrp = []
            for rp in range(0, len(rp_statevalue)):
                if rp_statevalue[rp] == 'Off':
                    offrp.append(rp)
            # print("onrp",onrp)
            vaildrplist = []
            for rp in offrp:
                if (trait1value[resourceRequest] == Trait1value[rp]) and (
                        trait2value[resourceRequest] == Trait2value[rp]) \
                        and (int(resource1List_values[rp]) >= int(requestSpecification[0])) and (
                        int(resource2List_values[rp]) >= int(requestSpecification[1])):
                    vaildrplist.append(rp)
            return vaildrplist
        except Exception as err:
            print(err)
    # def turnon(self):
    #     Rp_ready_on = self.getOffResourceProviders()
    #     bb = Rp_ready_on.SerializeToString()
    #     rp_ready_on = [int(s) for s in re.findall(r'\b\d+\b', bb)]
    #     print("rp_ready_on",rp_ready_on)
    #     candi_on = Data_pb2.ResourceProviderListProto()
    #     candi_onlist = candi_on.SerializeToString()
    #     Candi_onlist = [int(s) for s in re.findall(r'\b\d+\b', candi_onlist)]
    #     print("Candi_onlist",Candi_onlist)
    #     for rp in rp_ready_on:
    #         Candi_onlist.append(rp)
    #         r1 = resource1Listvalues[rp]
    #         r2 = resource2Listvalues[rp]
    #         self.updateByTrait(delta_r, Trait1listvalues[rp], Trait2listvalues[rp], r1, r2)
    #         rp_ready_on.remove(rp)
    #         if (not self.ifAnySmallerThan0(delta_r)) or (not rp_ready_on):
    #             break
    #     print("rp_ready_on", rp_ready_on)
    #     print("Candi_onlist", Candi_onlist)
    #     self.turnOnResourceProviderList(Candi_onlist)
    def PrioritizePms(self,rpList):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        resSpeciList = df['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        total_resourcelist = []
        total_resource1 = []
        total_resource2 = []
        for res in range(len(resSpeciListvalue)):
            total_resourcelist.append(resSpeciListvalue[res].strip('()').split(','))
        for r in range(len(total_resourcelist)):
            total_resource1.append(total_resourcelist[r][0])
            total_resource2.append(total_resourcelist[r][1])
        resource1List = df['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1List_values = resource1List_dict.values()
        resource2List = df['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2List_values = resource2List_dict.values()
        rpDict = {}
        for i in range(0, len(rpList)):
            # rpId = rpList.resourceProviderProto[i].id       #获得rpId
            resource1 = float(resource1List_values[rpList[i]])
            resource2 = float(resource2List_values[rpList[i]])
            totalresource1=float(total_resource1[rpList[i]])
            totalresource2 = float(total_resource2[rpList[i]])
            #most_requested
            rpDict[rpList[i]]=(float((totalresource1-resource1)/totalresource1)*10+float((totalresource2-resource2)/totalresource2)*10)*0.5
            #balanced_resource_allocation
            # rpDict[rpList[i]]={1-abs[float((totalresource1-resource1)/totalresource1)-float((totalresource2-resource2)/totalresource2)]}*10
            # rpDict[rpList[i]] = float(resource1 + resource2)/2  # or with other way to count a sorter
        #     #按几种资源的平均占用量排序
        sortedRPs = sorted(rpDict.items(), key = lambda x:x[1], reverse=False)
        return sortedRPs

    def kubernates(self, rrList, rpList, requestSpecificationList, vmListDit):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        df_res = pd.read_sql_query(sql_res, engine)
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        reqSpeciListvalue = reqSpeciList_dict.values()
        resourcereqlist = []
        resource1 = []
        resource2 = []
        for req in range(len(reqSpeciListvalue)):
            resourcereqlist.append(reqSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resourcereqlist)):
            resource1.append(resourcereqlist[res][0])
            resource2.append(resourcereqlist[res][1])
        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()

        rp_stateList = df_res['rp_state']
        rp_stateList_dict = rp_stateList.to_dict()
        rp_stateListvalues = rp_stateList_dict.values()

        vminPMList = df_res['vminPM']
        vminPMList_dict = vminPMList.to_dict()
        vminPMListvalues = vminPMList_dict.values()

        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        vipIDs = self.getVIPIds()
        # print("vipIDs",vipIDs)
        vip_request, retail_request = self.separateRequest(rrList, vipIDs)
        # print(" vip_request, retail_request", vip_request, retail_request)
        sorted_retail_request = self.sortReqs(retail_request, requestSpecificationList)  # [('ip', sorter),(),(),...]
        # print(" sorted_retail_request", sorted_retail_request)
        sorted_vip_request = self.sortReqs(vip_request, requestSpecificationList)
        # print("sorted_vip_request",sorted_vip_request)
        sorted_request = sorted_vip_request + sorted_retail_request
        # print("sorted_request",sorted_request)
        for i in range(0,len(sorted_request)):#len(sorted_request)
            r_id = sorted_request[i][0]
            r_i = self.findVMindex(r_id, rrList)  # request index in rrList
            print("rrList[r_i]",rrList[r_i])
            valid_rps = self.getValidResourceProviders(rrList[r_i])
            sorted_rps=self.PrioritizePms(valid_rps)
            print("sorted_rps",sorted_rps)
            candi_rp_id = sorted_rps[len(sorted_rps) - 1]  # place on hotter rpcandi_rp_id = sorted_rps[len(sorted_rps) - 1]  # place on hotter rp
            candi_rp_idlist = list(candi_rp_id)
            print("candi_rp_idlist", candi_rp_idlist)
            candi_rp_i = self.findRPindex(candi_rp_id, rpList)  # candi rp index in rpList
            print("candi_rp_i", candi_rp_i)
            aa = ['null'] * PM
            # if candi_rp_i!=None:
            # update
            r1 = float(resource1[rrList[r_i]])
            r2 = float(resource2[rrList[r_i]])
            if (resource1Listvalues[int(rpList[int(candi_rp_i)])] >= float(r1)) and (
                resource2Listvalues[int(rpList[int(candi_rp_i)])] >= float(r2)):
                rpIdListvalues[rrList[r_i]] = float(candi_rp_idlist[0])
                vmListDit[candi_rp_id[0]].append(rrList[r_i])
                resource1Listvalues[int(rpList[candi_rp_i])] -= float(r1)
                resource2Listvalues[int(rpList[candi_rp_i])] -= float(r2)
        #
                for key, value in vmListDit.items():
                    value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
                    aa[key] = str(value)
                    print("aa", aa)
                df_res.iloc[:, 2] = resource1Listvalues
                df_res.iloc[:, 3] = resource2Listvalues
                        # df_res.iloc[:, 5] = rp_stateListvalues

                df_res.iloc[:, 8] = aa
                df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
                df.iloc[:, 4] = rpIdListvalues
                df.to_sql('resourcerequest', engine, if_exists='replace', index=False)


    def firstPlacement(self,rrList, rpList, requestSpecificationList, vmListDit):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        df_res = pd.read_sql_query(sql_res, engine)
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        reqSpeciListvalue = reqSpeciList_dict.values()
        resourcereqlist = []
        resource1 = []
        resource2 = []
        vmonDit = {}
        for req in range(len(reqSpeciListvalue)):
            resourcereqlist.append(reqSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resourcereqlist)):
            resource1.append(resourcereqlist[res][0])
            resource2.append(resourcereqlist[res][1])
        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()

        rp_stateList = df_res['rp_state']
        rp_stateList_dict = rp_stateList.to_dict()
        rp_stateListvalues = rp_stateList_dict.values()

        vminPMList = df_res['vminPM']
        vminPMList_dict = vminPMList.to_dict()
        vminPMListvalues = vminPMList_dict.values()

        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        vipIDs = self.getVIPIds()
        # print("vipIDs",vipIDs)
        vip_request, retail_request = self.separateRequest(rrList, vipIDs)
        # print(" vip_request, retail_request", vip_request, retail_request)
        sorted_retail_request = self.sortReqs(retail_request, requestSpecificationList)  # [('ip', sorter),(),(),...]
        # print(" sorted_retail_request", sorted_retail_request)
        sorted_vip_request = self.sortReqs(vip_request, requestSpecificationList)
        # print("sorted_vip_request",sorted_vip_request)
        sorted_request = sorted_vip_request + sorted_retail_request
        # print("sorted_request",sorted_request)
        for i in range(0,len(sorted_request)):#len(sorted_request)
            r_id = sorted_request[i][0]
            r_i = self.findVMindex(r_id, rrList)  # request index in rrList
            print("rrList[r_i]",rrList[r_i])
            valid_rps = self.getValidResourceProviders(rrList[r_i])
            print("valid_rps",valid_rps)
            if (len(valid_rps)>0):
                sorted_rps = self.sortRPs(valid_rps)
                candi_rp_id = sorted_rps[len(sorted_rps) - 1]  # place on hotter rp
                candi_rp_idlist = list(candi_rp_id)
                print("candi_rp_idlist", candi_rp_idlist)
                candi_rp_i = self.findRPindex(candi_rp_id, rpList)  # candi rp index in rpList
                print("rpList",rpList)
                print("candi_rp_i", candi_rp_i)
                # if (candi_rp_i!=None):
                aa = ['null'] * PM
                # update
                r1 = float(resource1[rrList[r_i]])
                r2 = float(resource2[rrList[r_i]])
                if (resource1Listvalues[int(rpList[int(candi_rp_i)])] >= float(r1)) and (
                        resource2Listvalues[int(rpList[int(candi_rp_i)])] >= float(r2)):
                    rpIdListvalues[rrList[r_i]] = float(candi_rp_idlist[0])
                    vmListDit[candi_rp_id[0]].append(float(rrList[r_i]))

                    resource1Listvalues[int(rpList[candi_rp_i])] -= float(r1)
                    resource2Listvalues[int(rpList[candi_rp_i])] -= float(r2)
                    for key, value in vmListDit.items():
                        value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
                        aa[key] = str(value)
                    print("aa", aa)
                    df_res.iloc[:, 2] = resource1Listvalues
                    df_res.iloc[:, 3] = resource2Listvalues
                    # df_res.iloc[:, 5] = rp_stateListvalues
                    df_res.iloc[:, 8] = aa
                    df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
                    df.iloc[:, 4] = rpIdListvalues
                    df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
            else:
                print(len(valid_rps))
                print("valid_rps",valid_rps)
                valid_rps = self.getonValidResourceProviders(rrList[r_i])
                print("valid_rps",valid_rps)
                sorted_rps = self.sortRPs(valid_rps)
                candi_rp_id = sorted_rps[len(sorted_rps) - 1]  # place on hotter rp
                candi_rp_idlist = list(candi_rp_id)
                print("candi_rp_idlisttt",candi_rp_idlist)
                rp_stateListvalues[candi_rp_idlist[0]] = 'On'
                print("rp_stateListvaluesbb", rp_stateListvalues)
                candi_rp_i = self.findRPindex(candi_rp_id,rpList)  # candi rp index in rpList
                print("rplistbb",rpList)
                print("candi_rp_i",candi_rp_i)
                r1 = float(resource1[rrList[r_i]])
                r2 = float(resource2[rrList[r_i]])
                rpIdListvalues[rrList[r_i]] = float(candi_rp_idlist[0])
                vminPMListvalues[candi_rp_idlist[0]]=float(rrList[r_i])
                print("candi_rp_idlist[0]22",candi_rp_idlist[0])
                print("vminPMListvalues",vminPMListvalues)
                resource1Listvalues[candi_rp_idlist[0]] -= float(r1)
                resource2Listvalues[candi_rp_idlist[0]] -= float(r2)
                df_res.iloc[:, 2] = resource1Listvalues
                df_res.iloc[:, 3] = resource2Listvalues
                df_res.iloc[:, 5] = rp_stateListvalues
                df_res.iloc[:, 8] = vminPMListvalues
                df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
                df.iloc[:, 4] = rpIdListvalues
                df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
        #


    # 获得所有VM （request） 获取页面request/all返回的rrList,所有VMs的列表
   # 获取当前所有已经分配的虚拟机
    def getAllVirtualMachine(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        df = pd.read_sql_query(sql, engine)
        df = df.fillna('null')
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        try:
            bb= []
            for rp in range(len(rpIdListvalues)):
                if (rpIdListvalues[rp]!= 'null') and (rpIdListvalues[rp]!= 'Release'):
                    bb.append(rp)
            return bb
        except Exception as e:
            print(e)

    # 移除SRCRP?
    def removeSRCRP(self, srcrp_id, valid_rpList):
        for rp in valid_rpList:
            if rp == srcrp_id:
                valid_rpList.remove(rp)
                break

    def delta_dist(self, r1, r2, vmr_1, vmr_2):
        # if src vmr is + ,if des vmr is -
        # dist_aft - dist_bfo
        # result = ((r1+vmr_1)/(r2+vmr_2)-BALANCE_RATIO)/BALANCE_RATIO - (r1/r2-BALANCE_RATIO)/BALANCE_RATIO
        result = ((r1 + vmr_1) - BALANCE_RATIO*(r2 + vmr_2)) - (r1-BALANCE_RATIO*r2)
        return result

    # #查询到匹配的RP,找到trait相匹配的RP
    def findMatchRP(self, rpList, trait1, trait2, src_id):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        matchList = []
        # rplist =rpList.SerializeToString()
        # rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist )]
        trait1List = df_res['trait1']
        trait1List_dict = trait1List.to_dict()
        trait1Listvalues = trait1List_dict.values()

        trait2List = df_res['trait2']
        trait2List_dict = trait2List.to_dict()
        trait2Listvalues = trait2List_dict.values()
        for rp in rpList:
            if (trait1Listvalues[rp] == trait1) and (trait2Listvalues[rp]== trait2) and (rp!= int(src_id)):  #    id条件？

                matchList.append(rp)
        return matchList

    #找到最优放置
    def findBest(self, opi, rrList, rpList, vmListDit, vm_id, requestSpecificationList, resourceSpecificationList):
        if opi == 0:
            return self.findBestShift(rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList)
        elif opi == 1:
            return self.findBestSwap(rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList)
        else:
            return self.findBestReplace(rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList)

    # 最佳的Shift
    def findBestShift(self, rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList):
        # find best placement based on best_rrList,with only one shift move
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)

        idList = df_res['id']
        idList_dict = idList.to_dict()

        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        resspecifilist=[]
        res1=[]
        res2=[]

        for req in range(len(resSpeciListvalue)):
            resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resspecifilist)):
            res1.append(resspecifilist[res][0])
            res2.append(resspecifilist[res][1])
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        reqSpeciListvalue =reqSpeciList_dict.values()
        resourcereqlist = []
        resource1 = []
        resource2 = []
        for req in range(len(reqSpeciListvalue)):
            resourcereqlist.append(reqSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resourcereqlist)):
            resource1.append(resourcereqlist[res][0])
            resource2.append(resourcereqlist[res][1])
        # print("resource1", resource1 )


        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        vm_i = self.findVMindex(int(vm_id), rrList)
        # print("bshvm_i",vm_i)
        # rrlist = rrList.SerializeToString()
        # rr_list = [int(s) for s in re.findall(r'\b\d+\b', rrlist)]
        # rplist = rpList.SerializeToString()
        # rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist)]
        srcrp_id = rpIdList_dict.get(rrList[vm_i])  # [rr_list[vm_i]]
        # print("bshsrcrp_id",srcrp_id)
        # print("rpList",rpList)
        src_i = self.findRPindex([srcrp_id], rpList)  # src rp index in rand_rpList
        # print(" src_i", src_i)
        candi_vm_i = -1  # in rrList
        candi_des_i = -1
        candi_best_cost = float('inf')
        src_vmlist = vmListDit[int(srcrp_id)]
        # # print ("vmListDit",vmListDit)
        src_vmlist = [float(s) for s in re.findall(r"\d+\.?\d*", str(src_vmlist))]
        # print("src_vmlist",src_vmlist)
        # # print(type(src_vmlist))

        for i in range(0, len(src_vmlist)):
            v_id = src_vmlist[i]
            # print("v_id",v_id)
            v_i = self.findVMindex(int(v_id), rrList)
            # print("v_i",v_i)
            validRP = self.getValidResourceProviders(rrList[v_i])
            # print("validRP",validRP)
            self.removeSRCRP(idList_dict.get(rpList[src_i]), validRP)
            # print("validRP", validRP)
            sortedValidRP = self.sortRPs(validRP)  # [('ip', sorter),(),(),...]
            for j in range(len(sortedValidRP)-1, -1, -1):
                des_i = self.findRPindex(sortedValidRP[j], rpList)  # des index in rpList
                resSpecifi = resSpeciList_dict.get(int(rpList[des_i]))
                resourceSpecification = re.findall(r'[(](.*?)[)]', resSpecifi)
                des_rt = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
                ResSpecifi = resSpeciList_dict.get(int(rpList[src_i]))
                ResourceSpecification = re.findall(r'[(](.*?)[)]', ResSpecifi )
                src_rt = self.findResourceSpecification(ResourceSpecification[0], resourceSpecificationList)
                reqSpecifi =  reqSpeciList_dict.get(int(rrList[v_i]))
                requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
                vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
        #         # print("vm_r",vm_r)
                src_r1 = resource1Listvalues[rpList[src_i]]
                src_r2 = resource2Listvalues[rpList[src_i]]
                des_r1 = resource1Listvalues[rpList[des_i]]
                des_r2 = resource2Listvalues[rpList[des_i]]
        #         # print(" src_r1", src_r1)
        #         # print("src_r2",src_r2)
        #         # print("des_r1",des_r1)
        #         print("des_r2", des_r2)
                des_cpu_uti = 1 - float(des_r1+des_r2)/(float(des_rt[0])+float(des_rt[1]))
        #         # print("des_cpu_uti",des_cpu_uti)
                if des_cpu_uti > HOT_CPU_TS:
                    continue
                delta_mCost = 0.5*(int(vm_r[0] )+ int(vm_r[1]))
                src_delta_bCost=abs(float(src_r1+int(vm_r[0]))-float(src_r2+int(vm_r[1]))*BALANCE_RATIO)-abs(float(src_r1-BALANCE_RATIO*src_r2))
                des_delta_bCost=abs(float(des_r1-int(vm_r[0]))-float(des_r2-int(vm_r[1]))*BALANCE_RATIO)-abs(float(des_r1-BALANCE_RATIO*des_r2))
                delta_bCost = src_delta_bCost + des_delta_bCost
                delta_cost = MCOST_COEFFICIENT*delta_mCost + BCOST_COEFFICIENT*delta_bCost
                if delta_cost < candi_best_cost:
                    candi_vm_i = v_i
                    candi_des_i = des_i
                    candi_best_cost = delta_cost
        #         # print("candi_vm_i",candi_vm_i)
        #         # print("candi_des_i",candi_des_i)
        #         # print("candi_best_cost",candi_best_cost)
        if candi_best_cost == float('inf'):
            return 0
        else:
            # update
            # print("$$$$$$$$$$$$")
            if( float(res1[rpList[candi_des_i]])>=float(resource1Listvalues[rpList[candi_des_i]])>=float(resource1[rrList[candi_vm_i]])) and (float(res2[rpList[candi_des_i]])>=float(resource2Listvalues[rpList[candi_des_i]])>= float(resource2[rrList[candi_vm_i]])):
                rpIdListvalues[rrList[candi_vm_i]] =rpList[candi_des_i]
                resource1Listvalues[rpList[src_i]]+=float(resource1[rrList[candi_vm_i]])
                resource2Listvalues[rpList[src_i]]+=float(resource2[rrList[candi_vm_i]])
                vmListDit[rpList[src_i]] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[src_i]]))]
                while float(rrList[candi_vm_i]) in vmListDit[rpList[src_i]]: vmListDit[rpList[src_i]].remove(float(rrList[candi_vm_i]))
                resource1Listvalues[rpList[candi_des_i]]-=float(resource1[rrList[candi_vm_i]])
                resource2Listvalues[rpList[candi_des_i]] -= float(resource2[rrList[candi_vm_i]])
                vmListDit[rpList[candi_des_i]] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[candi_des_i]]))]
                while (float(rrList[candi_vm_i])) not in vmListDit[rpList[candi_des_i]]: vmListDit[rpList[candi_des_i]].append(float(rrList[candi_vm_i]))

                # vmListDit[rp_list[candi_des_i]].append(rrList[candi_vm_i])
            # print("rpIdLifloatstvalues",rpIdListvalues)
            # print(" vmListDit1", vmListDit)
            # print(" resource1Listvalues", resource1Listvalues)
            aa = ['null'] * PM
            for key, value in vmListDit.items():
                value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
                aa[key] = str(value)
            # print("aa",aa)
            df_res.iloc[:, 2] = resource1Listvalues
            df_res.iloc[:, 3] = resource2Listvalues
            df_res.iloc[:, 8] = aa
            df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
            df.iloc[:, 4] = rpIdListvalues
            df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
            return candi_best_cost

    def findBestSwap(self, rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList):

    # find best placement based on best_rrList,with only one shift move
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)

        idList = df_res['id']
        idList_dict = idList.to_dict()
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()

        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        resspecifilist = []
        res1 = []
        res2 = []

        for req in range(len(resSpeciListvalue)):
            resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resspecifilist)):
            res1.append(resspecifilist[res][0])
            res2.append(resspecifilist[res][1])

        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        reqSpeciListvalue = reqSpeciList_dict.values()

        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()



        resourcereqlist = []
        resource1 = []
        resource2 = []
        for req in range(len(reqSpeciListvalue)):
            resourcereqlist.append(reqSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resourcereqlist)):
            resource1.append(resourcereqlist[res][0])
            resource2.append(resourcereqlist[res][1])
        vm_i = self.findVMindex(int(vm_id), rrList)
        # print("bswvm_i", vm_i)

        # rplist = rpList.SerializeToString()
        # rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist)]
        srcrp_id = rpIdList_dict.get(rrList[vm_i])  # [rr_list[vm_i]]
        # print("bswsrcrp_id",srcrp_id)

        src_i = self.findRPindex([srcrp_id], rpList)  # src rp index in rand_rpList
        # print(" src_i", src_i)

        if src_i is None:
            print('none src_i')

        candi_src_vm_i = -1  # in rrList
        candi_des_i = -1
        candi_des_vm_i = -1
        candi_best_cost = float('inf')
        src_vmlist = vmListDit[int(srcrp_id)]
        src_vmlist = [float(s) for s in re.findall(r"\d+\.?\d*", str(src_vmlist))]
        # print("src_vmlist",src_vmlist)

        for i in range(0, len(src_vmlist)):
            src_v_id = src_vmlist[i]
            # print("src_v_id",src_v_id)
            src_v_i = self.findVMindex(src_v_id, rrList)
            # print("src_v_i",src_v_i)
            sortedRP = self.sortRPs(rpList)  # [('ip', sorter),(),(),...]
            # print("sortedRP",sortedRP)
            validRP = self.getValidResourceProviders(rrList[src_v_i])
            self.removeSRCRP(idList_dict.get(rpList[src_i]), validRP)
            sortedValidRP = self.sortRPs(validRP)  # [('ip', sorter),(),(),...]
            for j in range(len(sortedValidRP)-1, -1, -1):
                des_i = self.findRPindex(sortedValidRP[j], rpList)  # des index in rpList
                # print(" des_i", des_i)
                if des_i == src_i:
                    continue
                resSpecifi = resSpeciList_dict.get(int(rpList[des_i]))
                resourceSpecification = re.findall(r'[(](.*?)[)]', resSpecifi)
                des_rt = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
                # print(" des_rt", des_rt)
                ResSpecifi = resSpeciList_dict.get(int(rpList[src_i]))
                ResourceSpecification = re.findall(r'[(](.*?)[)]', ResSpecifi)
                src_rt = self.findResourceSpecification(ResourceSpecification[0], resourceSpecificationList)
                reqSpecifi = reqSpeciList_dict.get(int(rrList[src_v_i]))
                requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
                src_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
                # print("src_vm_r",src_vm_r)
                src_r1 = resource1Listvalues[rpList[src_i]]
                src_r2 = resource2Listvalues[rpList[src_i]]
                des_r1 = resource1Listvalues[rpList[des_i]]
                des_r2 = resource2Listvalues[rpList[des_i]]
        #         # print(" src_r1", src_r1)
        #         # print("src_r2",src_r2)
        #         # print("des_r1",des_r1)
                # print("des_r2", des_r2)
                des_cpu_uti = 1 - float(des_r1 + des_r2) / (float(des_rt[0]) + float(des_rt[1]))
                if des_cpu_uti < COLD_CPU_TS:
                    continue
                des_vmlist = vmListDit[int(sortedValidRP[j][0])]
                des_vmlist = [float(s) for s in re.findall(r"\d+\.?\d*", str(des_vmlist))]
                # print(" des_vmlist", des_vmlist)
                for k in range(0, len(des_vmlist)):
                    des_v_id = des_vmlist[k]
                    # print("des_v_id",des_v_id)
                    des_v_i = self.findVMindex(int(des_v_id), rrList)
                    reqSpecifi = reqSpeciList_dict.get(int(rrList[des_v_i]))
                    requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
                    des_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
        #             # print("des_vm_r",des_vm_r)
                    src_r1_try = src_r1 + int(src_vm_r[0] )- int(des_vm_r[0])
                    src_r2_try = src_r2 + int(src_vm_r[1]) - int(des_vm_r[1])
                    des_r1_try = des_r1 + int(des_vm_r[0] )- int(src_vm_r[0])
                    des_r2_try = des_r2 + int(des_vm_r[1]) - int(src_vm_r[1])
                    if src_r1_try>0 and src_r2_try>0 and des_r1_try>0 and des_r2_try>0:
                        delta_mCost = 0.5*(int(src_vm_r[0] )+ int(src_vm_r[1]) + int(des_vm_r[0]) + int(des_vm_r[1]))
        #                 # print(" delta_mCost", delta_mCost)
        #                 # src_delta_bCost = abs(float(src_r1 + src_vm_r[0]) / (src_r2 + src_vm_r[1]) - BALANCE_RATIO) - abs(float(src_r1) / src_r2 - BALANCE_RATIO)
                        src_delta_bCost=abs(float(src_r1+int(src_vm_r[0]))-float(src_r2+int(src_vm_r[1]))*BALANCE_RATIO)-abs(float(src_r1-BALANCE_RATIO*src_r2))
                        # src_delta_bCost = self.delta_dist(src_r1,src_r2,src_vm_r[0]-des_vm_r[0],src_vm_r[1]-des_vm_r[1])
                        des_delta_bCost = self.delta_dist(des_r1,des_r2,int(des_vm_r[0])-int(src_vm_r[0]),int(des_vm_r[1])-int(src_vm_r[1]))
                        delta_bCost = src_delta_bCost + des_delta_bCost
                        delta_cost = MCOST_COEFFICIENT*delta_mCost + BCOST_COEFFICIENT*delta_bCost
                        if delta_cost < candi_best_cost:
                            candi_src_vm_i = src_v_i
                            candi_des_i = des_i
                            candi_des_vm_i = des_v_i
                            candi_best_cost = delta_cost
        #                     # print("candi_best_cost",candi_best_cost)
        if candi_best_cost == float('inf'):
            return 0
        else:
            # update
            if(float(res1[rpList[candi_des_i]])>=float(resource1Listvalues[rpList[candi_des_i]])>= float(resource1[rrList[candi_src_vm_i]])) and (float(res2[rpList[candi_des_i]])>=float(resource2Listvalues[rpList[candi_des_i]])>= float(resource2[rrList[candi_src_vm_i]])):
                rpIdListvalues[rrList[candi_src_vm_i]] = rpList[candi_des_i]
                rpIdListvalues[rrList[candi_des_vm_i]] = rpList[src_i]
                resource1Listvalues[rpList[src_i]] += float(resource1[rrList[candi_src_vm_i]])
                resource2Listvalues[rpList[src_i]] +=float(resource2[rrList[candi_src_vm_i]])
                vmListDit[rpList[src_i]] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[src_i]]))]
                while float(rrList[candi_src_vm_i]) in vmListDit[rpList[src_i]]: vmListDit[rpList[src_i]].remove(float(rrList[candi_src_vm_i]))

                while float(rrList[candi_des_vm_i]) not in vmListDit[rpList[src_i]]: vmListDit[rpList[src_i]].append(float(rrList[candi_des_vm_i]))
                resource1Listvalues[rpList[candi_des_i]] -= float(resource1[rrList[candi_src_vm_i]])
                resource2Listvalues[rpList[candi_des_i]] -= float(resource2[rrList[candi_src_vm_i]])
                # vmListDit[idList_dict.get(rp_list[candi_des_i])].remove(rrList[candi_des_vm_i])
                vmListDit[rpList[candi_des_i]] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[candi_des_i]]))]
                while float(rrList[candi_des_vm_i]) in vmListDit[rpList[candi_des_i]]: vmListDit[rpList[candi_des_i]].remove(float(rrList[candi_des_vm_i]))
                while float(rrList[candi_src_vm_i]) not in vmListDit[rpList[candi_des_i]]: vmListDit[rpList[candi_des_i]].append(float(rrList[candi_src_vm_i]))
        # #     # print("resource1Listvalues", resource1Listvalues)
        #     print("rpIdListvalues",rpIdListvalues)
        #     print("vmListDit2",vmListDit)
            aa = ['null'] * PM
            for key, value in vmListDit.items():
                value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
                aa[key] = str(value)
        #     # print("aa",aa)
            df_res.iloc[:, 2] = resource1Listvalues
            df_res.iloc[:, 3] = resource2Listvalues
            df_res.iloc[:, 8] = aa
            df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
            df.iloc[:, 4] = rpIdListvalues
            df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
            return candi_best_cost

    def findBestReplace(self, rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList):
        # find best placement based on best_rrList,with only one shift move
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)

        idList = df_res['id']
        idList_dict = idList.to_dict()
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        resspecifilist = []
        res1 = []
        res2 = []

        for req in range(len(resSpeciListvalue)):
            resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resspecifilist)):
            res1.append(resspecifilist[res][0])
            res2.append(resspecifilist[res][1])

        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        reqSpeciListvalue = reqSpeciList_dict.values()

        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()

        resourcereqlist = []
        resource1 = []
        resource2 = []
        for req in range(len(reqSpeciListvalue)):
            resourcereqlist.append(reqSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resourcereqlist)):
            resource1.append(resourcereqlist[res][0])
            resource2.append(resourcereqlist[res][1])
        vm_i = self.findVMindex(int(vm_id), rrList)
        # print("brevm_i", vm_i)
        # rrlist = rrList.SerializeToString()
        # rr_list = [int(s) for s in re.findall(r'\b\d+\b', rrlist)]
        # rplist = rpList.SerializeToString()
        # rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist)]
        rp1_id= rpIdList_dict.get(rrList[vm_i])  # [rr_list[vm_i]]
        # print(" rp1_id", rp1_id)
        # print("rpList",rpList)
        rp1_i = self.findRPindex([rp1_id], rpList)  # src rp index in rand_rpList
        # print("rp1_i",rp1_i )
        candi_rp1_vm_i = -1  # in rrList
        candi_rp2_i = -1
        candi_rp2_vm_i = -1
        candi_rp3_i = -1
        candi_best_cost = float('inf')
        rp1_vmlist = vmListDit[int(rp1_id)]
        # print("rp1_vmlist",rp1_vmlist)
        rp1_vmlist = [float(s) for s in re.findall(r"\d+\.?\d*", str(rp1_vmlist))]
        # print("rp1_vmlist", rp1_vmlist)

        for i in range(0, len(rp1_vmlist)):
            rp1_v_id = rp1_vmlist[i]
            # print("rp1_v_id ",rp1_v_id )
            rp1_v_i = self.findVMindex(int(rp1_v_id), rrList)
            sortedRP2 = self.sortRPs(rpList)  # [('ip', sorter),(),(),...]
            # print(" sortedRP2", sortedRP2)
            for j in range(len(sortedRP2)-1, -1, -1):
                rp2_i = self.findRPindex(sortedRP2[j], rpList)  # des index in rpList
                # print("rp2_i", rp2_i)
                resSpecifi = resSpeciList_dict.get(int(rpList[rp2_i]))
                resourceSpecification = re.findall(r'[(](.*?)[)]', resSpecifi)
                rp2_rt = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
                ResSpecifi = resSpeciList_dict.get(int(rpList[rp1_i]))
                ResourceSpecification = re.findall(r'[(](.*?)[)]', ResSpecifi)
                rp1_rt = self.findResourceSpecification(ResourceSpecification[0], resourceSpecificationList)
                reqSpecifi = reqSpeciList_dict.get(int(rrList[rp1_v_i]))
                requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
                rp1_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
                rp1_r1 = resource1Listvalues[rpList[rp1_i]]
                rp1_r2 = resource2Listvalues[rpList[rp1_i]]
                rp2_r1 = resource1Listvalues[rpList[rp2_i]]
                rp2_r2 = resource2Listvalues[rpList[rp2_i]]
                rp2_cpu_uti = 1 - float(rp2_r1+rp2_r2)/(float(rp2_rt[0])+float(rp2_rt[1]))
                # print("rp2_cpu_uti",rp2_cpu_uti)
                if rp2_cpu_uti < COLD_CPU_TS:
                    continue
                rp2_vmlist = vmListDit[int(sortedRP2[j][0])]
                rp2_vmlist = [float(s) for s in re.findall(r"\d+\.?\d*", str(rp2_vmlist))]
                # print("vmListDit",vmListDit)
                for k in range(0, len(rp2_vmlist)):
                    rp2_v_id = rp2_vmlist[k]
                    # print("rp2_v_id",rp2_v_id)
                    rp2_v_i = self.findVMindex(int(rp2_v_id), rrList)
                    # print(" rp2_v_i", rp2_v_i)
                    reqSpecifi = reqSpeciList_dict.get(int(rrList[rp2_v_i]))
                    requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
                    rp2_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
                    validRP3= self.getValidResourceProviders(rrList[rp2_v_i])
                    # print("validRP3",validRP3)
                    self.removeSRCRP(idList_dict.get(rpList[int(rp1_i)]), validRP3)
                    # print("validRP3", validRP3)
                    self.removeSRCRP(idList_dict.get(rpList[int(rp2_i)]), validRP3)
                    # print("validRP3", validRP3)
                    sortedValidRP3 = self.sortRPs(validRP3)  # [('ip', sorter),(),(),...]
                    # print("sortedValidRP3",sortedValidRP3)
                    for l in range(0, len(sortedValidRP3)):
                        rp3_i = self.findRPindex(sortedValidRP3[l], rpList)
                        resSpecifi = resSpeciList_dict.get(int(rpList[rp3_i]))
                        resourceSpecification = re.findall(r'[(](.*?)[)]', resSpecifi)
                        rp3_rt = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
                        reqSpecifi = reqSpeciList_dict.get(int(rrList[rp2_v_i]))
                        requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
                        rp2_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
                        rp3_r1 =resource1Listvalues[rpList[rp3_i]]
                        rp3_r2 = resource2Listvalues[rpList[rp3_i]]
                        rp2_r1_try = rp2_r1 + int(rp2_vm_r[0] )- int(rp1_vm_r[0])
                        rp2_r2_try = rp2_r2 + int(rp2_vm_r[1]) - int(rp1_vm_r[1])
                        if rp2_r1_try>0 and rp2_r2_try>0:
                            delta_mCost = 0.5*(int(rp1_vm_r[0] )+ int(rp1_vm_r[1]) + int(rp2_vm_r[0] )+ int(rp2_vm_r[1]))
                            # src_delta_bCost = abs(float(src_r1 + src_vm_r[0]) / (src_r2 + src_vm_r[1]) - BALANCE_RATIO) - abs(float(src_r1) / src_r2 - BALANCE_RATIO)
                            rp1_delta_bCost = self.delta_dist(rp1_r1,rp1_r2,int(rp1_vm_r[0]),int(rp1_vm_r[1]))
                            rp2_delta_bCost = self.delta_dist(rp2_r1,rp2_r2,int(rp2_vm_r[0])-int(rp1_vm_r[0]),int(rp2_vm_r[1])-int(rp1_vm_r[1]))
                            rp3_delta_bCost = self.delta_dist(rp3_r1, rp3_r2,-int(rp2_vm_r[0]),-int(rp2_vm_r[1]))
                            delta_bCost = rp1_delta_bCost + rp2_delta_bCost + rp3_delta_bCost
                            delta_cost = MCOST_COEFFICIENT*delta_mCost + BCOST_COEFFICIENT*delta_bCost
                            if delta_cost < candi_best_cost:
                                candi_rp1_vm_i = rp1_v_i
                                candi_rp2_i = rp2_i
                                candi_rp2_vm_i = rp2_v_i
                                candi_rp3_i = rp3_i
                                candi_best_cost = delta_cost
        if candi_best_cost == float('inf'):
            return 0
        else:
            # update
            if (float(res1[rpList[candi_rp3_i]])>=float(resource1Listvalues[rpList[candi_rp3_i]])>= float(resource1[rrList[candi_rp2_vm_i]])) and (float(res2[rpList[candi_rp3_i]])>=float(resource2Listvalues[rpList[candi_rp3_i]])>= float(resource2[rrList[candi_rp2_vm_i]])) and (float(res1[rpList[candi_rp2_i]])>=float(resource1Listvalues[rpList[candi_rp2_i]])>=(float(resource1[rrList[candi_rp2_vm_i]])+float(resource1[rrList[candi_rp1_vm_i]]))) and (float(res2[rpList[candi_rp2_i]])>=float(resource2Listvalues[rpList[candi_rp2_i]])>=(float(resource2[rrList[candi_rp2_vm_i]]) + float(resource2[rrList[candi_rp1_vm_i]]))):

                rpIdListvalues[rrList[candi_rp1_vm_i]] = rpList[candi_rp2_i]
                rpIdListvalues[rrList[candi_rp2_vm_i]]=rpList[candi_rp3_i]
                resource1Listvalues[rpList[rp1_i]] += float(resource1[rrList[candi_rp1_vm_i]])
                resource2Listvalues[rpList[rp1_i]] += float(resource2[rrList[candi_rp1_vm_i]])
                vmListDit[rpList[rp1_i]]= [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[rp1_i]]))]
                while float(rrList[candi_rp1_vm_i] )in vmListDit[rpList[rp1_i]]:vmListDit[rpList[rp1_i]].remove(float(rrList[candi_rp1_vm_i]))
                # while float(rrList[candi_rp2_vm_i]) not in vmListDit[rp_list[rp1_i]]:vmListDit[rp_list[rp1_i]].append(rrList[candi_rp2_vm_i])
                resource1Listvalues[rpList[candi_rp2_i]] -=(float(resource1[rrList[candi_rp2_vm_i]])+float(resource1[rrList[candi_rp1_vm_i]]))
                resource2Listvalues[rpList[candi_rp2_i]] -= (float(resource2[rrList[candi_rp2_vm_i]]) + float(resource2[rrList[candi_rp1_vm_i]]))
                # vmListDit[idList_dict.get(rp_list[candi_rp2_i])].remove(rrList[candi_rp2_vm_i])
                vmListDit[rpList[candi_rp2_i]] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[candi_rp2_i]]))]
                while float(rrList[candi_rp2_vm_i]) in vmListDit[rpList[candi_rp2_i]]: vmListDit[rpList[candi_rp2_i]].remove(float(rrList[candi_rp2_vm_i]))
                while float(rrList[candi_rp1_vm_i]) not in vmListDit[rpList[candi_rp2_i]]: vmListDit[rpList[candi_rp2_i]].append(float(rrList[candi_rp1_vm_i]))
                resource1Listvalues[int(rpList[candi_rp3_i])] -= float(resource1[rrList[candi_rp2_vm_i]])
                resource2Listvalues[int(rpList[candi_rp3_i])] -= float(resource2[rrList[candi_rp2_vm_i]])
                vmListDit[rpList[candi_rp3_i]] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vmListDit[rpList[candi_rp3_i]]))]
                while float(rrList[candi_rp2_vm_i]) not in vmListDit[rpList[candi_rp3_i]]:vmListDit[rpList[candi_rp3_i]].append(rrList[candi_rp2_vm_i])
        #     # print("resource1Listvalues", resource1Listvalues)
        #     print("rpIdListvalues",rpIdListvalues)
        #     print("vmListDit3", vmListDit)
            aa = ['null'] * PM
            for key, value in vmListDit.items():
                value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
                aa[key] = str(value)
            # print("aa",aa)
            df_res.iloc[:, 2] = resource1Listvalues
            df_res.iloc[:, 3] = resource2Listvalues
            df_res.iloc[:, 8] = aa
            df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
            df.iloc[:, 4] = rpIdListvalues
            df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
            return candi_best_cost
    def shiftSearch(self, rrList, rpList, vm_id, requestSpecificationList, resourceSpecificationList,vmListDit):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        idList = df_res['id']
        idList_dict = idList.to_dict()
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()
        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        resspecifilist = []
        res1 = []
        res2 = []
        for req in range(len(resSpeciListvalue)):
            resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resspecifilist)):
            res1.append(resspecifilist[res][0])
            res2.append(resspecifilist[res][1])
        # randomly choose s'/desrp
        rand_rrList = rrList
        # rplist = rpList.SerializeToString()
        # rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist )]
        rand_rpList = rpList
        # rand_rplist = rand_rpList.SerializeToString()
        # Rand_rplist = [int(s) for s in re.findall(r'\b\d+\b', rand_rplist)]
        rand_vmListDict = vmListDit
        # print("rand_vmListDict ",rand_vmListDict )
        # print(" vm_id", vm_id)
        # print(type(vm_id))
        # print("rand_rrList",rand_rrList)
        vm_i = self.findVMindex(vm_id, rand_rrList)  # vm index in rand_rrList
        # print("vm_i",vm_i)
        # print(type(vm_i))

        srcrp_id=rpIdList_dict.get(rrList[vm_i]) #[rr_list[vm_i]]
        # print("srcrp_id",srcrp_id)
        srcrp_i = self.findRPindex([srcrp_id], rand_rpList)  # src rp index in rand_rpList
        # print("srcrp_i", srcrp_i )
        # randomly choose des rp in valid_rpList


        valid_rpList = self.getValidResourceProviders(rand_rrList[vm_i])
        # print("rand_rrList[vm_i]",rand_rrList[vm_i])
        # print(" valid_rpList", valid_rpList)
        self.removeSRCRP(int(srcrp_id),valid_rpList) # remove src rp in valid_rpList
        # print(" valid_rpList", valid_rpList)
        desrp_i = np.random.randint(0, len(valid_rpList)-1)  # in valid_rpList
        # print("desrp_i",desrp_i)
        # if not desrp_i:
        #     print('none desrp_i')
        desrp_id = valid_rpList[desrp_i]
        # # # desrp_id=valid_rpList.resourceProviderProto[desrp_i].id
        # print("desrp_id",desrp_id)
        # # # print(type(desrp_id))
        desrp_i = self.findRPindex([desrp_id],rand_rpList)  # in rand_rpList
        # print("desrp_i",desrp_i)
        reqSpecifi = reqSpeciList_dict.get(int(rand_rrList[vm_i]))
        requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
        # 定义的findRequestSpecification函数？
        reqSpecification = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
        # # print(" reqSpecification", reqSpecification)
        vm_r1 = reqSpecification[0]  # request
        # print("vm_r1 ",vm_r1 )
        vm_r2 = reqSpecification[1]
        # # print(" vm_r2 ", vm_r2 )
        src_r1 =resource1Listvalues[rand_rpList[srcrp_i]]
        # print("src_r1",src_r1)
        src_r2 = resource2Listvalues[rand_rpList[srcrp_i]]
        # # print(" src_r2", src_r2)
        des_r1 = resource1Listvalues[rand_rpList[desrp_i]] # remain resource in des rp
        # # print(" des_r1", des_r1)
        des_r2 = resource2Listvalues[rand_rpList[desrp_i]]
        # print(" des_r2", des_r2)
        # update rand_rrList, rand_rpList and vmListDict
        if (res1[rand_rpList[desrp_i]]>=resource1Listvalues[rand_rpList[desrp_i]]>=int(vm_r1)) and (res2[rand_rpList[desrp_i]]>=resource2Listvalues[rand_rpList[desrp_i]]>= int(vm_r2)):
            rpIdListvalues[rand_rrList[vm_i]]= desrp_id
            resource1Listvalues[rand_rpList[srcrp_i]]+=int(vm_r1) # remain
            resource2Listvalues[rand_rpList[srcrp_i]]+= int(vm_r2)
            rand_vmListDict[int(srcrp_id)] = [float(s) for s in re.findall(r"\d+\.?\d*", str(rand_vmListDict[int(srcrp_id)]))]
            while float(rand_rrList[vm_i]) in rand_vmListDict[int(srcrp_id)]: rand_vmListDict[int(srcrp_id)].remove(float(rand_rrList[vm_i]))
            # rand_vmListDict[int(srcrp_id)].remove(rand_rrList[vm_i])
            resource1Listvalues[rand_rpList[desrp_i]]-=int(vm_r1)
            resource2Listvalues[rand_rpList[desrp_i]] -= int(vm_r2)
            rand_vmListDict[int(desrp_id)] = [float(s) for s in re.findall(r"\d+\.?\d*", str(rand_vmListDict[int(desrp_id)]))]
            while rand_rrList[vm_i] not in rand_vmListDict[int(desrp_id)]: rand_vmListDict[int(desrp_id)].append(rand_rrList[vm_i])
        # print("rpIdListvalues",rpIdListvalues)
        # print("resource1Listvalues",resource1Listvalues)
        # print("shift_vmListDict",rand_vmListDict)
        # count cost of s'/rand_rrList
        # # # print("rand_vmListDict",rand_vmListDict)
        aa=['null']*PM
        for key, value in rand_vmListDict.items():
            value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
            aa[key] = str(value)
        # # # print("aa",aa)
        df_res.iloc[:, 2] = resource1Listvalues
        df_res.iloc[:, 3] = resource2Listvalues
        df_res.iloc[:, 8] = aa
        df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
        df.iloc[:, 4] = rpIdListvalues
        df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
        # #
        mCost = 0.5 * (int(vm_r1) + int(vm_r2))
        bCost=abs(src_r1+float(vm_r1)-(src_r2+float(vm_r2))*BALANCE_RATIO)-abs(src_r1-src_r2*BALANCE_RATIO)
        rand_cost = MCOST_COEFFICIENT*mCost+BCOST_COEFFICIENT*bCost
        # print("rand_cost",rand_cost)
        # find local optimum s''/best_rrList
        best_rrList = rand_rrList
        best_rpList = rand_rpList
        best_vmListDict = rand_vmListDict
        # print("best_vmListDict",best_vmListDict)
        opi = 0  # 0='shift', 1=swap', 2='replace'
        k = 0
        # delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList,resourceSpecificationList)
        while k<3:  # 5000 doesn't make sense
            delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList, resourceSpecificationList)
            # print("delta_cost",delta_cost)
            if delta_cost < 0:
                # accept shift search
                rrList= best_rrList
                rpList = best_rpList
                vmListDit.clear()
                vmListDit.update(best_vmListDict)
                return  rand_cost+ delta_cost
            else:
                opi += 1
                if opi > 2:
                    return False
                best_rrList = rand_rrList
                best_rpList = rand_rpList
                best_vmListDict = rand_vmListDict
            k += 1
        return rand_cost

    def swapSearch(self, rrList, rpList, vm_id, requestSpecificationList, resourceSpecificationList, vmListDit):
        # randomly choose s'/desrp
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        idList = df_res['id']
        idList_dict = idList.to_dict()
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()
        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        resspecifilist = []
        res1 = []
        res2 = []
        for req in range(len(resSpeciListvalue)):
            resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resspecifilist)):
            res1.append(resspecifilist[res][0])
            res2.append(resspecifilist[res][1])
        # print("res1",res1)
        # print("res2",res2)
        rand_rrList = rrList

        rand_rpList = rpList
        # rand_rplist = rand_rpList.SerializeToString()
        # Rand_rplist = [int(s) for s in re.findall(r'\b\d+\b', rand_rplist)]
        rand_vmListDict = vmListDit
        src_vm_i = self.findVMindex(int(vm_id),rand_rrList )  # vm index in rand_rrList
        # print("src_vm_i",src_vm_i)
        srcrp_id =  rpIdListvalues[rrList[src_vm_i]]
        # print("srcrp_id", srcrp_id)
        # print("rand_rpList",rand_rpList)
        srcrp_i = self.findRPindex([srcrp_id], rand_rpList)  # src rp index in rand_rpList
        # print("swsrcrp_i",srcrp_i)
        # if srcrp_i is None:
        #     print('none srcrp_i')
        # randomly choose des rp and des vm

        des_rpList = rand_rpList

        # des_rplist =  des_rpList.SerializeToString()
        # Des_rplist = [int(s) for s in re.findall(r'\b\d+\b', des_rplist)]
        # # print("Des_rplist",Des_rplist)
        # self.removeSRCRP(int(srcrp_id),Des_rplist)  # remove src rp in valid_rpList
        # print("Des_rplist",Des_rplist)
        #
        # # # # print("len1", len(des_rpList))
        valid_rpList = self.getValidResourceProviders(rand_rrList[src_vm_i])
        self.removeSRCRP(int(srcrp_id), valid_rpList)
        desrp_i = np.random.randint(0, len(valid_rpList)-1)  # in valid_rpList
        desrp_id = valid_rpList[desrp_i]
        # print("desrp_id",desrp_id)
        desrp_i = self.findRPindex([desrp_id],rand_rpList)  # in rand_rpList
        # print(" desrp_i",  desrp_i)
        reqSpecifi = reqSpeciList_dict.get(int(rand_rrList[src_vm_i]))
        requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
        src_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
        # print("src_vm_r ",src_vm_r )
        src_r1 = resource1Listvalues[rand_rpList[srcrp_i]]
        src_r2 = resource2Listvalues[rand_rpList[srcrp_i]]
        des_r1 = resource1Listvalues[rand_rpList[desrp_i]] # remain resource in des rp
        des_r2 = resource2Listvalues[rand_rpList[desrp_i]]
        # print("des_r2",des_r2)
        # # # vmListDit[rpList.resourceProviderProto[candi_rp2_i].id]
        des_vmList = rand_vmListDict[int(desrp_id)]
        des_vmList = [float(s) for s in re.findall(r"\d+\.?\d*", str(des_vmList))]
        # print("des_vmList",des_vmList)
        des_vm_i = np.random.randint(0, len(des_vmList))
        # # # # print("des_vm_i",des_vm_i)
        des_vm_id = des_vmList[des_vm_i]
        # print("des_vm_id",des_vm_id)
        # #
        des_vm_i = self.findVMindex(int(des_vm_id), rrList)
        # print(" des_vm_i", des_vm_i)
        ReqSpecifi = reqSpeciList_dict.get(int(rand_rrList[des_vm_i]))
        RequestSpecification = re.findall(r'[(](.*?)[)]',ReqSpecifi )
        des_vm_r = self.findRequestSpecification(RequestSpecification[0], requestSpecificationList)
        # print("des_vm_r",des_vm_r)
        # update rand_rrList, rand_rpList and vmListDict
        if (res1[rand_rpList[desrp_i]]>=resource1Listvalues[rand_rpList[desrp_i]]>= int(src_vm_r[0])) and (res2[rand_rpList[desrp_i]]>=resource2Listvalues[rand_rpList[desrp_i]]>= int(src_vm_r[1])) and (res1[rand_rpList[srcrp_i]]>=resource1Listvalues[rand_rpList[srcrp_i]]>=int(des_vm_r[0])) and (res2[rand_rpList[srcrp_i]]>=resource2Listvalues[rand_rpList[srcrp_i]]>=int(des_vm_r[1])):
            rpIdListvalues[rand_rrList[src_vm_i]]= desrp_id
            rpIdListvalues[rand_rrList[des_vm_i]] = srcrp_id
            resource1Listvalues[ rand_rpList[srcrp_i]]=resource1Listvalues[ rand_rpList[srcrp_i]]+int(src_vm_r[0]) - int(des_vm_r[0])# remain
            resource2Listvalues[ rand_rpList[srcrp_i]]=resource2Listvalues[ rand_rpList[srcrp_i]]+ int(src_vm_r[1]) - int(des_vm_r[1])
            rand_vmListDict[int(srcrp_id)] = [float(s) for s in re.findall(r"\d+\.?\d*", str(rand_vmListDict[int(srcrp_id)]))]
            while float(rand_rrList[src_vm_i]) in rand_vmListDict[int(srcrp_id)]:rand_vmListDict[int(srcrp_id)].remove(float(rand_rrList[src_vm_i]))
            while float(rand_rrList[des_vm_i]) not in rand_vmListDict[int(srcrp_id)]:rand_vmListDict[int(srcrp_id)].append(float(rand_rrList[des_vm_i]))
            resource1Listvalues[ rand_rpList[desrp_i]]=resource1Listvalues[ rand_rpList[desrp_i]]- int(src_vm_r[0])+int(des_vm_r[0])
            resource2Listvalues[ rand_rpList[desrp_i]]=resource2Listvalues[ rand_rpList[desrp_i]]- int(src_vm_r[1])+int(des_vm_r[1])
        #     # rand_vmListDict[desrp_id].remove(rand_rrList.resourceRequestProto[des_vm_i])
            rand_vmListDict[int(desrp_id)] = [float(s) for s in re.findall(r"\d+\.?\d*", str(rand_vmListDict[int(desrp_id)]))]
            while float(rand_rrList[des_vm_i]) in rand_vmListDict[int(desrp_id)]:rand_vmListDict[int(desrp_id)].remove(float(rand_rrList[des_vm_i]))
            while float(rand_rrList[src_vm_i]) not in rand_vmListDict[int(desrp_id)]:rand_vmListDict[int(desrp_id)].append(float(rand_rrList[src_vm_i]))
        # print("resource1Listvalues",  resource1Listvalues)
        # print("swrand_vmListDict",rand_vmListDict)
        aa = ['null'] * PM
        for key, value in rand_vmListDict.items():
            value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
            aa[key] = str(value)
        # print("aa",aa)
        df_res.iloc[:, 2] = resource1Listvalues
        df_res.iloc[:, 3] = resource2Listvalues
        df_res.iloc[:, 8] = aa
        df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
        df.iloc[:, 4] = rpIdListvalues
        df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
        # count cost of s'/rand_rrList
        mCost = 0.5 * (int(src_vm_r[0] )+ int(src_vm_r[1]) + int(des_vm_r[0]) + int(des_vm_r[1]))

        bCost = self.delta_dist(src_r1, src_r2, int(src_vm_r[0])-int(des_vm_r[0]), int(src_vm_r[1])-int(des_vm_r[1])) + self.delta_dist(des_r1, des_r2, int(des_vm_r[0])-int(src_vm_r[0]), int(des_vm_r[1])-int(src_vm_r[1]))
        rand_cost = MCOST_COEFFICIENT*mCost+BCOST_COEFFICIENT*bCost
        # #
        # find local optimum s''/best_rrList
        best_rrList = rand_rrList
        best_rpList = rand_rpList
        best_vmListDict = rand_vmListDict
        opi = 0  # 0='shift', 1=swap', 2='replace'
        k = 0
        # delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList,resourceSpecificationList)
        while k<3:  # 5000 doesn't make sense
            delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList, resourceSpecificationList)
            # print("delta_cost",delta_cost)
            if delta_cost < 0:
                # accept shift search
                rrList= best_rrList
                rpList= best_rpList
                vmListDit.clear()
                vmListDit.update(best_vmListDict)
                return rand_cost + delta_cost
            else:
                opi += 1
                if opi > 2:
                    return False
                best_rrList = rand_rrList
                best_rpList = rand_rpList
                best_vmListDict = rand_vmListDict
            k += 1
        return rand_cost


    def replaceSearch(self, rrList, rpList, vm_id, requestSpecificationList, resourceSpecificationList, vmListDit):

    # randomly choose s'/desrp
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)
        rpIdList = df['rpId']
        rpIdList_dict = rpIdList.to_dict()
        rpIdListvalues = rpIdList_dict.values()
        idList = df_res['id']
        idList_dict = idList.to_dict()
        reqSpeciList = df['requestSpecification']
        reqSpeciList_dict = reqSpeciList.to_dict()
        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()
        trait1List = df_res['trait1']
        trait1List_dict = trait1List.to_dict()
        trait1Listvalues = trait1List_dict.values()

        trait2List = df_res['trait2']
        trait2List_dict = trait2List.to_dict()
        trait2Listvalues = trait2List_dict.values()

        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resSpeciListvalue = resSpeciList_dict.values()
        resspecifilist = []
        res1 = []
        res2 = []
        for req in range(len(resSpeciListvalue)):
            resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
        for res in range(len(resspecifilist)):
            res1.append(resspecifilist[res][0])
            res2.append(resspecifilist[res][1])
        rand_rrList = rrList
        # rand_rrlist = rand_rrList.SerializeToString()
        # Rand_rrlist = [int(s) for s in re.findall(r'\b\d+\b', rand_rrlist)]
        rand_rpList = rpList
        # rand_rplist = rand_rpList.SerializeToString()
        # Rand_rplist = [int(s) for s in re.findall(r'\b\d+\b', rand_rplist)]
        rand_vmListDict = vmListDit
        # rrlist = rrList.SerializeToString()
        # rr_list = [int(s) for s in re.findall(r'\b\d+\b', rrlist)]
        rp1_vm_i = self.findVMindex(vm_id, rand_rrList)  # vm index in rand_rrList
        # print("rp1_vm_i", rp1_vm_i )
        rp1_id = rpIdList_dict.get(rrList[rp1_vm_i])
        # print("rp1_id ",rp1_id )
        rp1_i = self.findRPindex([rp1_id], rand_rpList)  # src rp index in rand_rpList
        # randomly choose rp2 and rp2 vm and rp3
        trait1 = trait1List_dict.get(rand_rpList[rp1_i])
        trait2 = trait2List_dict.get(rand_rpList[rp1_i])
        # print("trait1",trait1)
        # print("trait2",trait2)
        rp2_rpList = self.findMatchRP(rand_rpList, trait1, trait2, int(rp1_id))
        # print("rp2_rpList", rp2_rpList)
        rp2_i = np.random.randint(0, len(rp2_rpList)-1)
        # print(" rp2_i", rp2_i)
        rp2_id = rp2_rpList[rp2_i]
        # print(" rp2_id ", rp2_id )
        rp2_i = self.findRPindex([rp2_id], rand_rpList)
        # print("rp2_i",rp2_i)
        reqSpecifi = reqSpeciList_dict.get(int(rand_rrList[rp1_vm_i]))
        requestSpecification = re.findall(r'[(](.*?)[)]', reqSpecifi)
        rp1_vm_r = self.findRequestSpecification(requestSpecification[0], requestSpecificationList)
        # print("rp1_vm_r",rp1_vm_r)

        rp1_r1 = resource1Listvalues[rand_rpList[rp1_i]]
        rp1_r2= resource2Listvalues[rand_rpList[rp1_i]]
        rp2_r1 = resource1Listvalues[rand_rpList[rp2_i]]
        rp2_r2 = resource2Listvalues[rand_rpList[rp2_i]]  # remain resource in des rp
        rp2_vmList = rand_vmListDict[int(rp2_id)]

        rp2_vmList = [float(s) for s in re.findall(r"\d+\.?\d*", str(rp2_vmList))]
        # print("rp2_vmList",rp2_vmList)
        rp2_vm_i = np.random.randint(0, len(rp2_vmList))
        # print("rp2_vm_i",rp2_vm_i)
        rp2_vm_id = rp2_vmList[int(rp2_vm_i)]

        rp2_vm_id= [float(s) for s in re.findall(r"\d+\.?\d*", str(rp2_vm_id))]
        rp2_vm_i  = self.findVMindex(int(rp2_vm_id[0]), rrList)
        ReqSpecifi = reqSpeciList_dict.get(int(rand_rrList[rp2_vm_i]))
        RequestSpecification = re.findall(r'[(](.*?)[)]',ReqSpecifi)
        rp2_vm_r = self.findRequestSpecification(RequestSpecification[0],requestSpecificationList)
        # print(" rp2_vm_r ", rp2_vm_r )
        # update rand_rrList, rand_rpList and vmListDict
        if (res1[rand_rpList[rp2_i]]>=resource1Listvalues[rand_rpList[rp2_i]]>= int(rp1_vm_r[0])) and (res2[rand_rpList[rp2_i]]>=resource2Listvalues[rand_rpList[rp2_i]]>= int(rp1_vm_r[1])) and (res1[rand_rpList[rp1_i]]>=resource1Listvalues[rand_rpList[rp1_i]]>=float(rp2_vm_r[0])) and (res2[rand_rpList[rp1_i]]>=resource2Listvalues[rand_rpList[rp1_i]]>=float(rp2_vm_r[1])):
            rpIdListvalues[rand_rrList[rp1_vm_i]] =rp2_id
            rpIdListvalues[rand_rrList[rp2_vm_i]] = rp1_id
            resource1Listvalues[rand_rpList[rp1_i]] = resource1Listvalues[rand_rpList[rp1_i]]+float(rp1_vm_r[0]) - float(rp2_vm_r[0]) # remain
            resource2Listvalues[rand_rpList[rp1_i]] = resource2Listvalues[rand_rpList[rp1_i]]+float(rp1_vm_r[1]) - float(rp2_vm_r[1])
            rand_vmListDict[int(rp1_id)]=[float(s) for s in re.findall(r"\d+\.?\d*", str(rand_vmListDict[int(rp1_id)]))]
            while float(rand_rrList[rp1_vm_i]) in rand_vmListDict[int(rp1_id)]: rand_vmListDict[int(rp1_id)].remove(float(rand_rrList[rp1_vm_i]))
            while float(rand_rrList[rp2_vm_i]) not in rand_vmListDict[int(rp1_id)]:rand_vmListDict[int(rp1_id)].append(float(rand_rrList[rp2_vm_i]))
            resource1Listvalues[rand_rpList[rp2_i]] =resource1Listvalues[rand_rpList[rp2_i]] -float(rp1_vm_r[0])+float(rp2_vm_r[0])
            resource2Listvalues[rand_rpList[rp2_i]] =resource2Listvalues[rand_rpList[rp2_i]] -float(rp1_vm_r[1])+float(rp2_vm_r[1])
            rand_vmListDict[int(rp2_id)] = [float(s) for s in re.findall(r"\d+\.?\d*", str(rand_vmListDict[int(rp2_id)]))]
            while float(rand_rrList[rp2_vm_i]) in rand_vmListDict[int(rp2_id)]: rand_vmListDict[int(rp2_id)].remove(float(rand_rrList[rp2_vm_i]))
            while float(rand_rrList[rp1_vm_i]) not in rand_vmListDict[int(rp2_id)]:rand_vmListDict[int(rp2_id)].append(rand_rrList[rp1_vm_i])
        # print("resource1Listvalues",resource1Listvalues)
        # print("replace",rand_vmListDict)
        aa = ['null'] * PM
        for key, value in rand_vmListDict.items():
            value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
            aa[key] = str(value)
        # print("aa",aa)
        df_res.iloc[:, 2] = resource1Listvalues
        df_res.iloc[:, 3] = resource2Listvalues
        df_res.iloc[:, 8] = aa
        df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
        df.iloc[:, 4] = rpIdListvalues
        df.to_sql('resourcerequest', engine, if_exists='replace', index=False)

        # count cost of s'/rand_rrList
        mCost = 0.5 * (int(rp1_vm_r[0] )+ int(rp1_vm_r[1]) + int(rp2_vm_r[0]) + int(rp2_vm_r[1]))
        # bCost = abs(((src_r1+vm_r1)/(src_r2+vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)+abs(((des_r1-vm_r1)/(des_r2-vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)
        bCost = self.delta_dist(rp1_r1, rp1_r2, int(rp1_vm_r[0]) - int(rp2_vm_r[0]), int(rp1_vm_r[1] )- int(rp2_vm_r[1])) + self.delta_dist(rp2_r1, rp2_r2, int(rp2_vm_r[0] )- int(rp1_vm_r[0]), int(rp2_vm_r[1]) - int(rp1_vm_r[1]))
        rand_cost = MCOST_COEFFICIENT * mCost + BCOST_COEFFICIENT * bCost
        # print("rand_cost", rand_cost)
        # find local optimum s''/best_rrList
        best_rrList = rand_rrList
        best_rpList = rand_rpList
        best_vmListDict = rand_vmListDict
        opi = 0  # 0='shift', 1=swap', 2='replace'
        k = 0
        # delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList,resourceSpecificationList)
        while k < 3:  # 5000 doesn't make sense
            delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList,resourceSpecificationList)
            if delta_cost < 0:
                # accept shift search
                rrList= best_rrList
                rpList= best_rpList
                vmListDit.clear()
                vmListDit.update(best_vmListDict)
                return rand_cost + delta_cost
            else:
                opi += 1
                if opi > 2:
                    return False
                best_rrList = rand_rrList
                best_rpList = rand_rpList
                best_vmListDict = rand_vmListDict
            k += 1
        return rand_cost

    def rpLisTurningoff(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        # sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        vmList = df_res['vminPM']
        vmList_dict = vmList.to_dict()
        rpStateList = df_res['rp_state']
        rpState_dict=rpStateList.to_dict()
        off_rpList=[]
        for rp in range(len( vmList_dict )):
            if (vmList_dict[rp]=='[]') and (rpState_dict[rp]=='On'):
                off_rpList.append(rp)
        return off_rpList

    def rpList_turningoff(self, rpList, vmListDict):
        off_rpList = []
        for i in range(0, len(rpList)):
            if len(vmListDict[rpList[i]]) == 0:
                off_rpList.append(rpList[i])
        return off_rpList
    # def rpList_turningoff(self, rpList, vmListDict):
    #     engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
    #     # sql = ''' select * from resourcerequest; '''
    #     sql_res = ''' select * from resourceprovider; '''
    #     df_res = pd.read_sql_query(sql_res, engine)
    #     rplist = rpList.SerializeToString()
    #     rp_list = [int(s) for s in re.findall(r'\b\d+\b', rplist)]
    #     off_rpList =[]
    #     for i in range(0, len(rp_list)):
    #         if len(vmListDict[rp_list[i]]) == 0:
    #             off_rpList.append(rp_list[i])
    #     return off_rpList


    def vnsBasedScheduler(self, ori_rrList, ori_rpList, resourceSpecificationList, requestSpecificationList, ori_vmListDict):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql_res = ''' select * from resourceprovider; '''
        sql = ''' select * from resourcerequest; '''
        df_res = pd.read_sql_query(sql_res, engine)
        resSpeciList = df_res['resourceSpecification']
        resSpeciList_dict = resSpeciList.to_dict()
        resource1List = df_res['resource1']
        resource1List_dict = resource1List.to_dict()
        resource1Listvalues = resource1List_dict.values()
        resource2List = df_res['resource2']
        resource2List_dict = resource2List.to_dict()
        resource2Listvalues = resource2List_dict.values()
        rpList = ori_rpList
        rrList = ori_rrList
        vmListDict = ori_vmListDict
        try:
            sortedRP = self.sortRPs(ori_rpList)  # [('ip', sorter),(),(),...]
            for i in range(0, len(sortedRP)):
                pre_rpList = rpList
                pre_rrList = rrList
                pre_vmListDict = vmListDict
                rp_id = sortedRP[i]
                rp_i = self.findRPindex(rp_id, rpList)  # src rp index in rpList
                resource1=resource1Listvalues[rpList[rp_i]]
                resSpecifi = resSpeciList_dict.get(int(rpList[rp_i]))
                resourceSpecification = re.findall(r'[(](.*?)[)]', resSpecifi)
                resSpecification = self.findResourceSpecification(resourceSpecification[0], resourceSpecificationList)
                resource1_t = resSpecification[0]
                if float(resource1)/float(resource1_t )> COLD_CPU_TS:
                    continue
                vm_tcost = 0
                rp_Id=list(rp_id)
                aa=vmListDict[rp_Id[0]]
                AA = [float(s) for s in re.findall(r"\d+\.?\d*", str(aa))]
                for vm in AA:#vmLihtDict[rp_Id[0]]
                    best_cost = float('inf')
                    best_move = 0
                    shift_rrList = pre_rrList
                    shift_rpList = pre_rpList
                    shift_vmListDict = pre_vmListDict
                    swap_rrList = pre_rrList
                    swap_rpList = pre_rpList
                    swap_vmListDict = pre_vmListDict
                    replace_rrList = pre_rrList
                    replace_rpList = pre_rpList
                    replace_vmListDict = pre_vmListDict
                    T = 0
                    while T < 3:#2000
                        shift_cost = self.shiftSearch(shift_rrList, shift_rpList, vm, requestSpecificationList, resourceSpecificationList, shift_vmListDict)
                        print("shift_cost",shift_cost)
                        swap_cost =  self.swapSearch(swap_rrList, swap_rpList,vm, requestSpecificationList, resourceSpecificationList, swap_vmListDict)
                        print("swap_cost",swap_cost)
                    #     # T += 1
                        replace_cost = self.replaceSearch(replace_rrList, replace_rpList, vm, requestSpecificationList, resourceSpecificationList, replace_vmListDict)
                        print("replace_cost",replace_cost)
                        # T += 1
                #         if shift_cost < best_cost:
                #             best_cost = shift_cost
                #             best_move = 0
                #         if swap_cost < best_cost:
                #             best_cost = swap_cost
                #             best_move = 1
                #         if replace_cost < best_cost:
                #             best_cost = replace_cost
                #             best_move = 2
                # #         print("best_cost", best_cost)
                # #         print("best_move", best_move)
                # #         print("replace_cost",replace_cost)
                #         if best_move == 0:
                #             vm_tcost += shift_cost
                #             swap_rrList = shift_rrList
                #             swap_rpList = shift_rpList
                #             swap_vmListDict = shift_vmListDict
                #             replace_rrList = shift_rrList
                #             replace_rpList = shift_rpList
                #             replace_vmListDict = shift_vmListDict
                #         elif best_move == 1:
                #             vm_tcost += swap_cost
                #             shift_rrList = swap_rrList
                #             shift_rpList = swap_rpList
                #             shift_vmListDict = swap_vmListDict
                #             replace_rrList = swap_rrList
                #             replace_rpList = swap_rpList
                #             replace_vmListDict = swap_vmListDict
                #         elif best_move == 2:
                #             vm_tcost += replace_cost
                #             shift_rrList = replace_rrList
                #             shift_rpList = replace_rpList
                #             shift_vmListDict = replace_vmListDict
                #             swap_rrList = replace_rrList
                #             swap_rpList = replace_rpList
                #             swap_vmListDict = replace_vmListDict
                #         print("vm_tcost", vm_tcost)
                #     if best_move == 0:
                #         pre_rrList = shift_rrList
                #         pre_rpList = shift_rpList
                #         pre_vmListDict = shift_vmListDict
                #     elif best_move == 1:
                #         pre_rrList = swap_rrList
                #         pre_rpList = swap_rpList
                #         pre_vmListDict = swap_vmListDict
                #     elif best_move == 2:
                #         pre_rrList = replace_rrList
                #         pre_rpList = replace_rpList
                #         pre_vmListDict = replace_vmListDict
                # if vm_tcost < RP_CHARGE:
                #     rpList = pre_rpList
                #     rrList = pre_rrList
            # return self.rpList_turningoff(rpList, vmListDict)
        except Exception as e:
            print(e)

    def listMinus(self, bfo_k, aft_k_1):
        result = []
        for i in range(0,len(bfo_k)):
            result.append([bfo_k[i][j] - aft_k_1[i][j] for j in range(len(bfo_k[i]))])
        return result

    def listMultiply(self, bfo_k, aft_k_1):
        result = []
        for i in range(0, len(bfo_k)):
            result.append([float(bfo_k[i][j] / aft_k_1[i][j]) for j in range(len(bfo_k[i]))])
        return result

    def separateList(self, mixList):
        r1_AB = []
        r1_Ab = []
        r1_aB = []
        r1_ab = []
        r2_AB = []
        r2_Ab = []
        r2_aB = []
        r2_ab = []
        for res_used in mixList:  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
            r1_AB.append(res_used[0][0])
            r1_Ab.append(res_used[1][0])
            r1_aB.append(res_used[2][0])
            r1_ab.append(res_used[3][0])
            r2_AB.append(res_used[0][1])
            r2_Ab.append(res_used[1][1])
            r2_aB.append(res_used[2][1])
            r2_ab.append(res_used[3][1])
        return [r1_AB, r1_Ab, r1_aB, r1_ab, r2_AB, r2_Ab, r2_aB, r2_ab]


    def predictR(self, R_LIST, CHANGE_P):
        l = len(R_LIST)
        lists = self.separateList(R_LIST)  # [r1_AB, r1_Ab, r1_aB, r1_ab, r2_AB, r2_Ab, r2_aB, r2_ab]
        result = [[0,0], [0,0], [0,0], [0,0]]
        for i in range(0, len(lists)):
            if len(lists[i]) > WINDOW:
                lists[i] = lists[i][-WINDOW:]
            if predict.is_change_point(lists[i], PRIOR_STEP, THRESH):
                CHANGE_P[i] = l-1
                ALPHA[i] = 1.0
            elif ALPHA[i] > FIX_ALPHA:
                ALPHA[i] -= 0.1
            result[i//2][i%2] = predict.ewma(lists[i][CHANGE_P[i]:], ALPHA[i])
        return result

    def listPlus(self, bfo_k, aft_k_1):
        result = []
        for i in range(0,len(bfo_k)):
            result.append([bfo_k[i][j] + aft_k_1[i][j] for j in range(len(bfo_k[i]))])
        return result

    def ifAllBigerThan0(self, delta_r):
        for i in range(0, len(delta_r)):
            for j in range(0, len(delta_r[i])):
                if delta_r[i][j] <= 0:
                    return False
        return True

    def ifAnySmallerThan0(self, delta_r):
        for i in range(0, len(delta_r)):
            for j in range(0, len(delta_r[i])):
                if delta_r[i][j] <= 0:
                    return True
        return False

    def finishMission(self):
        try:
            print("finish")
        except Exception as ee:
            print(ee)


    # 获得关闭的RP的状况
    def getOffResourceProviders(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        try:
            rpStateList = df['rp_state']
            rpStateList_dict = rpStateList.to_dict()
            offrplist = filter(lambda k: rpStateList_dict[k] == 'Off', rpStateList_dict)
            return offrplist
        except Exception as err:
            print(err)

    def releaseResourceRequests(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourcerequest; '''
        sql_res = ''' select * from resourceprovider; '''
        df_res = pd.read_sql_query(sql_res, engine)
        df = pd.read_sql_query(sql, engine)
        try:
            #rp表
            resSpeciList = df_res['resourceSpecification']
            resSpeciList_dict = resSpeciList.to_dict()
            resSpeciListvalue = resSpeciList_dict.values()
            resspecifilist = []
            res1 = []
            res2 = []
            for req in range(len(resSpeciListvalue)):
                resspecifilist.append(resSpeciListvalue[req].strip('()').split(','))
            for res in range(len(resspecifilist)):
                res1.append(resspecifilist[res][0])
                res2.append(resspecifilist[res][1])
            vminPM=df_res['vminPM']
            vminPM_dict=vminPM.to_dict()
            vminPMlist=vminPM_dict.values()
            resource1 = df_res['resource1']
            resource1_dict = resource1.to_dict()
            resource1list = resource1_dict.values()
            resource2 = df_res['resource2']
            resource2_dict = resource2.to_dict()
            resource2list = resource2_dict.values()
            #rr表
            df = df.fillna('null')
            reqSpeciList = df['requestSpecification']
            reqSpeciList_dict = reqSpeciList.to_dict()
            reqSpeciListvalue = reqSpeciList_dict.values()
            resourcereqlist = []
            resource1 = []
            resource2 = []
            for req in range(len(reqSpeciListvalue)):
                resourcereqlist.append(reqSpeciListvalue[req].strip('()').split(','))
            for res in range(len(resourcereqlist)):
                resource1.append(resourcereqlist[res][0])
                resource2.append(resourcereqlist[res][1])
            rpId=df['rpId']
            rpId_dict=rpId.to_dict()
            rpIdlist=rpId_dict.values()
            # print("rpIdlist",rpIdlist)
            # print("vminPM_dict",vminPM_dict)
            rpIdList=[]
            for rpid in range(0,len(rpIdlist)):
                if (rpIdlist[rpid]!="null") and (rpIdlist[rpid]!="Release"):
                    rpIdList.append(rpid)
            # print("rpIdList",rpIdList)
            slice = random.sample(rpIdList, 30)
            # print("slice",slice)

            for req in slice:
                if (res1[int(rpIdlist[req])]>=resource1list[int(rpIdlist[req])]) and (res1[int(rpIdlist[req])]>=resource2list[int(rpIdlist[req])]):
                    resource1list[int(rpIdlist[req])] += float(resource1[req])
                    resource2list[int(rpIdlist[req])]+= float(resource2[req])
                    vminPM_dict[int(rpIdlist[req])] = [float(s) for s in re.findall(r"\d+\.?\d*", str(vminPM_dict[int(rpIdlist[req])]))]
                    while float(req) in vminPM_dict[int(rpIdlist[req])]: vminPM_dict[int(rpIdlist[req])].remove(float(req))
                    rpIdlist[req] = "Release"

            aa = ['null'] * PM
            for key, value in vminPM_dict.items():
                value = [float(s) for s in re.findall(r"\d+\.?\d*", str(value))]
                aa[key] = str(value)
            df_res.iloc[:, 8] = aa
            df_res.iloc[:, 2] = resource1list
            df_res.iloc[:, 3] = resource2list
            df_res.to_sql('resourceprovider', engine, if_exists='replace', index=False)
            df.iloc[:, 4] = rpIdlist
            df.to_sql('resourcerequest', engine, if_exists='replace', index=False)
        except Exception as err:
            print(err)

    def test1(self):
        on_rp = self.getRunningResourceProviders()
        print("rp_on_list", on_rp)
        # rp_off_list = []
        # rp_off_list.extend(rp_on_list[:10])
        # print("rp_off_list",rp_off_list)
        # self.turnOffResourceProviderList(rp_off_list)

        aft_k = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]  # resource used after placement in kth cycle
        RELEASE_LIST = []
        REQUEST_LIST = []
        REL_CHANGE_P = [0, 0, 0, 0, 0, 0, 0, 0]
        REQ_CHANGE_P = [0, 0, 0, 0, 0, 0, 0, 0]
        for i in range(400):  # make first few cycle predicable
            RELEASE_LIST.append([[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]])
            REQUEST_LIST.append([[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]])
        Rr_list=[]
        On_rplist=[]
        for i in range(6):  # 6 days = 8640 min = 1728 5min
            resourceSpecificationList = self.getResourceSpecfication()
            # print("resourceSpecificationList", resourceSpecificationList)
            requestSpecificationList = self.getRequestSpecfication()
            # print(" requestSpecificationList",requestSpecificationList)
            # on_rp= self.getRunningResourceProviders() #是list
            print("on_rp",on_rp)
            vmListDit = self.getvmLists(on_rp)  # { 'id0':[vm1,vm2,...], 'id1':[vm3,vm4,...], ...  } notice it is vm instance  not vm_id
            # print("vmListDit",vmListDit)
           # resource used before placement in kth cycle
            bfo_k = self.TotalResUsed(on_rp, resourceSpecificationList)  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
            # print(" bfo_k",bfo_k)
           # resource remained before placement in kth cycle
            remain_k=self.TotalResRem(on_rp, resourceSpecificationList)
            # print("rem_k",remain_k)
            # delta_t= self.listMinus(remain_k, bfo_k)
            # print("delta_t",delta_t)
            rrList=self.getMission(39+20*i)#
            rrlist = rrList.SerializeToString()
            Rr_list.append([int(s) for s in re.findall(r'\b\d+\b', rrlist)])
            print("rrList",Rr_list[i])
            # total = self.listPlus(bfo_k,  remain_k)
            # uslization = self.listMultiply(bfo_k, total)
            # print("total", total)
            # print("uslization",uslization)
            #kubernetes
            # self.kubernates(Rr_list[i], on_rp, requestSpecificationList, vmListDit)

            # first placement
            self.firstPlacement(Rr_list[i],on_rp, requestSpecificationList, vmListDit)
            on_rp = self.getRunningResourceProviders()
            print("on_rp",on_rp)
            afo_k = self.TotalResUsed(on_rp, resourceSpecificationList)
            afremain_k = self.TotalResRem(on_rp, resourceSpecificationList)
            Total = self.listPlus( afo_k, afremain_k )
            Uslization=self.listMultiply(afo_k,Total)
            # print("afo_k",afo_k )
            # print("afremain_k",afremain_k)
            # print("Total", Total)
            # print("Uslization",Uslization)


            # sendAllocation=self.sendAllocation(Rr_list[i])

            # print("sendAllocation",sendAllocation)
            # self.finishMission()

            # resource used after placement in (k-1)th cycle
            aft_k_1 = aft_k  # when i=0 aft_k_1=0
            aft_k = self.TotalResUsed(on_rp, resourceSpecificationList)
            Rr_list[i]= self.getAllVirtualMachine()
           #  print("Rr_list[i]", Rr_list[i])
            # trans_rrList = Data.ResourceRequestListProto()
            # trans_rrList.resourceRequestProto.extend(rrList.resourceRequestProto[:10])
            # self.randomAllocate(rrList)
            #
            self.vnsBasedScheduler(Rr_list[i], on_rp, resourceSpecificationList, requestSpecificationList, vmListDit)


            if i%5==0:
                self.releaseResourceRequests()
            rp_ready_off = self.rpLisTurningoff()
            rp_ready_off = self.rpLisTurningoff()
            print("rp_ready_off0", rp_ready_off)

            # self.transferVirtualMachine(rrList) #没实现

            # predict rp_on_list
            RELEASE_LIST.append(self.listMinus(bfo_k, aft_k_1))  # RELEASE_LIST[k] store resource released in cycle (k-1)th
            REQUEST_LIST.append(self.listMinus(aft_k, bfo_k))  # REQUEST_LIST[k] store resource requested in cycle kth
            release_k = self.predictR(RELEASE_LIST, REL_CHANGE_P)  # resource will be released in this cycle
            req_kp1 = self.predictR(REQUEST_LIST, REQ_CHANGE_P)  # resource needed in next cycle


            delta_r = self.listMinus(self.listPlus(release_k, remain_k), req_kp1)

            print(" delta_r", delta_r)
            engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
            sql_res = ''' select * from resourceprovider; '''
            df_res = pd.read_sql_query(sql_res, engine)
            resource1List = df_res['resource1']
            resource1List_dict = resource1List.to_dict()
            resource1Listvalues = resource1List_dict.values()
            resource2List = df_res['resource2']
            resource2List_dict = resource2List.to_dict()
            resource2Listvalues = resource2List_dict.values()
            Trait1list = df_res['trait1']
            Trait1list_dict = Trait1list.to_dict()
            Trait1listvalues=Trait1list_dict.values()
            Trait2list =df_res['trait2']
            Trait2list_dict = Trait2list.to_dict()
            Trait2listvalues = Trait2list_dict.values()
            if self.ifAllBigerThan0(delta_r):
                # select some rps in rp_ready_off to turn off
                Candi_offlist=[]
                print("Candi_offlist",Candi_offlist)
                for rp in rp_ready_off:
                    Candi_offlist.append(rp)
                    r1 = resource1Listvalues[rp]
                    r2 = resource2Listvalues[rp]
                    self.updateByTrait(delta_r, Trait1listvalues[rp], Trait2listvalues[rp], -r1, -r2)
                    # rp_ready_off.remove(rp)

                    if (not self.ifAllBigerThan0(delta_r)) or (not rp_ready_off):
                        break
                print("rp_ready_off", rp_ready_off)
                print("Candi_offlist",Candi_offlist)
                # del Candi_offlist[len(Candi_offlist)-1]
           #  #     print("Candi_offlist",Candi_offlist)
                self.turnOffResourceProviderList(Candi_offlist)
            elif self.ifAnySmallerThan0(delta_r):
                # select some off rps to turn on
                rp_ready_on = self.getOffResourceProviders()
                print("rp_ready_on",rp_ready_on)
                Candi_onlist=[]
                print("Candi_onlist",Candi_onlist)
                for rp in rp_ready_on:
                    Candi_onlist.append(rp)
                    r1 = resource1Listvalues[rp]
                    r2 = resource2Listvalues[rp]
                    self.updateByTrait(delta_r, Trait1listvalues[rp], Trait2listvalues[rp], r1, r2)
                    # rp_ready_on.remove(rp)
                    if (not self.ifAnySmallerThan0(delta_r)) or (not rp_ready_on):
                        break
                print("rp_ready_on", rp_ready_on)
                print("Candi_onlist", Candi_onlist)
                self.turnOnResourceProviderList(Candi_onlist)
    #         # rp_off_list = self.getOffResourceProviders()
    #         # rp_on_list = Data.ResourceProviderListProto()
    #         # rp_on_list.resourceProviderProto.extend(rp_off_list.resourceProviderProto[:10])
    #         # self.turnOnResourceProviderList(rp_on_list)
    #
    # #     self.halt()


if __name__ == '__main__':

    c=Allocation()
    c.test1()
    # aa=c.getVMinPM([18])
    # print(aa)




