# -*- coding: utf-8 -*-
# # ***************************************************************************
# Copyright (c) 2019 华为技术有限责任公司
# All rights reserved
#
# 文件名称：AllocationTest.py
#
# 摘    要：随机分配算法
#
# 创 建 者：上官栋栋
#
# 创建日期：2019年10月26日
#
# 修改记录
# 日期  修改者   		版本     修改内容
# ------------- 		-------  ------------------------
# ***************************************************************************

import urllib
import unittest

import os
import sys
import logging
# from HTMLTestRunner import HTMLTestRunner
from Proto import Data_pb2 as Data
import time
import numpy as np
import predict

COLD_SET_SIZE = 200
HOT_SET_SIZE = 500
RCOST_COEFFICIENT = 1
MCOST_COEFFICIENT = 1
BCOST_COEFFICIENT = 1
RP_CHARGE = 320  # charge for per onRP
HOT_CPU_TS = 0.9  # lower bound of cpu utilization of coldRP list
COLD_CPU_TS = 0.8  # upper bound of cpu utilization of coldRP list
BALANCE_RATIO = 1.0 # r1:r2 that considered to be balance
DISTANCE = 0.25  # abs((real_ratio - BALANCE_RATIO)/BALANCE_RATIO) distance
TRAIT1 = ['A', 'a']
TRAIT2 = ['B', 'b']
WINDOW = 2000
PRIOR_STEP = 10# prior_step
THRESH = 0.2 #thresh
ALPHA = [0.8]*8  #alpha
FIX_ALPHA = 0.8


class RandomAllocation(unittest.TestCase):

    @classmethod
    def setUpClass(cls): #通过URL获得数据
        sys.path.append(os.path.dirname(os.path.abspath(__file__)) + r'\..')  # 返回脚本的路径
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                            datefmt='%a, %d %b %Y %H:%M:%S',
                            filename='log/log_test.log',
                            filemode='w')
        cls.logger = logging.getLogger()#获取日志实例，返回根日志

        cls.logPath = "D:/PycharmProject/CloudVM_Client/log"
        if not os.path.exists(cls.logPath):
            os.mkdir(cls.logPath)

        # cls.baseURL = "http://127.0.0.1:8080/cloudvm/"
        cls.urlMap = {"ready": "environment/ready",
                      "finish": "environment/finish",
                      "halt": "environment/halt",
                      "restart": "environment/restart",
                      "allResource": "resource/all",
                      "runningResource": "resource/on",
                      "closedResource": "resource/off",
                      "turnOffResource": "resource/halt",
                      "turnOnResource": "resource/start",
                      "validResource": "resource/valid",
                      "getMission": "request/generate",
                      "sendAllocation": "request/allocate",
                      "transferVM": "request/transfer",
                      "allVirtualMachine": "request/all",
                      "requestSpecification":"request/specification",
                      "resourceSpecification":"resource/specification",
                      "VIPIds":"environment/VIPUserID",
                      "VMinPM":"request/inResource"}
        cls.HttpStatus = {"OK":200,
                          "NotReady":202,
                          "Refuse":403}
#每台PM的VM放置情况
    def getVMinPM(self, PM):
        try:
            url = self.baseURL + self.urlMap["VMinPM"]  #[""]?  84行？
            req = urllib.request.Request(url, PM.SerializeToString(),#序列到串的函数？
                                         {'Content-Type': 'application/x-protobuf'})
            req.get_method = lambda: "GET"
            res = urllib.request.urlopen(req)
            rrpList = Data.ResourceRequestListProto()#26行引入库
            rrpList.ParseFromString(res.read())
            # return rrpList
            print(rrplist)
        except Exception as e:
            print(e)
if __name__ == '__main__':

    RandomAllocation.getVMinPM(6)


#获得RP规格CUP:MEM配比   1:1；
    def getResourceSpecfication(self):
        try:
            url = self.baseURL + self.urlMap["resourceSpecification"]#82行
            res = urllib.request.urlopen(url)
            resSpecListProto = Data.SpecificationListProto()
            resSpecListProto.ParseFromString(res.read())#从串解析
            return resSpecListProto
        except Exception as err:
            print(err)
#获得request规格，request的大小
    def getRequestSpecfication(self):
        try:
            url = self.baseURL + self.urlMap["requestSpecification"]
            res = urllib.request.urlopen(url)
            reqSpecListProto = Data.SpecificationListProto()
            reqSpecListProto.ParseFromString(res.read())
            return reqSpecListProto
        except Exception as err:
            print(err)
# #获得useIP,大用户
#     def getVIPIds(self):
#         try:
#             url = self.baseURL + self.urlMap["VIPIds"]#83
#             res = urllib.request.urlopen(url)
#             userIdList = Data.UserIdsProto()
#             userIdList.ParseFromString(res.read())
#             return userIdList
#         except Exception as e:
#             print(e)
# #停止函数，获取页面http://127.0.0.1:8080/cloudvm/environment/halt
#     def halt(self):
#         try:
#             url = self.baseURL + self.urlMap["halt"]#69行
#             urllib.request.urlopen(url)
#         except Exception as err:
#             print(err)
# #等待直到准备好
#     def waitUntilReady(self):
#         try:
#             response = urllib.request.urlopen(self.baseURL + self.urlMap["ready"])
#             while response.getcode() == self.HttpStatus["NotReady"]:
#                 time.sleep(5)
#                 response = urllib.request.urlopen(self.baseURL + self.urlMap["ready"])
#         except Exception as err:
#             print(err)
# #重启功能
#     def restart(self):
#         try:
#             url = self.baseURL + self.urlMap["restart"]
#             urllib.request.urlopen(url)
#         except Exception as err:
#             print(err)
# #完成任务
#     def finishMission(self):
#         try:
#             url = self.baseURL + self.urlMap["finish"]
#             urllib.request.urlopen(url)
#         except Exception as ee:
#             print(ee)
# #获得所有RP状况，运行的RP和关闭的RP？
#     def getAllResourceProviders(self):
#         url = self.baseURL + self.urlMap["allResource"]
#         try:
#             res = urllib.request.urlopen(url)
#             rpList = Data.ResourceProviderListProto()#？Data里面的函数？
#             rpList.ParseFromString(res.read())
#             return rpList
#         except Exception as err:
#             print(err)
# #获得运行的RP的状况,获取所有打开的运行中的RPs
#     def getRunningResourceProviders(self):
#         url = self.baseURL + self.urlMap["runningResource"]
#         try:
#             res = urllib.request.urlopen(url)#
#             rpList = Data.ResourceProviderListProto()
#             rpList.ParseFromString(res.read())
#             return rpList
#         except Exception as err:
#             print(err)
# #获得关闭的RP的状况
#     def getOffResourceProviders(self):
#         url = self.baseURL + self.urlMap["closedResource"]
#         try:
#             res = urllib.request.urlopen(url)
#             rpList = Data.ResourceProviderListProto()
#             rpList.ParseFromString(res.read())
#             return rpList
#         except Exception as err:
#             print(err)
# #
#     def turnOffResourceProviderList(self, rpList):
#         url = self.baseURL + self.urlMap["turnOffResource"]
#         try:
#             #   将需要关闭的rplist包装到请求，然后发送到页面resource/halt
#             #   执行关机操作
#             request = urllib.request.Request(url, rpList.SerializeToString(), {'Content-Type': 'application/x-protobuf'})#？request函数？
#             request.get_method = lambda: "PUT"# ?lambda什么意思？
#             urllib.request.urlopen(request)
#         except Exception as err:
#             print(err)
# #
#     def turnOnResourceProviderList(self, rpList):
#         url = self.baseURL + self.urlMap["turnOnResource"]
#         try:
#             #将需要开启的rplist包装到请求，然后发送到页面resource/start
#             # 执行开机操作
#             request = urllib.request.Request(url, rpList.SerializeToString(), {'Content-Type': 'application/x-protobuf'})
#             #      前面定义的
#             #      rpList=Data.ResourceProviderListProto()   ？
#             request.get_method = lambda: "PUT"
#             urllib.request.urlopen(request)
#         except Exception as err:
#             print(err)
#     #    获得有效的RP,满足一个VM的所有可用的RPlist？
#     def getValidResourceProviders(self, resourceRequest):
#         url = self.baseURL + self.urlMap["validResource"]
#         try:
#              #     request,Request()?
#            #将一个资源请求resourceRequest包装到请求，发送到页面resource/valid，
#            #  接收返回的该请求的可用RP的列表
#             req = urllib.request.Request(url, resourceRequest.SerializeToString(),
#                                          {'Content-Type': 'application/x-protobuf'})
#             req.get_method = lambda: "GET"
#             response = urllib.request.urlopen(req)
#             rpList = Data.ResourceProviderListProto()
#             rpList.ParseFromString(response.read())
#             return rpList
#         except Exception as err:
#             print(err)
#     #获得任务（未分配的resourcerequest）  获取页面request/generate返回的任务列表rrList
#     #  获取每一轮的任务
#     def getMission(self):
#         try:
#             url = self.baseURL + self.urlMap["getMission"]
#             response = urllib.request.urlopen(url)
#             rrList = Data.ResourceRequestListProto()     #获得ResourceRequestList
#             rrList.ParseFromString(response.read())
#             return rrList
#         except Exception as e:
#             print(e)
#    #发送放置一次调度后的结果  request请求分配
#     def sendAllocation(self, rrList):
#         try:
#             url = self.baseURL + self.urlMap["sendAllocation"]
#             #rrList是上面定义的吗？
#             #将放置信息rrList包装到请求，发送到页面request/allocate
#             # 发送当前的分配决策
#             req = urllib.request.Request(url, rrList.SerializeToString(),
#                                          {'Content-Type': 'application/x-protobuf'})
#             req.get_method = lambda: "PUT"
#             urllib.request.urlopen(req)
#         except Exception as e:
#             print(e)
#     #随机分配   如何随机？
#     def randomAllocate(self, rrList):
#         try:
#             #对于rrList中的每一个请求，调用getValidResourceProviders()函数，得到候选RP列表，然后从中随机选一个
#             for rr in rrList.resourceRequestProto:
#                 rpList = self.getValidResourceProviders(rr)     #rpList资源放置列表    ？
#                 rpSize = len(rpList.resourceProviderProto)
#                 if (rpSize == 0):
#                     continue
#                     #如何随机？
#                 rand = np.random.randint(0, rpSize, 1)    #随机找到的RP的下标
#                 rr.rpId = rpList.resourceProviderProto[rand[0]].id     #rpId
#         except Exception as e:
#             print(e)
#    #获得所有VM （request） 获取页面request/all返回的rrList,所有VMs的列表
#    # 获取当前所有已经分配的虚拟机
#     def getAllVirtualMachine(self):
#         try:
#             url = self.baseURL + self.urlMap["allVirtualMachine"]
#             response = urllib.request.urlopen(url)
#             rrList = Data.ResourceRequestListProto()
#             rrList.ParseFromString(response.read())
#             return rrList
#         except Exception as e:
#             print(e)
#
#     #转移虚拟机的决策  ，二次调度后的结果发送到平台
#     def transferVirtualMachine(self, rrList):
#         try:
#             url = self.baseURL + self.urlMap["transferVM"]
#             #  将rrList包装到请求，发送到页面request/transfer
#             req = urllib.request.Request(url, rrList.SerializeToString(),
#                                          {'Content-Type': 'application/x-protobuf'})
#             req.get_method = lambda: "PUT"
#             urllib.request.urlopen(req)
#         except Exception as e:
#             print(e)
#
#
#
#
#     #给RP排序  ，从最冷的机器到最热的机器
#     def sortRPs(self,rpList):
#         rpDict = {}
#         for i in range(0, len(rpList)):
#             rpId = rpList.resourceProviderProto[i].id       #获得rpId
#             resource1 = float(rpList.resourceProviderProto[i].resource1)
#             resource2 = float(rpList.resourceProviderProto[i].resource2)
#             rpDict[rpId] = (resource1 + resource2)/2  # or with other way to count a sorter
#             #按几种资源的平均占用量排序
#         sortedRPs = sorted(rpDict.items(), key = lambda x:x[1], reverse=True)
#         return sortedRPs
          #resourcerequest排序
    def sortReqs(self, rrList, requestSpecificationList):
        rrDict = {}
        for i in range(0, len(rrList)):  #rrList只是大户或散户
            rrId = rrList.resourceRequestProto[i].id
            #定义的findRequestSpecification函数？
            resource = self.findRequestSpecification(rrList.resourceRequestProto[i].requestSpecification, requestSpecificationList)
            rrDict[rrId] = (resource[0] + resource[1])/2  # or with other way to count a sorter
        sortedReqs = sorted(rrDict.items(), key = lambda x:x[1], reverse=False)  # from small to large
        return sortedReqs
#   #找到已分配request的指定的RPid
#     def findRPindex(self,RPId,rpList):
#         for i in range(0, len(rpList)):
#             if rpList.resourceProviderProto[i].id == RPId:     #判断条件怎么理解？
#                 return i
#    #找到VM索引
#     def findVMindex(self,VMId,rrList):
#         for i in range(0, len(rrList)):
#             if rrList.resourceRequestProto[i].id == VMId:
#                 return i
#      #移除SRCRP?
#     def removeSRCRP(self, srcrp_id, valid_rpList):
#         for rp in valid_rpList.resourceProviderProto:
#             if rp.id == srcrp_id:
#                 valid_rpList.resourceProviderProto.remove(rp)
#                 break
#     #没看懂
#     def delta_dist(self, r1, r2, vmr_1, vmr_2):
#         # if src vmr is + ,if des vmr is -
#         # dist_aft - dist_bfo
#         result = ((r1+vmr_1)/(r2+vmr_2)-BALANCE_RATIO)/BALANCE_RATIO - (r1/r2-BALANCE_RATIO)/BALANCE_RATIO
#         return result
#     #查询到匹配的RP,找到trait相匹配的RP
#     def findMatchRP(self, rpList, trait1, trait2, src_id):
#         matchList = Data.ResourceProviderListProto()
#         for rp in rpList.resourceProviderProto:
#             if rp.trait1 == trait1 and rp.trait2 == trait2 and rp.id != src_id:  #    id条件？
#                 matchList.resourceProviderProto.append(rp)
#         return matchList
#    #找到Resource规范，返回用户id（大户或散户）和请求的资源类型
#     def findResourceSpecification(self, resSpecification, resourceSpecificationList):
#         for s in resourceSpecificationList:
#             if s.id == resSpecification:
#                 return [s.resource1, s.resource2]
#    #和上面的一样？
#     def findRequestSpecification(self, reqSpecification, requestSpecificationList):
#         for s in requestSpecificationList:
#             if s.id == reqSpecification:
#                 return [s.resource1, s.resource2]
#    #找到最优放置
#     def findBest(self, opi, rrList, rpList, vmListDit, vm_id, requestSpecificationList, resourceSpecificationList):
#         if opi == 0:
#             return self.findBestShift(rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList)
#         elif opi == 1:
#             return self.findBestSwap(rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList)
#         else:
#             return self.findBestReplace(rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList)
#      #最佳的Shift
#     def findBestShift(self, rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList):
#         # find best placement based on best_rrList,with only one shift move
#         vm_i = self.findVMindex(vm_id, rrList)
#         srcrp_id = rrList.resourceRequestProto[vm_i].rpId
#         src_i = self.findRPindex(srcrp_id, rpList)  # src rp index in rand_rpList
#         candi_vm_i = -1  # in rrList
#         candi_des_i = -1
#         candi_best_cost = float('inf')
#         src_vmlist = vmListDit[srcrp_id]
#         for i in range(0, len(src_vmlist)):
#             v_id = src_vmlist[i].id
#             v_i = self.findVMindex(v_id, rrList)
#             validRP = self.getValidResourceProviders(rrList.resourceRequestProto[v_i])
#             self.removeSRCRP(rpList.resourceProviderProto[src_i].id, validRP)
#             sortedValidRP = self.sortRPs(validRP)  # [('ip', sorter),(),(),...]
#             for j in range(len(sortedValidRP)-1, -1, -1):
#                 des_i = self.findRPindex(sortedValidRP[j][0], rpList)  # des index in rpList
#                 des_rt = self.findResourceSpecification(rpList.resourceProviderProto[des_i].resourceSpecification, resourceSpecificationList)
#                 src_rt = self.findResourceSpecification(rpList.resourceProviderProto[src_i].resourceSpecification, resourceSpecificationList)
#                 vm_r = self.findRequestSpecification(rrList.resourceRequestProto[v_i].requestSpecification, requestSpecificationList)
#                 src_r1 = rpList.resourceProviderProto[src_i].resource1
#                 src_r2 = rpList.resourceProviderProto[src_i].resource2
#                 des_r1 = rpList.resourceProviderProto[des_i].resource1
#                 des_r2 = rpList.resourceProviderProto[des_i].resource2
#                 des_cpu_uti = 1 - float(des_r1+des_r2)/(des_rt[0]+des_rt[1])
#                 if des_cpu_uti > HOT_CPU_TS:
#                     continue
#                 delta_mCost = 0.5*(vm_r[0] + vm_r[1])
#                 src_delta_bCost = abs(float(src_r1 + vm_r[0]) / (src_r2 + vm_r[1]) - BALANCE_RATIO) - abs(float(src_r1) / src_r2 - BALANCE_RATIO)
#                 des_delta_bCost = abs(float(des_r1 - vm_r[0]) / (des_r2 - vm_r[1]) - BALANCE_RATIO) - abs(float(des_r1) / des_r2 - BALANCE_RATIO)
#                 delta_bCost = src_delta_bCost + des_delta_bCost
#                 delta_cost = MCOST_COEFFICIENT*delta_mCost + BCOST_COEFFICIENT*delta_bCost
#                 if delta_cost < candi_best_cost:
#                     candi_vm_i = v_i
#                     candi_des_i = des_i
#                     candi_best_cost = delta_cost
#         if candi_best_cost == float('inf'):
#             return 0
#         else:
#             # update
#             rrList.resourceRequestProto[candi_vm_i].rpId = candi_des_i
#             rpList.resourceProviderProto[src_i].resource1 += rrList.resourceRequestProto[candi_vm_i].resource1
#             rpList.resourceProviderProto[src_i].resource2 += rrList.resourceRequestProto[candi_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[src_i].id].remove(rrList.resourceRequestProto[candi_vm_i])
#             rpList.resourceProviderProto[candi_des_i].resource1 -= rrList.resourceRequestProto[candi_vm_i].resource1
#             rpList.resourceProviderProto[candi_des_i].resource2 -= rrList.resourceRequestProto[candi_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[candi_des_i].id].append(rrList.resourceRequestProto[candi_vm_i])
#             return candi_best_cost
#
#     def findBestSwap(self, rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList):
#         # find best placement based on best_rrList,with only one shift move
#         vm_i = self.findVMindex(vm_id, rrList)
#         srcrp_id = rrList.resourceRequestProto[vm_i].rpId
#         src_i = self.findRPindex(srcrp_id, rpList)  # src rp index in rand_rpList
#         candi_src_vm_i = -1  # in rrList
#         candi_des_i = -1
#         candi_des_vm_i = -1
#         candi_best_cost = float('inf')
#         src_vmlist = vmListDit[srcrp_id]
#         for i in range(0, len(src_vmlist)):
#             src_v_id = src_vmlist[i].id
#             src_v_i = self.findVMindex(src_v_id, rrList)
#             # validRP = self.getValidResourceProviders(rrList.resourceRequestProto[src_v_i])
#             # self.removeSRCRP(rpList.resourceProviderProto[src_i].id, validRP)
#             # sortedValidRP = self.sortRPs(validRP)  # [('ip', sorter),(),(),...]
#             sortedRP = self.sortRPs(rpList)  # [('ip', sorter),(),(),...]
#             for j in range(len(sortedRP)-1, -1, -1):
#                 des_i = self.findRPindex(sortedRP[j][0], rpList)  # des index in rpList
#                 if des_i == src_i:
#                     continue
#                 des_rt = self.findResourceSpecification(rpList.resourceProviderProto[des_i].resourceSpecification, resourceSpecificationList)
#                 src_rt = self.findResourceSpecification(rpList.resourceProviderProto[src_i].resourceSpecification, resourceSpecificationList)
#                 src_vm_r = self.findRequestSpecification(rrList.resourceRequestProto[src_v_i].requestSpecification, requestSpecificationList)
#                 src_r1 = rpList.resourceProviderProto[src_i].resource1
#                 src_r2 = rpList.resourceProviderProto[src_i].resource2
#                 des_r1 = rpList.resourceProviderProto[des_i].resource1
#                 des_r2 = rpList.resourceProviderProto[des_i].resource2
#                 des_cpu_uti = 1 - float(des_r1+des_r2)/(des_rt[0]+des_rt[1])
#                 if des_cpu_uti < COLD_CPU_TS:
#                     continue
#                 des_vmlist = vmListDit[sortedRP[j][0]]
#                 for k in range(0, len(des_vmlist)):
#                     des_v_id = des_vmlist[k].id
#                     des_v_i = self.findVMindex(des_v_id, rrList)
#                     des_vm_r = self.findRequestSpecification(rrList.resourceRequestProto[des_v_i].requestSpecification, requestSpecificationList)
#                     src_r1_try = src_r1 + src_vm_r[0] - des_vm_r[0]
#                     src_r2_try = src_r2 + src_vm_r[1] - des_vm_r[1]
#                     des_r1_try = des_r1 + des_vm_r[0] - src_vm_r[0]
#                     des_r2_try = des_r2 + des_vm_r[1] - src_vm_r[1]
#                     if src_r1_try>0 and src_r2_try>0 and des_r1_try>0 and des_r2_try>0:
#                         delta_mCost = 0.5*(src_vm_r[0] + src_vm_r[1] + des_vm_r[0] + des_vm_r[1])
#                         # src_delta_bCost = abs(float(src_r1 + src_vm_r[0]) / (src_r2 + src_vm_r[1]) - BALANCE_RATIO) - abs(float(src_r1) / src_r2 - BALANCE_RATIO)
#                         src_delta_bCost = self.delta_dist(src_r1,src_r2,src_vm_r[0]-des_vm_r[0],src_vm_r[1]-des_vm_r[1])
#                         des_delta_bCost = self.delta_dist(des_r1,des_r2,des_vm_r[0]-src_vm_r[0],des_vm_r[1]-src_vm_r[1])
#                         delta_bCost = src_delta_bCost + des_delta_bCost
#                         delta_cost = MCOST_COEFFICIENT*delta_mCost + BCOST_COEFFICIENT*delta_bCost
#                         if delta_cost < candi_best_cost:
#                             candi_src_vm_i = src_v_i
#                             candi_des_i = des_i
#                             candi_des_vm_i = des_v_i
#                             candi_best_cost = delta_cost
#         if candi_best_cost == float('inf'):
#             return 0
#         else:
#             # update
#             rrList.resourceRequestProto[candi_src_vm_i].rpId = candi_des_i
#             rrList.resourceRequestProto[candi_des_vm_i].rpId = src_i
#             rpList.resourceProviderProto[src_i].resource1 += rrList.resourceRequestProto[candi_src_vm_i].resource1
#             rpList.resourceProviderProto[src_i].resource2 += rrList.resourceRequestProto[candi_src_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[src_i].id].remove(rrList.resourceRequestProto[candi_src_vm_i])
#             vmListDit[rpList.resourceProviderProto[src_i].id].append(rrList.resourceRequestProto[candi_des_vm_i])
#             rpList.resourceProviderProto[candi_des_i].resource1 -= rrList.resourceRequestProto[candi_src_vm_i].resource1
#             rpList.resourceProviderProto[candi_des_i].resource2 -= rrList.resourceRequestProto[candi_src_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[candi_des_i].id].remove(rrList.resourceRequestProto[candi_des_vm_i])
#             vmListDit[rpList.resourceProviderProto[candi_des_i].id].append(rrList.resourceRequestProto[candi_src_vm_i])
#             return candi_best_cost
#
#     def findBestReplace(self, rrList, rpList, vm_id, vmListDit, requestSpecificationList, resourceSpecificationList):
#         # find best placement based on best_rrList,with only one shift move
#         vm_i = self.findVMindex(vm_id, rrList)
#         rp1_id = rrList.resourceRequestProto[vm_i].rpId
#         rp1_i = self.findRPindex(rp1_id, rpList)  # src rp index in rand_rpList
#         candi_rp1_vm_i = -1  # in rrList
#         candi_rp2_i = -1
#         candi_rp2_vm_i = -1
#         candi_rp3_i = -1
#         candi_best_cost = float('inf')
#         rp1_vmlist = vmListDit[rp1_id]
#         for i in range(0, len(rp1_vmlist)):
#             rp1_v_id = rp1_vmlist[i].id
#             rp1_v_i = self.findVMindex(rp1_v_id, rrList)
#             # validRP = self.getValidResourceProviders(rrList.resourceRequestProto[src_v_i])
#             # self.removeSRCRP(rpList.resourceProviderProto[src_i].id, validRP)
#             # sortedValidRP = self.sortRPs(validRP)  # [('ip', sorter),(),(),...]
#             sortedRP2 = self.sortRPs(rpList)  # [('ip', sorter),(),(),...]
#             for j in range(len(sortedRP2)-1, -1, -1):
#                 rp2_i = self.findRPindex(sortedRP2[j][0], rpList)  # des index in rpList
#                 rp2_rt = self.findResourceSpecification(rpList.resourceProviderProto[rp2_i].resourceSpecification, resourceSpecificationList)
#                 rp1_rt = self.findResourceSpecification(rpList.resourceProviderProto[rp1_i].resourceSpecification, resourceSpecificationList)
#                 rp1_vm_r = self.findRequestSpecification(rrList.resourceRequestProto[rp1_v_i].requestSpecification, requestSpecificationList)
#                 rp1_r1 = rpList.resourceProviderProto[rp1_i].resource1
#                 rp1_r2 = rpList.resourceProviderProto[rp1_i].resource2
#                 rp2_r1 = rpList.resourceProviderProto[rp2_i].resource1
#                 rp2_r2 = rpList.resourceProviderProto[rp2_i].resource2
#                 rp2_cpu_uti = 1 - float(rp2_r1+rp2_r2)/(rp2_rt[0]+rp2_rt[1])
#                 if rp2_cpu_uti < COLD_CPU_TS:
#                     continue
#                 rp2_vmlist = vmListDit[sortedRP2[j][0]]
#                 for k in range(0, len(rp2_vmlist)):
#                     rp2_v_id = rp2_vmlist[k].id
#                     rp2_v_i = self.findVMindex(rp2_v_id, rrList)
#                     rp2_vm_r = self.findRequestSpecification(rrList.resourceRequestProto[rp2_v_i].requestSpecification, requestSpecificationList)
#                     validRP3 = self.getValidResourceProviders(rrList.resourceRequestProto[rp2_v_i])
#                     self.removeSRCRP(rpList.resourceProviderProto[rp1_i].id, validRP3)
#                     self.removeSRCRP(rpList.resourceProviderProto[rp2_i].id, validRP3)
#                     sortedValidRP3 = self.sortRPs(validRP3)  # [('ip', sorter),(),(),...]
#                     # sortedRP3 = self.sortRPs(rpList)  # [('ip', sorter),(),(),...]
#                     for l in range(0, len(sortedValidRP3)):
#                         rp3_i = self.findRPindex(sortedValidRP3[l][0], rpList)
#                         rp3_rt = self.findResourceSpecification(rpList.resourceProviderProto[rp3_i].resourceSpecification, resourceSpecificationList)
#                         rp2_vm_r = self.findRequestSpecification(rrList.resourceRequestProto[rp2_v_i].requestSpecification, requestSpecificationList)
#                         rp3_r1 = rpList.resourceProviderProto[rp3_i].resource1
#                         rp3_r2 = rpList.resourceProviderProto[rp3_i].resource2
#
#                         # rp1_r1_try = rp1_r1 + rp1_vm_r[0] - rp2_vm_r[0]
#                         # rp1_r2_try = rp1_r2 + rp1_vm_r[1] - rp2_vm_r[1]
#                         rp2_r1_try = rp2_r1 + rp2_vm_r[0] - rp1_vm_r[0]
#                         rp2_r2_try = rp2_r2 + rp2_vm_r[1] - rp1_vm_r[1]
#                         if rp2_r1_try>0 and rp2_r2_try>0:
#                             delta_mCost = 0.5*(rp1_vm_r[0] + rp1_vm_r[1] + rp2_vm_r[0] + rp2_vm_r[1])
#                             # src_delta_bCost = abs(float(src_r1 + src_vm_r[0]) / (src_r2 + src_vm_r[1]) - BALANCE_RATIO) - abs(float(src_r1) / src_r2 - BALANCE_RATIO)
#                             rp1_delta_bCost = self.delta_dist(rp1_r1,rp1_r2,rp1_vm_r[0],rp1_vm_r[1])
#                             rp2_delta_bCost = self.delta_dist(rp2_r1,rp2_r2,rp2_vm_r[0]-rp1_vm_r[0],rp2_vm_r[1]-rp1_vm_r[1])
#                             rp3_delta_bCost = self.delta_dist(rp3_r1, rp3_r2,-rp2_vm_r[0],-rp2_vm_r[1])
#                             delta_bCost = rp1_delta_bCost + rp2_delta_bCost + rp3_delta_bCost
#                             delta_cost = MCOST_COEFFICIENT*delta_mCost + BCOST_COEFFICIENT*delta_bCost
#                             if delta_cost < candi_best_cost:
#                                 candi_rp1_vm_i = rp1_v_i
#                                 candi_rp2_i = rp2_i
#                                 candi_rp2_vm_i = rp2_v_i
#                                 candi_rp3_i = rp3_i
#                                 candi_best_cost = delta_cost
#         if candi_best_cost == float('inf'):
#             return 0
#         else:
#             # update
#             rrList.resourceRequestProto[candi_rp1_vm_i].rpId = candi_rp2_i
#             rrList.resourceRequestProto[candi_rp2_vm_i].rpId = candi_rp3_i
#             rpList.resourceProviderProto[rp1_i].resource1 += rrList.resourceRequestProto[candi_rp1_vm_i].resource1
#             rpList.resourceProviderProto[rp1_i].resource2 += rrList.resourceRequestProto[candi_rp1_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[rp1_i].id].remove(rrList.resourceRequestProto[candi_rp1_vm_i])
#             # vmListDit[rpList.resourceProviderProto[rp1_i].id].append(rrList.resourceRequestProto[candi_rp2_vm_i])
#             rpList.resourceProviderProto[candi_rp2_i].resource1 += rrList.resourceRequestProto[candi_rp2_vm_i].resource1+rrList.resourceRequestProto[candi_rp1_vm_i].resource1
#             rpList.resourceProviderProto[candi_rp2_i].resource2 -= rrList.resourceRequestProto[candi_rp2_vm_i].resource2+rrList.resourceRequestProto[candi_rp1_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[candi_rp2_i].id].remove(rrList.resourceRequestProto[candi_rp2_vm_i])
#             vmListDit[rpList.resourceProviderProto[candi_rp2_i].id].append(rrList.resourceRequestProto[candi_rp1_vm_i])
#             rpList.resourceProviderProto[candi_rp3_i].resource1 -= rrList.resourceRequestProto[candi_rp2_vm_i].resource1
#             rpList.resourceProviderProto[candi_rp3_i].resource2 -= rrList.resourceRequestProto[candi_rp2_vm_i].resource2
#             vmListDit[rpList.resourceProviderProto[candi_rp3_i].id].append(rrList.resourceRequestProto[candi_rp2_vm_i])
#             return candi_best_cost
#
#     def shiftSearch(self, rrList, rpList, vm_id, requestSpecificationList, resourceSpecificationList,vmListDit):
#         # randomly choose s'/desrp
#         rand_rrList = rrList
#         rand_rpList = rpList
#         rand_vmListDict = vmListDit
#         vm_i = self.findVMindex(vm_id, rand_rrList)  # vm index in rand_rrList
#         srcrp_id = rrList.resourceRequestProto[vm_i].rpId
#         srcrp_i = self.findRPindex(srcrp_id, rand_rpList)  # src rp index in rand_rpList
#         # randomly choose des rp in valid_rpList
#         valid_rpList = self.getValidResourceProviders(rand_rrList.resourceRequestProto[vm_i])
#         self.removeSRCRP(srcrp_id, valid_rpList)  # remove src rp in valid_rpList
#         desrp_i = np.random.randint(0, len(valid_rpList)-1)  # in valid_rpList
#         desrp_id = valid_rpList.resourceProviderProto[desrp_i].id
#         desrp_i = self.findRPindex(desrp_id,rand_rpList)  # in rand_rpList
#         reqSpecification = self.findRequestSpecification(rand_rrList.resourceRequestProto[vm_i].requestSpecification, requestSpecificationList)
#         vm_r1 = reqSpecification[0]  # request
#         vm_r2 = reqSpecification[1]
#         src_r1 = rand_rpList.resourceProviderProto[srcrp_i].resource1
#         src_r2 = rand_rpList.resourceProviderProto[srcrp_i].resource2
#         des_r1 = rand_rpList.resourceProviderProto[desrp_i].resource1  # remain resource in des rp
#         des_r2 = rand_rpList.resourceProviderProto[desrp_i].resource2
#         # update rand_rrList, rand_rpList and vmListDict
#         rand_rrList.resourceRequestProto[vm_i].rpId = desrp_id
#         rand_rpList.resourceProviderProto[srcrp_i].resource1 += vm_r1  # remain
#         rand_rpList.resourceProviderProto[srcrp_i].resource2 += vm_r2
#         rand_vmListDict[srcrp_id].remove(rand_rrList.resourceRequestProto[vm_i])
#         rand_rpList.resourceProviderProto[desrp_i].resource1 -= vm_r1
#         rand_rpList.resourceProviderProto[desrp_i].resource2 -= vm_r2
#         rand_vmListDict[desrp_id].append(rand_rrList.resourceRequestProto[vm_i])
#         # count cost of s'/rand_rrList
#         mCost = 0.5 * (vm_r1 + vm_r2)
#         # bCost = abs(((src_r1+vm_r1)/(src_r2+vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)+abs(((des_r1-vm_r1)/(des_r2-vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)
#         bCost = self.delta_dist(src_r1, src_r2, vm_r1, vm_r2) + self.delta_dist(des_r1, des_r2, -vm_r1, -vm_r2)
#         rand_cost = MCOST_COEFFICIENT*mCost+BCOST_COEFFICIENT*bCost
#
#         # find local optimum s''/best_rrList
#         best_rrList = rand_rrList
#         best_rpList = rand_rpList
#         best_vmListDict = rand_vmListDict
#         opi = 0  # 0='shift', 1=swap', 2='replace'
#         k = 0
#         while k<5000:  # 5000 doesn't make sense
#             delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList, resourceSpecificationList)
#             if delta_cost < 0:
#                 # accept shift search
#                 rrList[:] = best_rrList
#                 rpList[:] = best_rpList
#                 vmListDit.clear()
#                 vmListDit.update(best_vmListDict)
#                 return rand_cost + delta_cost
#             else:
#                 opi += 1
#                 if opi > 2:
#                     return False
#                 best_rrList = rand_rrList
#                 best_rpList = rand_rpList
#                 best_vmListDict = rand_vmListDict
#             k += 1
#         return rand_cost
#
#     def swapSearch(self, rrList, rpList, vm_id, requestSpecificationList, resourceSpecificationList,vmListDit):
#         # randomly choose s'/desrp
#         rand_rrList = rrList
#         rand_rpList = rpList
#         rand_vmListDict = vmListDit
#         src_vm_i = self.findVMindex(vm_id, rand_rrList)  # vm index in rand_rrList
#         srcrp_id = rrList.resourceRequestProto[src_vm_i].rpId
#         srcrp_i = self.findRPindex(srcrp_id, rand_rpList)  # src rp index in rand_rpList
#         # randomly choose des rp and des vm
#         des_rpList = rand_rpList
#         self.removeSRCRP(srcrp_id, des_rpList)  # remove src rp in valid_rpList
#         desrp_i = np.random.randint(0, len(des_rpList)-1)  # in valid_rpList
#         desrp_id = des_rpList.resourceProviderProto[desrp_i].id
#         desrp_i = self.findRPindex(desrp_id,rand_rpList)  # in rand_rpList
#         src_vm_r = self.findRequestSpecification(rand_rrList.resourceRequestProto[src_vm_i].requestSpecification, requestSpecificationList)
#         src_r1 = rand_rpList.resourceProviderProto[srcrp_i].resource1
#         src_r2 = rand_rpList.resourceProviderProto[srcrp_i].resource2
#         des_r1 = rand_rpList.resourceProviderProto[desrp_i].resource1  # remain resource in des rp
#         des_r2 = rand_rpList.resourceProviderProto[desrp_i].resource2
#         des_vmList = rand_vmListDict[desrp_id]
#         des_vm_i = np.random.randint(0, len(des_vmList)-1)
#         des_vm_id = des_vmList[des_vm_i].id
#         des_vm_i = self.findVMindex(des_vm_id, rrList)
#         des_vm_r = self.findRequestSpecification(rand_rrList.resourceRequestProto[des_vm_i].requestSpecification, requestSpecificationList)
#         # update rand_rrList, rand_rpList and vmListDict
#         rand_rrList.resourceRequestProto[src_vm_i].rpId = desrp_id
#         rand_rrList.resourceRequestProto[des_vm_i].rpId = srcrp_id
#         rand_rpList.resourceProviderProto[srcrp_i].resource1 += src_vm_r[0] - des_vm_r[0]  # remain
#         rand_rpList.resourceProviderProto[srcrp_i].resource2 += src_vm_r[1] - des_vm_r[1]
#         rand_vmListDict[srcrp_id].remove(rand_rrList.resourceRequestProto[src_vm_i])
#         rand_vmListDict[srcrp_id].append(rand_rrList.resourceRequestProto[des_vm_i])
#         rand_rpList.resourceProviderProto[desrp_i].resource1 -= src_vm_r[0]
#         rand_rpList.resourceProviderProto[desrp_i].resource2 -= src_vm_r[1]
#         rand_vmListDict[desrp_id].remove(rand_rrList.resourceRequestProto[des_vm_i])
#         rand_vmListDict[desrp_id].append(rand_rrList.resourceRequestProto[src_vm_i])
#         # count cost of s'/rand_rrList
#         mCost = 0.5 * (src_vm_r[0] + src_vm_r[1] + des_vm_r[0] + des_vm_r[1])
#         # bCost = abs(((src_r1+vm_r1)/(src_r2+vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)+abs(((des_r1-vm_r1)/(des_r2-vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)
#         bCost = self.delta_dist(src_r1, src_r2, src_vm_r[0]-des_vm_r[0], src_vm_r[1]-des_vm_r[1]) + self.delta_dist(des_r1, des_r2, des_vm_r[0]-src_vm_r[0], des_vm_r[1]-src_vm_r[1])
#         rand_cost = MCOST_COEFFICIENT*mCost+BCOST_COEFFICIENT*bCost
#
#         # find local optimum s''/best_rrList
#         best_rrList = rand_rrList
#         best_rpList = rand_rpList
#         best_vmListDict = rand_vmListDict
#         opi = 0  # 0='shift', 1=swap', 2='replace'
#         k = 0
#         while k<5000:  # 5000 doesn't make sense
#             delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList, resourceSpecificationList)
#             if delta_cost < 0:
#                 # accept shift search
#                 rrList[:] = best_rrList
#                 rpList[:] = best_rpList
#                 vmListDit.clear()
#                 vmListDit.update(best_vmListDict)
#                 return rand_cost + delta_cost
#             else:
#                 opi += 1
#                 if opi > 2:
#                     return False
#                 best_rrList = rand_rrList
#                 best_rpList = rand_rpList
#                 best_vmListDict = rand_vmListDict
#             k += 1
#         return rand_cost
#
#     def replaceSearch(self, rrList, rpList, vm_id, requestSpecificationList, resourceSpecificationList, vmListDit):
#         # randomly choose s'/desrp
#         rand_rrList = rrList
#         rand_rpList = rpList
#         rand_vmListDict = vmListDit
#         rp1_vm_i = self.findVMindex(vm_id, rand_rrList)  # vm index in rand_rrList
#         rp1_id = rrList.resourceRequestProto[rp1_vm_i].rpId
#         rp1_i = self.findRPindex(rp1_id, rand_rpList)  # src rp index in rand_rpList
#         # randomly choose rp2 and rp2 vm and rp3
#         trait1 = rand_rpList.resourceProviderProto[rp1_i].trait1
#         trait2 = rand_rpList.resourceProviderProto[rp1_i].trait2
#         rp2_rpList = self.findMatchRP(rand_rpList, trait1, trait2, rp1_id)
#         rp2_i = np.random.randint(0, len(rp2_rpList) - 1)
#         rp2_id = rp2_rpList.resourceProviderProto[rp2_i].id
#         rp2_i = self.findRPindex(rp2_id, rand_rpList)
#         rp1_vm_r = self.findRequestSpecification(rand_rrList.resourceRequestProto[rp1_vm_i].requestSpecification,
#                                                  requestSpecificationList)
#         rp1_r1 = rand_rpList.resourceProviderProto[rp1_i].resource1
#         rp1_r2 = rand_rpList.resourceProviderProto[rp1_i].resource2
#         rp2_r1 = rand_rpList.resourceProviderProto[rp2_i].resource1  # remain resource in des rp
#         rp2_r2 = rand_rpList.resourceProviderProto[rp2_i].resource2
#         rp2_vmList = rand_vmListDict[rp2_id]
#         rp2_vm_i = np.random.randint(0, len(rp2_vmList) - 1)
#         rp2_vm_id = rp2_vmList[rp2_vm_i].id
#         rp2_vm_i = self.findVMindex(rp2_vm_id, rrList)
#         rp2_vm_r = self.findRequestSpecification(rand_rrList.resourceRequestProto[rp2_vm_i].requestSpecification,
#                                                  requestSpecificationList)
#         # update rand_rrList, rand_rpList and vmListDict
#         rand_rrList.resourceRequestProto[rp1_vm_i].rpId = rp2_id
#         rand_rrList.resourceRequestProto[rp2_vm_i].rpId = rp1_id
#         rand_rpList.resourceProviderProto[rp1_i].resource1 += rp1_vm_r[0] - rp2_vm_r[0]  # remain
#         rand_rpList.resourceProviderProto[rp1_i].resource2 += rp1_vm_r[1] - rp2_vm_r[1]
#         rand_vmListDict[rp1_id].remove(rand_rrList.resourceRequestProto[rp1_vm_i])
#         rand_vmListDict[rp1_id].append(rand_rrList.resourceRequestProto[rp2_vm_i])
#         rand_rpList.resourceProviderProto[rp2_i].resource1 -= rp1_vm_r[0]
#         rand_rpList.resourceProviderProto[rp2_i].resource2 -= rp1_vm_r[1]
#         rand_vmListDict[rp2_id].remove(rand_rrList.resourceRequestProto[rp2_vm_i])
#         rand_vmListDict[rp2_id].append(rand_rrList.resourceRequestProto[rp1_vm_i])
#         # count cost of s'/rand_rrList
#         mCost = 0.5 * (rp1_vm_r[0] + rp1_vm_r[1] + rp2_vm_r[0] + rp2_vm_r[1])
#         # bCost = abs(((src_r1+vm_r1)/(src_r2+vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)+abs(((des_r1-vm_r1)/(des_r2-vm_r2)-BALANCE_RATIO)/BALANCE_RATIO)
#         bCost = self.delta_dist(rp1_r1, rp1_r2, rp1_vm_r[0] - rp2_vm_r[0], rp1_vm_r[1] - rp2_vm_r[1]) + self.delta_dist(
#             rp2_r1, rp2_r2, rp2_vm_r[0] - rp1_vm_r[0], rp2_vm_r[1] - rp1_vm_r[1])
#         rand_cost = MCOST_COEFFICIENT * mCost + BCOST_COEFFICIENT * bCost
#
#         # find local optimum s''/best_rrList
#         best_rrList = rand_rrList
#         best_rpList = rand_rpList
#         best_vmListDict = rand_vmListDict
#         opi = 0  # 0='shift', 1=swap', 2='replace'
#         k = 0
#         while k < 5000:  # 5000 doesn't make sense
#             delta_cost = self.findBest(opi, best_rrList, best_rpList, best_vmListDict, vm_id, requestSpecificationList,
#                                        resourceSpecificationList)
#             if delta_cost < 0:
#                 # accept shift search
#                 rrList[:] = best_rrList
#                 rpList[:] = best_rpList
#                 vmListDit.clear()
#                 vmListDit.update(best_vmListDict)
#                 return rand_cost + delta_cost
#             else:
#                 opi += 1
#                 if opi > 2:
#                     return False
#                 best_rrList = rand_rrList
#                 best_rpList = rand_rpList
#                 best_vmListDict = rand_vmListDict
#             k += 1
#         return rand_cost
#
#     def rpList_turningoff(self, rpList, vmListDict):
#         off_rpList = Data.ResourceProviderListProto()
#         for i in range(0, len(rpList.resourceProviderProto)):
#             if len(vmListDict[rpList.resourceProviderProto[i].id]) == 0:
#                 off_rpList.resourceProviderProto.append(rpList.resourceProviderProto[i])
#         return off_rpList
#
#     def vnsBasedScheduler(self, ori_rrList, ori_rpList, resourceSpecificationList, requestSpecificationList, ori_vmListDict):
#         rpList = ori_rpList
#         rrList = ori_rrList
#         vmListDict = ori_vmListDict
#         try:
#             sortedRP = self.sortRPs(ori_rpList)  # [('ip', sorter),(),(),...]
#             for i in range(0, len(sortedRP)):
#                 pre_rpList = rpList
#                 pre_rrList = rrList
#                 pre_vmListDict = vmListDict
#                 rp_id = sortedRP[i][0]
#                 rp_i = self.findRPindex(rp_id, rpList)  # src rp index in rpList
#                 resource1 = rpList.resourceProviderProto[rp_i].resource1
#                 resSpecification = self.findResourceSpecification(rpList.resourceProviderProto[rp_i].resourceSpecification, resourceSpecificationList)
#                 resource1_t = resSpecification[0]
#                 if float(resource1)/resource1_t > COLD_CPU_TS:
#                     break
#                 vm_tcost = 0
#                 for vm in vmListDict[rp_id]:
#                     best_cost = float('inf')
#                     best_move = 0
#                     shift_rrList = pre_rrList
#                     shift_rpList = pre_rpList
#                     shift_vmListDict = pre_vmListDict
#                     swap_rrList = pre_rrList
#                     swap_rpList = pre_rpList
#                     swap_vmListDict = pre_vmListDict
#                     replace_rrList = pre_rrList
#                     replace_rpList = pre_rpList
#                     replace_vmListDict = pre_vmListDict
#                     T = 0
#                     while T < 2000:
#                         shift_cost = self.shiftSearch(shift_rrList, shift_rpList, vm.id, requestSpecificationList, resourceSpecificationList, shift_vmListDict)
#                         swap_cost =  self.swapSearch(swap_rrList, swap_rpList, vm.id, requestSpecificationList, resourceSpecificationList, swap_vmListDict)
#                         replace_cost = self.replaceSearch(replace_rrList, replace_rpList, vm.id, requestSpecificationList, resourceSpecificationList, replace_vmListDict)
#                         if shift_cost < best_cost:
#                             best_cost = shift_cost
#                             best_move = 0
#                         if swap_cost < best_cost:
#                             best_cost = swap_cost
#                             best_move = 1
#                         if replace_cost < best_cost:
#                             best_cost = replace_cost
#                             best_move = 2
#                         if best_move == 0:
#                             vm_tcost += shift_cost
#                             swap_rrList = shift_rrList
#                             swap_rpList = shift_rpList
#                             swap_vmListDict = shift_vmListDict
#                             replace_rrList = shift_rrList
#                             replace_rpList = shift_rpList
#                             replace_vmListDict = shift_vmListDict
#                         elif best_move == 1:
#                             vm_tcost += swap_cost
#                             shift_rrList = swap_rrList
#                             shift_rpList = swap_rpList
#                             shift_vmListDict = swap_vmListDict
#                             replace_rrList = swap_rrList
#                             replace_rpList = swap_rpList
#                             replace_vmListDict = swap_vmListDict
#                         elif best_move == 2:
#                             vm_tcost += replace_cost
#                             shift_rrList = replace_rrList
#                             shift_rpList = replace_rpList
#                             shift_vmListDict = replace_vmListDict
#                             swap_rrList = replace_rrList
#                             swap_rpList = replace_rpList
#                             swap_vmListDict = replace_vmListDict
#                     if best_move == 0:
#                         pre_rrList = shift_rrList
#                         pre_rpList = shift_rpList
#                         pre_vmListDict = shift_vmListDict
#                     elif best_move == 1:
#                         pre_rrList = swap_rrList
#                         pre_rpList = swap_rpList
#                         pre_vmListDict = swap_vmListDict
#                     elif best_move == 2:
#                         pre_rrList = replace_rrList
#                         pre_rpList = replace_rpList
#                         pre_vmListDict = replace_vmListDict
#                 if vm_tcost < RP_CHARGE:
#                     rpList = pre_rpList
#                     rrList = pre_rrList
            return self.rpList_turningoff(rpList, vmListDict)
#         except Exception as e:
#             print(e)
#
#     def updateByTrait(self, res, trait1, trait2, r1, r2):
#         if trait1 == TRAIT1[0] and trait2 == TRAIT2[0]:  # AB
#             res[0][0] += r1
#             res[0][1] += r2
#         elif trait1 == TRAIT1[0] and trait2 == TRAIT2[1]:  # Ab
#             res[1][0] += r1
#             res[1][1] += r2
#         elif trait1 == TRAIT1[1] and trait2 == TRAIT2[0]:  # aB
#             res[2][0] += r1
#             res[2][1] += r2
#         elif trait1 == TRAIT1[1] and trait2 == TRAIT2[1]:  # ab
#             res[3][0] += r1
#             res[3][1] += r2
#
    # def TotalResUsed(self, on_rp, resourceSpecificationList):
    #     res = [[0, 0], [0, 0], [0, 0], [0, 0]]  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
    #     for rp in on_rp.resourceProviderProto:
    #         resource = self.findResourceSpecification(rp.resourceSpecification, resourceSpecificationList)
    #         resource1_t = resource[0]
    #         resource2_t = resource[1]
    #         self.updateByTrait(res, rp.trait1, rp.trait2, resource1_t - rp.resource1, resource2_t - rp.resource2)
    #     return res
#
#     def TotalResRem(self, on_rp):
#         res = [[0, 0], [0, 0], [0, 0], [0, 0]]  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
#         for rp in on_rp.resourceProviderProto:
#             self.updateByTrait(res, rp.trait1, rp.trait2, rp.resource1, rp.resource2)
#         return res
#
#     def separateList(self, mixList):
#         r1_AB = []
#         r1_Ab = []
#         r1_aB = []
#         r1_ab = []
#         r2_AB = []
#         r2_Ab = []
#         r2_aB = []
#         r2_ab = []
#         for res_used in mixList:  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
#             r1_AB.append(res_used[0][0])
#             r1_Ab.append(res_used[1][0])
#             r1_aB.append(res_used[2][0])
#             r1_ab.append(res_used[3][0])
#             r2_AB.append(res_used[0][1])
#             r2_Ab.append(res_used[1][1])
#             r2_aB.append(res_used[2][1])
#             r2_ab.append(res_used[3][1])
#         return [r1_AB, r1_Ab, r1_aB, r1_ab, r2_AB, r2_Ab, r2_aB, r2_ab]
#
#     def predictR(self, R_LIST, CHANGE_P):
#         l = len(R_LIST)
#         lists = self.separateList(R_LIST)  # [r1_AB, r1_Ab, r1_aB, r1_ab, r2_AB, r2_Ab, r2_aB, r2_ab]
#         result = [[0,0], [0,0], [0,0], [0,0]]
#         for i in range(0, len(lists)):
#             if len(lists[i]) > WINDOW:
#                 lists[i] = lists[i][-WINDOW:]
#             if predict.is_change_point(lists[i], PRIOR_STEP, THRESH):
#                 CHANGE_P[i] = l-1
#                 ALPHA[i] = 1.0
#             elif ALPHA[i] > FIX_ALPHA:
#                 ALPHA[i] -= 0.1
#             result[i//2][i%2] = predict.ewma(lists[i][CHANGE_P[i]:], ALPHA[i])
#         return result
#
#     def predict_next(self):
#         # get historical r_pre and r_aft list from file
#         # next(k-1) = r_aft(k-1) - r_pre(k-1)
#
#     def listMinus(self, bfo_k, aft_k_1):
#         result = []
#         for i in range(0,len(bfo_k)):
#             result.append([bfo_k[i][j] - aft_k_1[i][j] for j in range(len(bfo_k[i]))])
#         return result
#
#     def listPlus(self, bfo_k, aft_k_1):
#         result = []
#         for i in range(0,len(bfo_k)):
#             result.append([bfo_k[i][j] + aft_k_1[i][j] for j in range(len(bfo_k[i]))])
#         return result
#
#     def ifAllBigerThan0(self, delta_r):
#         for i in range(0, len(delta_r)):
#             for j in range(0, len(delta_r[i])):
#                 if delta_r[i][j] <= 0:
#                     return False
#         return True
#
#     def ifAnySmallerThan0(self, delta_r):
#         for i in range(0, len(delta_r)):
#             for j in range(0, len(delta_r[i])):
#                 if delta_r[i][j] <= 0:
#                     return True
#         return False
#
#     def getvmLists(self, on_rp):
#         vmListDit = {}
#         for rp in on_rp.resourceProviderProto:
#             vmListDit[rp.id] = self.getVMinPM(rp.id).resourceRequestProto
#         return vmListDit
#
#     def separateRequest(self, rrList, vipIDs):
#         retail_request = Data.ResourceRequestListProto()
#         vip_request = Data.ResourceRequestListProto()
#         for r in rrList.resourceRequestProto:
#             if r.userId in vipIDs.userIdsProto:
#                 vip_request.resourceRequestProto.append(r)
#             else:
#                 retail_request.resourceRequestProto.append(r)
#         return retail_request, vip_request
#
#     def firstPlacement(self, rrList, rpList, requestSpecificationList, vmListDit):
#         vipIDs = self.getVIPIds()
#         retail_request, vip_request = self.separateRequest(rrList, vipIDs)
#         sorted_retail_request = self.sortReqs(retail_request, requestSpecificationList)  # [('ip', sorter),(),(),...]
#         sorted_vip_request = self.sortReqs(vip_request, requestSpecificationList)
#         sorted_request = sorted_vip_request + sorted_retail_request
#         for i in range(0, len(sorted_request)):
#             r_id = sorted_request[i][0]
#             r_i = self.findVMindex(r_id, rrList)  # request index in rrList
#             valid_rps = self.getValidResourceProviders(rrList.resourceRequestProto[r_i])
#             sorted_rps = self.sortRPs(valid_rps)
#             candi_rp_id = sorted_rps[len(sorted_rps)-1]  # place on hotter rp
#             candi_rp_i = self.findRPindex(candi_rp_id,rpList)  # candi rp index in rpList
#             # update
#             rrList.resourceRequestProto[r_i].rpId = candi_rp_id
#             vmListDit[candi_rp_id].append(rrList.resourceRequestProto[r_i])
#             r1 = rrList.resourceRequestProto[r_i].resource1
#             r2 = rrList.resourceRequestProto[r_i].resource2
#             rpList.resourceProviderProto[candi_rp_i].resource1 -= r1
#             rpList.resourceProviderProto[candi_rp_i].resource2 -= r2
#
#     def test1(self):
#         self.halt()
#         self.restart()
#         self.waitUntilReady()
#
#         rp_on_list = self.getRunningResourceProviders()
#         rp_off_list = Data.ResourceProviderListProto()
#         rp_off_list.resourceProviderProto.extend(rp_on_list.resourceProviderProto[:200])
#         self.turnOffResourceProviderList(rp_off_list)
#
#         aft_k = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]  # resource used after placement in kth cycle
#         RELEASE_LIST = []
#         REQUEST_LIST = []
#         REL_CHANGE_P = [0, 0, 0, 0, 0, 0, 0, 0]
#         REQ_CHANGE_P = [0, 0, 0, 0, 0, 0, 0, 0]
#         for i in range(10):  # make first few cycle predicable
#             RELEASE_LIST.append([[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]])
#             REQUEST_LIST.append([[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]])
#
#         for i in range(5):  # 6 days = 8640 min = 1728 5min
#             resourceSpecificationList = self.getResourceSpecfication()
#             requestSpecificationList = self.getRequestSpecfication()
#             on_rp = self.getRunningResourceProviders()
#             vmListDit = self.getvmLists(on_rp)  # { 'id0':[vm1,vm2,...], 'id1':[vm3,vm4,...], ...  } notice it is vm instance  not vm_id
#             # resource used before placement in kth cycle
#             bfo_k = self.TotalResUsed(on_rp, resourceSpecificationList)  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
#
#             rrList = self.getMission()
#             # self.randomAllocate(rrList)
#             # first placement
#             self.firstPlacement(rrList, on_rp, requestSpecificationList, vmListDit)
#             self.sendAllocation(rrList)
#             self.finishMission()
#
#             # resource used after placement in (k-1)th cycle
#             aft_k_1 = aft_k  # when i=0 aft_k_1=0
#             aft_k = self.TotalResUsed(on_rp, resourceSpecificationList)
#
#             rrList = self.getAllVirtualMachine()
#             # trans_rrList = Data.ResourceRequestListProto()
#             # trans_rrList.resourceRequestProto.extend(rrList.resourceRequestProto[:10])
            #self.randomAllocate(rrList)
#             rp_ready_off = self.vnsBasedScheduler(rrList, on_rp, resourceSpecificationList, requestSpecificationList, vmListDit)
#             self.transferVirtualMachine(rrList)
#
#             # predict rp_on_list
#             RELEASE_LIST.append(self.listMinus(bfo_k, aft_k_1))  # RELEASE_LIST[k] store resource released in cycle (k-1)th
#             REQUEST_LIST.append(self.listMinus(aft_k, bfo_k))  # REQUEST_LIST[k] store resource requested in cycle kth
#             release_k = self.predictR(RELEASE_LIST, REL_CHANGE_P)  # resource will be released in this cycle
#             req_kp1 = self.predictR(REQUEST_LIST, REQ_CHANGE_P)  # resource needed in next cycle
#
#             delta_r = self.listMinus(self.listPlus(release_k, remain_k), req_kp1)
            if self.ifAllBigerThan0(delta_r):
                # select some rps in rp_ready_off to turn off
                candi_off = Data.ResourceProviderListProto()
                for rp in rp_ready_off.resourceProviderProto:
                    candi_off.resourceProviderProto.append(rp)
                    r1 = rp.resource1
                    r2 = rp.resource2
                    self.updateByTrait(delta_r, rp.trait1, rp.trait2, -r1, -r2)
                    rp_ready_off.resourceProviderProto.remove(rp)
                    if (not self.ifAllBigerThan0(delta_r)) or (not rp_ready_off):
                        break
                del candi_off.resourceProviderProto[len(candi_off)-1]
                self.turnOffResourceProviderList(candi_off)
            elif self.ifAnySmallerThan0(delta_r):
                # select some off rps to turn on
                rp_ready_on = self.getOffResourceProviders()
                candi_on = Data.ResourceProviderListProto()
                for rp in rp_ready_on.resourceProviderProto:
                    candi_on.resourceProviderProto.append(rp)
                    r1 = rp.resource1
                    r2 = rp.resource2
                    self.updateByTrait(delta_r, rp.trait1, rp.trait2, r1, r2)
                    rp_ready_on.resourceProviderProto.remove(rp)
                    if (not self.ifAnySmallerThan0(delta_r)) or (not rp_ready_on):
                        break
                self.turnOnResourceProviderList(candi_on)
            # rp_off_list = self.getOffResourceProviders()
            # rp_on_list = Data.ResourceProviderListProto()
            # rp_on_list.resourceProviderProto.extend(rp_off_list.resourceProviderProto[:10])
            # self.turnOnResourceProviderList(rp_on_list)
#
#         self.halt()

# if __name__ == "__main__":
#
#     suite = unittest.TestSuite()
#     tests = [RandomAllocation("test1")]
#     # tests = [PowerForecastTest("test3")]
#     suite.addTests(tests)
#
#     with open('./log/HTMLReport.html', 'w') as f:
#         runner = HTMLTestRunner(stream=f,
#                                 title='Cloud virtual allocation',
#                                 description='Copyright (c) 2019 Huawei Technologies Co., Ltd.\nAll rights reserved',
#                                 verbosity=2)
#
#         runner.run(suite)