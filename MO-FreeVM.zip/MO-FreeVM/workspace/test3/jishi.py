import java.util.Scanner;

public


class Main{
public static void main(String[] args){
Scanner sc=new Scanner(System.in );
String s=sc.nextLine();
String[] strs=s.split(",");
if (strs.length != 2){
System.out.println("null");


return;
}
int
I = Integer.parseInt(strs[0]);
double
X = Double.parseDouble(strs[1]);
if (I >= 0 & & I <= 99 & & X >= 0 & & X <= 1000000000)
{
double[]
a = new
double[10005];
a[1] = X;
for (int dep=1;dep <= I;dep++){
    int start =loc(dep);
int end=start+dep;
for (int i= start; i < end;i++){
double cap=(a[i]-1) / 2.0;
a[i+dep] += cap;
a[i+dep+1] += cap;
}
}
I = I + 1;
int
start = loc(I);
int
end = start + I;
double
maxCount = Double.MIN_VALUE;
double
minCount = Double.MAX_VALUE;
for (int i=start;i < end;i++){
    maxCount=Math.max(maxCount, a[i]);
minCount=Math.min(minCount, a[i]);

}
double
value = maxCount - minCount;
System.out.println(String.format("%.4f", value));

} else {
System.out.println("null");
return;

}
}
public
static
int
loc(int
n){
return n * (n - 1) / 2 + 1;
}
}