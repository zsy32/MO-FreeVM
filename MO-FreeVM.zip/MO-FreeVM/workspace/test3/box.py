#! /usr/bin/env python
# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
def list_generator(mean, dis, number): # 封装一下这个函数，用来后面生成数据
 return np.random.normal(mean, dis * dis, number)
datafile = u'D:\\Program Files\\workspace\\test4\\all.xlsx'
data = pd.read_excel(datafile)

box_1=data['fp_cpu']
box_1_mean = np.mean(box_1)
box_1_std = np.std(box_1,ddof=1)

box_11=data['kubernetes_cpu']
box_11_mean = np.mean(box_11)
box_11_std = np.std(box_11,ddof=1)

box_111=data['vns_cpu']
box_111_mean = np.mean(box_111)
box_111_std = np.std(box_111,ddof=1)

box_2=data['fp_mem']
box_2_mean = np.mean(box_2)
box_2_std = np.std(box_2,ddof=1)

box_22=data['kubernetes_mem']
box_22_mean = np.mean(box_22)
box_22_std = np.std(box_22,ddof=1)

box_222=data['vns_mem']
box_222_mean = np.mean(box_222)
box_222_std = np.std(box_222,ddof=1)


y1=list_generator(box_1_mean,box_1_std,215)
y2 = list_generator(box_11_mean, box_11_std, 207)
y3 = list_generator(box_111_mean, box_111_std, 194)
y4=list_generator(box_2_mean,box_2_std,215)
y5 = list_generator(box_22_mean, box_22_std, 207)
y6 = list_generator(box_222_mean, box_222_std, 194)
print y1
y1 = pd.Series(np.array(y1))
y2 = pd.Series(np.array(y2))
y3 = pd.Series(np.array(y3))
y4 = pd.Series(np.array(y4))
y5 = pd.Series(np.array(y5))
y6 = pd.Series(np.array(y6))
data=[y1,y2,y3,y4,y5,y6]
# 用positions参数设置各箱线图的位置
plt.boxplot(data,positions=[0,0.5,1.0,4.0,4.5,5.0])# 就是后面加了位置
plt.colors = ['pink', 'lightblue', 'lightgreen','pink', 'lightblue', 'lightgreen']
# data = pd.DataFrame({"1": y1,"2": y2,  }) #" "3": y3, "4": y4,
# data.boxplot() # 这里，pandas自己有处理的过程，很方便哦。
plt.ylabel("ylabel")
plt.xlabel("xlabel") # 我们设置横纵坐标的标题。
plt.show()
# box_2=data['kubernetes_cpu']
# # print(box_1)
# da=[box_1,box_2]
# # plt.figure(figsize=(10, 5))  # 设置画布的尺寸
# # plt.title('Examples of boxplot', fontsize=20)  # 标题，并设定字号大小
# # labels = 'Jay'
# # # , 'JJ', 'Jolin', 'Hannah'  # 图例
# plt.boxplot(box_1)  # grid=False：代表不显示背景中的网格线
# # plt.boxplot(box_2)
# # # data.boxplot()#画箱型图的另一种方法，参数较少，而且只接受dataframe，不常用
# plt.show()  # 显示图像