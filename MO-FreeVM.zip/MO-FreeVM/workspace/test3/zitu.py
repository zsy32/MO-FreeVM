# --coding:utf-8--
import matplotlib.pyplot as plt
import csv
with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[5] for row in reader]
    res2 = column[1:]
    mem = []
    for i in range(0, len(res2)):
        mem.append(float(res2[i]))

with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    onPM = column1[1:]
    # print onPM
    on_pm = []
    for i in range(0, len(onPM)):
        on_pm.append(int(onPM[i]))

# print mem
# print on_pm
with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[5] for row in reader]
    kres2 = column[1:]
    # print res2
    kmem = []
    for i in range(0, len(kres2)):
        kmem.append(float(kres2[i]))

with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    konPM = column1[1:]
    # print onPM
    kon_pm = []
    for i in range(0, len(konPM)):
        kon_pm.append(int(konPM[i]))
#
with open('D:\\Program Files\\workspace\\test4\\fp.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[5] for row in reader]
    fres2 = column[1:]
    fmem = []
    for i in range(0, len(fres2)):
        fmem.append(float(fres2[i]))

with open('D:\\Program Files\\workspace\\test4\\fp.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    fonPM = column1[1:]
    # print onPM
    fon_pm = []
    for i in range(0, len(fonPM)):
        fon_pm.append(int(fonPM[i]))

# print mem
# print on_pm
# 数据设置
x1=[]
for i in range(len(on_pm)):
    x1.append(i)
x2=[]
for i in range(len(kon_pm)):
    x2.append(i)
y1=mem
y1.sort()

y2=kmem
y2.sort()

x3=[]
for i in range(len(fon_pm)):
    x3.append(i)

y3=fmem
y3.sort()

# 设置输出的图片大小
figsize = 5, 5
figure, ax = plt.subplots(figsize=figsize)

# 在同一幅图片上画两条折线
A, = plt.plot(x1, y1, 'ro-', label='vns', linewidth=1.0)
B, = plt.plot(x2, y2, 'g+-', label='kubernetes', linewidth=1.0)
C, = plt.plot(x3, y3, 'b--', label='greedy', linewidth=1.0)
# 设置图例并且设置图例的字体及大小
font1 = {'family': 'Times New Roman',
         'weight': 'normal',
         'size': 30,
         }
legend = plt.legend(handles=[A,B,C], prop=font1)

# 设置坐标刻度值的大小以及刻度值的字体
plt.tick_params(labelsize=20)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]

# 设置横纵坐标的名称以及对应字体格式
font2 = {'family': 'Times New Roman',
         'weight': 'normal',
         'size': 40,
         }
plt.xlabel('The ID of the opened PM', font2)
plt.ylabel('Memory Utilization(%)', font2)

# 将文件保存至文件中并且画出图
plt.savefig('figure.eps')
plt.show()