

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def list_generator(mean, dis, number):
 return np.random.normal(mean, dis * dis, number)
datafile = u'D:\\Program Files\\workspace\\test4\\all5.xlsx'
data = pd.read_excel(datafile)

box_1=data['fp_cpu']
box_1_mean = np.mean(box_1)
box_1_std = np.std(box_1,ddof=1)

box_11=data['kubernetes_cpu']
box_11_mean = np.mean(box_11)
box_11_std = np.std(box_11,ddof=1)

box_111=data['vns_cpu']
box_111_mean = np.mean(box_111)
box_111_std = np.std(box_111,ddof=1)

box_2=data['fp_mem']
box_2_mean = np.mean(box_2)
box_2_std = np.std(box_2,ddof=1)

box_22=data['kubernetes_mem']
box_22_mean = np.mean(box_22)
box_22_std = np.std(box_22,ddof=1)

box_222=data['vns_mem']
box_222_mean = np.mean(box_222)
box_222_std = np.std(box_222,ddof=1)

y1 = list_generator(box_111_mean, box_111_std, 194)
y2 = list_generator(box_11_mean, box_11_std, 207)
y3=list_generator(box_1_mean,box_1_std,215)

y4 = list_generator(box_222_mean, box_222_std, 194)
y5 = list_generator(box_22_mean, box_22_std, 207)
y6=list_generator(box_2_mean,box_2_std,215)
# Random test data
# np.random.seed(19680801)
# all_data = [np.random.normal(0, std, size=100) for std in range(1, 4)]
all_data=[y1,y2,y3]
all_data1=[y4,y5,y6]
labels = ['vns', 'kubernetes', 'greedy',]

fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(6, 4))
# plt.xticks(fontsize=20)
#     plt.yticks(fontsize=20)
# rectangular box plot
bplot1 = axes[0].boxplot(all_data,
                         vert=True,  # vertical box alignment
                         patch_artist=True,  # fill with color
                         labels=labels)  # will be used to label x-ticks
axes[0].set_title('CPU',fontsize=20)

# notch shape box plot
bplot2 = axes[1].boxplot(all_data1,
                         notch=True,  # notch shape
                         vert=True,  # vertical box alignment
                         patch_artist=True,  # fill with color
                         labels=labels)  # will be used to label x-ticks
axes[1].set_title('Memory',fontsize=20)

# fill with colors
colors = ['pink', 'lightblue', 'lightgreen']
for bplot in (bplot1, bplot2):
    for patch, color in zip(bplot['boxes'], colors):
        patch.set_facecolor(color)

# adding horizontal grid lines
for ax in axes:
    ax.yaxis.grid(True)
    # ax.set_xlabel()
    ax.set_ylabel('Utilization')
#     plt.xticks(fontsize=20)
#     plt.yticks(fontsize=20)



plt.show()
