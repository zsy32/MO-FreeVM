# -*- coding: utf-8 -*-
# import matplotlib.pyplot as plt
# from pylab import *                                 #支持中文
# mpl.rcParams['font.sans-serif'] = ['SimHei']
#
# names = ['100', '200', '300', '400', '500']
# x = range(len(names))
# y = [0.855, 0.84, 0.835, 0.815, 0.81]
# # y1=[0.86,0.85,0.853,0.849,0.83]
# #plt.plot(x, y, 'ro-')
# #plt.plot(x, y1, 'bo-')
# #pl.xlim(-1, 11)  # 限定横轴的范围
# #pl.ylim(-1, 110)  # 限定纵轴的范围
# plt.plot(x, y, marker='o', mec='r', mfc='w',label=u'y=x^2曲线图')
# # plt.plot(x, y1, marker='*', ms=10,label=u'y=x^3曲线图')
# plt.legend()  # 让图例生效
# plt.xticks(x, names, rotation=45)
# plt.margins(0)
# plt.subplots_adjust(bottom=0.15)
# plt.xlabel(u"time(s)邻居") #X轴标签
# # plt.ylabel("RMSE") #Y轴标签
# plt.title("A simple plot") #标题
#
# plt.show()
#
import matplotlib.pyplot as plt
#储存温度和日期
datas = {
         '1' : [2346,2105,2056,2365,2368,2374,2380],
         # '3':  [2707,2679,2633,2581,2514,2489,2478],
         '3':  [2707,2609, 2557, 2503, 2443, 2440, 2445],
         '4' : [2921,2887,2847,2895,2818,2754,2750],
         # '5' : [3121,3023,2971,2917,2847,2844,2839],
         '5' : [3121,3093,3067,3035,3028,3020,3014],
         '2' : ['100','200','300','400','500','600','700']
         }
#绘制出图形，大小是 (15,15)
plt.figure(figsize = (10,10))
#绘制出图形    x轴     y轴
ln1,=plt.plot(datas['2'],datas['1'],color='red',linewidth=2.0,linestyle='--')
ln3,=plt.plot(datas['2'],datas['4'],color='green',linewidth=3.0,linestyle='-')
ln2,=plt.plot(datas['2'],datas['3'],color='blue',linewidth=3.0,linestyle='-.')

ln4,=plt.plot(datas['2'],datas['5'],color='black',linewidth=3.0,linestyle=':')
# plt.legend()  # 让图例生效
plt.legend(handles=[ln1, ln3,ln2,ln4], labels=["MO_STVNS","GWO", "SA","GA"],loc=2, prop={'size': 20})

#设置x和y轴的文字颜色
plt.xticks(size = 20,color = 'black')
plt.yticks(size = 20,color = 'black')
#设置x轴和y轴的标签
plt.xlabel('Cycle',size = 20,color = 'black')
plt.ylabel('TSF',size = 20,color = 'black')
#设置标题
# plt.title('Future Weather Chart Temperature Trend',size = 20,color = 'black')
#使用风格 bmh
plt.style.use('bmh')
#绘制出统计图
plt.savefig('D:\\TOSC\\vmplacement_time\\running_time\\TSF.pdf')
plt.show()