import numpy as np
import matplotlib.pyplot as plt

size = 5
x = np.arange(size)
a = [156,179,201,234,272]
print a
# b = np.random.random(size)
b=[203,267,319,377,436]
# c = np.random.random(size)
c=[182,233,285,330,396]
# d = np.random.random(size)
d=[193,249,305,370,421]
total_width, n = 0.8, 4
width = total_width / n
x = x - (total_width - width) / 3
tick_label=[600,700,800,900,1000]
plt.figure(figsize=(10, 10))
plt.bar(x, a,  width=width, label='MO_STVNS')
plt.bar(x + width, b, width=width,hatch='+', label='GWO')
plt.bar(x + 2 * width, c, width=width, hatch='o',label='SA')
plt.bar(x + 3 * width, d, width=width,hatch='-', label='Gen')

# plt.bar(x, a, edgecolor='black',width=width,hatch='o', label='vns')
# plt.bar(x + width, b, color='white', edgecolor='black', width=width,hatch='x', label='GWO')
# plt.bar(x + 2 * width, c, color='white', edgecolor='black', width=width, hatch='||',label='SA')
# plt.bar(x + 3 * width, d, color='white', edgecolor='black', width=width,hatch='-', label='Gen')
plt.legend(loc = 0, prop = {'size':28})
plt.xticks(x+0.3,tick_label,fontsize=28)
plt.yticks(fontsize=28)
plt.xlabel('Cycle',fontsize=28)
plt.ylabel('Average number of active PMs',fontsize=28)

plt.savefig('D:\\TOSC\\vmplacement_time\\running_time\\onpm_ali.pdf')
plt.show()