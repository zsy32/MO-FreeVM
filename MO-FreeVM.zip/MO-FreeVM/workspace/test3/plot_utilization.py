# coding:utf-8

import numpy as np
import matplotlib.pyplot as plt
import csv
with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[2] for row in reader]
    res2 = column[1:]
    # print res2
    mem = []
    for i in range(0, len(res2)):
        mem.append(float(res2[i]))

with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    onPM = column1[1:]
    # print onPM
    on_pm = []
    for i in range(0, len(onPM)):
        on_pm.append(int(onPM[i]))

print mem
print on_pm
with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[2] for row in reader]
    kres2 = column[1:]
    # print res2
    kmem = []
    for i in range(0, len(kres2)):
        kmem.append(float(kres2[i]))

with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    konPM = column1[1:]
    # print onPM
    kon_pm = []
    for i in range(0, len(konPM)):
        kon_pm.append(int(konPM[i]))

# print kmem
# print kon_pm
with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    res1 = column[1:]
    # print res2
    cpu = []
    for i in range(0, len(res1)):
        cpu.append(float(res1[i]))
#
# with open('D:\\Program Files\\workspace\\test4\\vns.csv','rb') as csvfile:
#     reader = csv.reader(csvfile)
#     column1 = [row[0] for row in reader]
#     onPM = column1[1:]
#     # print onPM
#     on_pm = []
#     for i in range(0, len(onPM)):
#         on_pm.append(int(onPM[i]))

print cpu
print on_pm
with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    kres1 = column[1:]
    # print res2
    kcpu = []
    for i in range(0, len(kres1)):
        kcpu.append(float(kres1[i]))

# with open('D:\\Program Files\\workspace\\test4\\kubernetes.csv','rb') as csvfile:
#     reader = csv.reader(csvfile)
#     column1 = [row[0] for row in reader]
#     konPM = column1[1:]
#     # print onPM
#     kon_pm = []
#     for i in range(0, len(konPM)):
#         kon_pm.append(int(konPM[i]))

# print kcpu
# print kon_pm
# x1 = [20, 33, 51, 79, 101, 121, 132, 145, 162, 182, 203, 219, 232, 243, 256, 270, 287, 310, 325]
# y1 = [49, 48, 48, 48, 48, 87, 106, 123, 155, 191, 233, 261, 278, 284, 297, 307, 341, 319, 341]
x1=on_pm
y1=mem
y1.sort()
print y1
x2=kon_pm
y2=kmem
y2.sort()

l1 = plt.plot(x1, y1, 'r--', label='vns')
l2 = plt.plot(x2, y2, 'g--', label='kubernetes')
plt.legend(loc = 0, prop = {'size':20})

# A,=plt.plot(x1,y1,'r--',label='A',linewidth=5.0)
# B,=plt.plot(x2,y2,'g--',label='B',linewidth=5.0)
# legend = plt.legend(handles=[l1, l2], fontsize=20)
# plt.legend(fontsize=20)
# l3 = plt.plot(x3, y3, 'b--', label='type3')


# plt.subplot(1,2,1)
# plt.plot([0,1],[0,1])
plt.plot(x1, y1, 'ro-', x2, y2, 'g+-')#, x2, y2, 'g+-', x3, y3, 'b^-'

# plt.tight_layout()
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
# l1 = plt.plot(x1, y1, 'r--', label='vns')
# l2 = plt.plot(x2, y2, 'g--', label='kubernetes')
# plt.title('The Lasers in Three Conditions')
plt.xlabel('The ID of the opened PM',fontsize=20)
plt.ylabel('Memory Utilization(%)',fontsize=20)
# plt.figure(dpi=300,figsize=(2,1))
# plt.subplot(1,2,2)
# x1=on_pm
# y1=cpu
# y1.sort()
# x2=kon_pm
# y2=kcpu
# y2.sort()
# # plt.plot([0,1],[0,1])
# plt.figure(figsize=(10,4))
# plt.plot(x1, y1, 'ro-', x2, y2, 'g+-',)#, x2, y2, 'g+-', x3, y3, 'b^-'
# plt.tight_layout()
# l1 = plt.plot(x1, y1, 'r--', label='vns')
# l2 = plt.plot(x2, y2, 'g--', label='kubernetes')
# # plt.title('The Lasers in Three Conditions')
# plt.xlabel('The ID of the opened PM')
# plt.ylabel('Memory Utilization(%)')
# plt.figure(dpi=300,figsize=(2,1))
plt.legend()
# plt.figure(dpi=300,figsize=(2,1))
plt.show()