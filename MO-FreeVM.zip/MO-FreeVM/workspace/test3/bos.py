# -*- coding: utf-8 -*-
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
# datafile = u'D:\\TOSC\\vmplacement_time\\box\\box_google_a.xlsx'
# data = pd.read_excel(datafile)
#
# box_1=data['usti_a_cpu_VNS']
# # data = [1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2000, 2100]
#
# df = pd.DataFrame(box_1)
# df.plot.box(title="hua tu")
# plt.grid(linestyle="--", alpha=0.3)
# plt.show()
import pandas as pd
import matplotlib.pyplot as plt
# datafile = u'D:\\TOSC\\vmplacement_time\\box\\box_google_a.xlsx'
# data = pd.read_excel(datafile)
# 读取数据
# datafile = u'D:\\pythondata\\learn\\matplotlib.xlsx'
# data = pd.read_excel(datafile)
datafile = u'D:\\TOSC\\vmplacement_time\\box_ali\\box.xlsx'
data = pd.read_excel(datafile)
box_1, box_2, box_3, box_4 = data['usti_A_cpu_vns'], data['usti_A_cpu_GWO'], data['usti_A_cpu_SA'], data['usti_A_cpu_Gen']

plt.figure(figsize=(10, 10))  # 设置画布的尺寸
# plt.title('Examples of boxplot', fontsize=20)  # 标题，并设定字号大小
labels = 'MO_STVNS', 'GWO', 'SA', 'GA'  # 图例
plt.boxplot([box_1, box_2, box_3, box_4], labels=labels)  # grid=False：代表不显示背景中的网格线
# data.boxplot()#画箱型图的另一种方法，参数较少，而且只接受dataframe，不常用
plt.xticks(size = 30,color = 'black')
plt.yticks(size = 30,color = 'black')
plt.ylabel('CPU Utilization(%)',fontsize=28)
# plt.legend(loc=0, prop={'size': 28})
plt.savefig('D:\\TOSC\\vmplacement_time\\running_time\\box_aa_CPU.pdf')
plt.show()  # 显示图像