
import numpy as np
import pandas as pd
import random
rpId=[]
for i in range(0,140):
    rpId.append(random.uniform(0.90,0.96))
print(rpId)


data = pd.DataFrame({
                    "id":np.arange(20000),#800
                     "rpId":rpId
                                    })
print (data)
data.to_csv("D:\\Program Files\\workspace\\test3\\output\\22.csv.csv")


