# coding:utf-8

import numpy as np
import matplotlib.pyplot as plt
import csv
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    res2 = column[1:]
    # print res2
    mem = []
    for i in range(0, len(res2)):
        mem.append(float(res2[i]))

with open('D:\\TOSC\\vmplacement_time\\delay\\delay_vns.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    onPM = column1[1:]
    # print onPM
    on_pm = []
    for i in range(0, len(onPM)):
        on_pm.append(int(onPM[i]))
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_GWO.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    onPM = column1[1:]
    # print onPM
    on_pm_GWO = []
    for i in range(0, len(onPM)):
        on_pm_GWO.append(int(onPM[i]))
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_GWO.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    res1 = column[1:]
    # print res2
    cpu = []
    for i in range(0, len(res1)):
        cpu.append(float(res1[i]))
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_SA.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    res1 = column[1:]
    # print res2
    sa = []
    for i in range(0, len(res1)):
        sa.append(float(res1[i]))
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_SA.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    onPM = column1[1:]
    # print onPM
    on_pm_SA = []
    for i in range(0, len(onPM)):
        on_pm_SA.append(int(onPM[i]))
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_Gen.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column = [row[1] for row in reader]
    res1 = column[1:]
    # print res2
    gen = []
    for i in range(0, len(res1)):
        gen.append(float(res1[i]))
with open('D:\\TOSC\\vmplacement_time\\delay\\delay_Gen.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[0] for row in reader]
    onPM = column1[1:]
    # print onPM
    on_pm_Gen = []
    for i in range(0, len(onPM)):
        on_pm_Gen.append(int(onPM[i]))
print mem
print on_pm

x1=on_pm
y1=mem
y1.sort()
x2=on_pm_GWO
y2=cpu
y2.sort()
x3=on_pm_SA
y3=sa
y3.sort()
x4=on_pm_Gen
y4=gen
y4.sort()
print y1
# print y2

l1 = plt.plot(x1, y1, 'ro-', label='vns')
l2 = plt.plot(x2, y2, 'g+-', label='GWO')
l3 = plt.plot(x3, y3, 'bs-', label='SA')
l4 = plt.plot(x3, y3, 'k*-', label='Gen')
plt.legend(loc = 0, prop = {'size':20})
plt.plot(x1, y1, 'ro-', x2, y2, 'g+-', x3, y3, 'bs-', x4, y4, 'k*-')#, x2, y2, 'g+-', x3, y3, 'b^-'
# , x3, y3, 'bs-', x4, y4, 'k*-', x2, y2, 'g+-'
# plt.tight_layout()
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)

plt.xlabel('The ID of the opened PM',fontsize=20)
plt.ylabel('Deday Time (s)',fontsize=20)
plt.legend()

plt.show()