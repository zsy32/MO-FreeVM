import numpy as np
import matplotlib.pyplot as plt

size = 5
x = np.arange(size)
a = [121,137,154,174,197]
print a
# b = np.random.random(size)
b=[151,184,213,245,267]
# c = np.random.random(size)
c=[134,153,177,193,219]
# d = np.random.random(size)
d=[145,170,196,223,251]
total_width, n = 0.8, 4
width = total_width / n
x = x - (total_width - width) / 3
tick_label=[600,700,800,900,1000]

plt.figure(figsize=(10, 10))
plt.bar(x, a,  width=width, label='MO_STVNS')
plt.bar(x + width, b, width=width,hatch='+', label='GWO')
plt.bar(x + 2 * width, c, width=width, hatch='o',label='SA')
plt.bar(x + 3 * width, d, width=width,hatch='-', label='Gen')
plt.legend(loc = 0, prop = {'size':28})
plt.xticks(x+0.3,tick_label,fontsize=28)
plt.yticks(fontsize=28)
plt.xlabel('Cycle',fontsize=28)
plt.ylabel('Average number of active PMs',fontsize=28)

plt.savefig('D:\\TOSC\\vmplacement_time\\running_time\\onpm.pdf')
plt.show()