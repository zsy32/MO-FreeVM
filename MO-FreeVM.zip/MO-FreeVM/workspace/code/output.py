# name =['a1','a2','a3']
# seq=['seq11111','seqs22222','seq33333']
# f = open("D:/Program Files/workspace/test3/output/1.txt", "w+")
# f.write("name\tseq\n")
# for i in range(0, len(name)):
#     f.write(name[i] + "\t" + seq[i] + "\n")
# f.close()
f = open("D:/Program Files/workspace/test3/output/2.txt", "w+")
i=0
while i<10:
    print(i)
    f.write(str(i)+"\n")
    i=i+1
f.close()