# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import random
# def max_index(lst_int):
#     index = []
#     max_n = max(lst_int)
#     for i in range(len(lst_int)):
#         if lst_int[i] == max_n:
#             index.append(i)
#     return index  #返回一个列表
# #
# #
# lst = [1, 5, 2, 3, 4, 5, 5, 5]
# print("max_indexlist:",max_index(lst))
# aa=max_index(lst)
# des = np.random.randint(0, len(aa))
# print("des:",des)
# #
# # cc=[1,2,3]
# # bb=[4,5,1]
# # a = np.array(cc)
# # b = np.array(bb)
# # r1 = a + b  # [[3 6]]
# # print(r1)
# def get_keys(d, value):
#     return [k for k, v in d.items() if v == value]
#
# rpDict={2:1,4:1,1:6,6:2,3:5}
# print(get_keys(rpDict, 5))
# sortedRPs = sorted(rpDict.items(), key = lambda x:x[1], reverse=False)
# candi_rp_id = sortedRPs[len(sortedRPs) - 1]  # place on hotter rpcandi_rp_id = sorted_rps[len(sorted_rps) - 1]  # place on hotter rp
# candi_rp_idlist = list(candi_rp_id)
#
# print("sortedRPs",sortedRPs)
# print(max_index(sortedRPs))
# print("candi_rp_idlist", candi_rp_idlist)
des_vmList=[3]
des_vm_i = np.random.randint(0, len(des_vmList)-1)
print(des_vm_i)