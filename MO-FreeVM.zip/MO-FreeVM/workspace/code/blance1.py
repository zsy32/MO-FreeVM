import matplotlib.pyplot as plt
import numpy as np
import csv
with open('D:/Program Files/workspace/test3/output/5.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[2] for row in reader]
    y=column1[1:]
    print y
    aa=[]
    for i in range(0,len(y)):
        aa.append(float(y[i]))
    print aa
with open('D:/Program Files/workspace/test3/output/3.csv','rb') as csvfile:
    reader = csv.reader(csvfile)
    column1 = [row[1] for row in reader]
    x=column1[1:]
    print x
    bb=[]
    for i in range(0,len(x)):
        bb.append(float(x[i]))
    print bb
# with open('D:/Program Files/workspace/test3/output/3.csv', 'rb') as csvfile:
#     reader = csv.reader(csvfile)
#     column2 = [row[3] for row in reader]
#     y2=column2[1:]
#     y1.sort()
#     print y1
#     print y2

# plt.scatter(x,y1,c='red')
# plt.scatter(x,y1,c='red')
# plt.scatter(x, y2, c='green')
# print len(y1)
y1=[0.8125, 1.0, 0.0, 0.00390625, 0.5, 0.0625, 0.0, 0.953125, 0.0, 0.5, 0.5, 1.0, 0.734375, 1.0, 0.25, 0.8671875, 0.78125, 0.0, 0.734375, 0.78125, 0.03125, 0.03125, 0.0, 0.0078125, 1.0]
x=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63, 64, 66, 67, 68, 69, 70, 71, 72, 73, 74, 78, 79, 80, 84, 85, 89, 91, 92, 94, 98]
for i in range(0,len(aa)):
    x.append(i)
print x

plt.scatter(x, aa, c='green')
plt.show()