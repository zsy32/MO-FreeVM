import csv
import re
import pandas as pd
with open('resourceprovider.csv', 'r') as csvfile:

    reader = csv.reader(csvfile)
    vminPMlist = [row[8] for row in reader]
    print(vminPMlist)
    p=[]
    for rp in range(1,len(vminPMlist)):
        if vminPMlist[rp]!='null':
            p.append(rp-1)
    print("p",p)
with open('resourcerequest.csv', 'r') as csvfile1:
    reader1 = csv.reader(csvfile1)
    rpId = [row[3] for row in reader1]
    # rpIdlist=[]
    # for rp in range(1,len(rpId)):
    #     rpIdlist.append(rpId[rp])
    # print(rpIdlist)
    for i in range(len(p)):
        rpId[i+1]=p[i]
    print(rpId)
df = pd.read_csv("D:\\Program Files\\workspace\\test3\\resourcerequest.csv")
df.iloc[:, 3]=rpId[1:]
df.to_csv("D:\\Program Files\\workspace\\test3\\resourcerequest.csv")

    # col=[]
    # for req in range(1,len(column1)):
    #     col.append(column1[req].strip('()').split(','))
    # print (col)
    #
    # print(col[3][0])
    # print(type(col[3]))
