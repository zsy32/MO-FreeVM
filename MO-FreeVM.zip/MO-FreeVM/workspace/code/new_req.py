import csv
import re
import pandas as pd
with open('resourcerequest1.csv', 'r') as csvfile1:
    reader1 = csv.reader(csvfile1)
    rpId = [row[3] for row in reader1]
    print(rpId)
with open('resourceprovider4.csv', 'r') as csvfile:
    reader = csv.reader(csvfile)
    vminPMlist = [row[8] for row in reader]
    print(vminPMlist)
    vminPM=vminPMlist[1:]
    for vm in range(0,len(vminPM)):
        if vminPM[vm]!="[]":
            vminPM[vm] = [int(s) for s in re.findall(r"\d+\.?\d*", str(vminPM[vm]))]
            print(vminPM[vm])
            for v in range(len(vminPM[vm])):
                rpId[vminPM[vm][v]+1]=vm
    print(rpId)
df = pd.read_csv("D:\\Program Files\\workspace\\test3\\resourcerequest1.csv")
df.iloc[:, 3]=rpId[1:]
df.to_csv("D:\\Program Files\\workspace\\test3\\resourcerequest1.csv")

