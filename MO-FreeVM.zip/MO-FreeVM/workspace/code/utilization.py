#! /usr/bin/env python
# -*- coding: utf-8 -*-
import Data_pb2
import pandas as pd
import numpy as np
import random
import csv

from sqlalchemy import create_engine
import re
import predict
class Allocation:
    def getRunningResourceProviders(self):
        engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
        sql = ''' select * from resourceprovider; '''
        df = pd.read_sql_query(sql, engine)
        try:
            rp_stateList= df['rp_state']
            rp_stateList_dict = rp_stateList.to_dict()
            onrplist = filter(lambda k: rp_stateList_dict[k] == 'On', rp_stateList_dict)
            # print("onrplist",onrplist)
            toresList = df['resourceSpecification']
            toresList_dict = toresList.to_dict()
            toresList_value = toresList_dict.values()
            # print("toresList_value", toresList_value)
            resource1List = df['resource1']
            resource1List_dict = resource1List.to_dict()
            resource1List_value = resource1List_dict.values()
            utilization_resource1=[]
            resource2List = df['resource2']
            resource2List_dict = resource2List.to_dict()
            resource2List_value = resource2List_dict.values()
            utilization_resource2 = []

            for onrp in range(0,len(onrplist)):
                total= toresList_value[onrplist[onrp]].strip('()').split(',')
                resource1=resource1List_value[onrplist[onrp]]
                resource2=resource2List_value[onrplist[onrp]]
                # print("total",float(total[0]))
                # print("resource1",resource1)
                utilization_resource1.append(float((float(total[0])-resource1)/float(total[0])))
                utilization_resource2.append(float((float(total[1]) - resource2) / float(total[1])))
            print(" utilization_resource1", utilization_resource1)
            print(" utilization_resource2", utilization_resource2)
            lista=[onrplist,utilization_resource1,utilization_resource2]
            return lista

        except Exception as err:
            print(err)
if __name__ == '__main__':
    c=Allocation()
    aa=c.getRunningResourceProviders()
    print(aa[0])
    data = pd.DataFrame({
        "onPM": aa[0],
        "utilization_resource1": aa[1],
        "utilization_resource2": aa[2],
    })
    print (data)
    data.to_csv("D:/Program Files/workspace/test3/output/7.csv")





