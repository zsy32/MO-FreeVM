# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import random

def trait1(sample_count):
    sample=[]
    sample_choosed={}
    test_rate={}
    simulate_count=10000
    dic = {'A': 0.5, 'a': 0.5}

    for key,values  in dic.items():

        for i in range (int(values*sample_count)):
            sample.append(key)
        sample_choosed[key]=0
        test_rate[key]=0.0
    random.shuffle(sample)

    for i in range(simulate_count):
        key=int(random.random()*sample_count)
        try:
            sample_choosed[sample[key]] += 1
        except:
            continue
        # sample_choosed[sample[key]]+=1

    for (key,count) in sample_choosed.items():
        test_rate[key]=count/float(simulate_count)
    return sample

def trait2(sample_count):
    sample=[]
    sample_choosed={}
    test_rate={}
    simulate_count=10000
    dic = {'B': 0.5, 'b': 0.5}

    for key,values  in dic.items():

        for i in range (int(values*sample_count)):
            sample.append(key)
        sample_choosed[key]=0
        test_rate[key]=0.0
    random.shuffle(sample)

    for i in range(simulate_count):
        key=int(random.random()*sample_count)
        try:
            sample_choosed[sample[key]] += 1
        except:
            continue
        # sample_choosed[sample[key]]+=1

    for (key,count) in sample_choosed.items():
        test_rate[key]=count/float(simulate_count)
    return sample

def requestSpecification(sample_count):
    sample=[]
    sample_choosed={}
    test_rate={}
    simulate_count=10000
    dic = {'(2,1)': 0.02,
           '(2,2)': 0.01,
           '(2,4)': 0.015,
           '(2,8)': 0.055,
           '(4,2)': 0.04,
           '(4,4)': 0.02,
           '(4,8)': 0.03,
           '(4,16)': 0.11,
           '(8,4)': 0.08,
           '(8,8)': 0.04,
           '(8,16)': 0.06,
           '(8,32)': 0.22,
           '(16,8)': 0.04,
           '(16,16)': 0.02,
           '(16,32)': 0.03,
           '(16,64)': 0.11,
           '(32,16)': 0.02,
           '(32,32)': 0.01,
           '(32,64)': 0.015,
           '(32,128)': 0.055,
           }

    for key,values  in dic.items():
        for i in range (int(values*sample_count)):
            sample.append(key)
        sample_choosed[key]=0
        test_rate[key]=0.0
    random.shuffle(sample)
    for i in range(simulate_count):
        key=int(random.random()*sample_count)
        try:
            sample_choosed[sample[key]] += 1
        except:
            continue
        # sample_choosed[sample[key]]+=1

    for (key,count) in sample_choosed.items():
        test_rate[key]=count/float(simulate_count)
    return sample
# def VMid(m):
#     lista = []
#     for i in range(m):
#         lista.append("vm" + str(i))
#     return lista

sample_count=40000 #800
Trait1=trait1(sample_count)
# print (Trait1)
Trait2=trait2(sample_count)
RequestSpecification=requestSpecification(sample_count)
# print (ResourceSpecification)
userId = ['VIPId', 'Retail']
UserId=np.random.choice(userId, sample_count, p=[0.4, 0.6])
rpId='null'
print(rpId)
# vmid=VMid(800)
# print (vmid)



# a={'id':np.arange(100),
#    'trait1':Trait1,
#    'trait2':Trait2,
#    # 'requestSpecification':RequestSpecification,
#    # 'rpId':Trait2,
#    'userId':UserId}
# df=pd.DataFrame.from_dict(a,orient='index')

data = pd.DataFrame({
                    "id":np.arange(40000),#800
                    # "VMid":VMid(800),
                     "trait1": Trait1,
                     "trait2": Trait2,
                     "requestSpecification":RequestSpecification,
                     "userId":UserId,
                     "rpId":rpId
                                    })
print (data)
data.to_csv("resourcerequest1.csv")
