# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import random

from sqlalchemy import create_engine
class Resourceprovider:

    def trait1(self,sample_count):
        sample=[]
        sample_choosed={}
        test_rate={}
        simulate_count=10000
        dic = {'A': 0.5, 'a': 0.5}

        for key,values  in dic.items():

            for i in range (int(values*sample_count)):
                sample.append(key)
            sample_choosed[key]=0
            test_rate[key]=0.0
        random.shuffle(sample)

        for i in range(simulate_count):
            key=int(random.random()*sample_count)
            try:
                sample_choosed[sample[key]] += 1
            except:
                continue
        for (key,count) in sample_choosed.items():
            test_rate[key]=count/float(simulate_count)
        return sample

    def trait2(self,sample_count):
        sample=[]
        sample_choosed={}
        test_rate={}
        simulate_count=10000
        dic = {'B': 0.4, 'b': 0.6}

        for key,values  in dic.items():

            for i in range (int(values*sample_count)):
                sample.append(key)
            sample_choosed[key]=0
            test_rate[key]=0.0
        random.shuffle(sample)

        for i in range(simulate_count):
            key=int(random.random()*sample_count)
            try:
                sample_choosed[sample[key]] += 1
            except:
                continue

        for (key,count) in sample_choosed.items():
            test_rate[key]=count/float(simulate_count)
        return sample

    def resourceSpecification(self,sample_count):
        sample=[]
        sample_choosed={}
        test_rate={}
        simulate_count=10000
        dic = {'32,128': 0.1,
               '64,128': 0.4,
               '64,256': 0.3,
               '128,256': 0.2
                }

        for key,values  in dic.items():
            for i in range (int(values*sample_count)):
                sample.append(key)
            sample_choosed[key]=0
            test_rate[key]=0.0
        random.shuffle(sample)
        for i in range(simulate_count):
            key=int(random.random()*sample_count)
            try:
                sample_choosed[sample[key]] += 1
            except:
                continue

        for (key,count) in sample_choosed.items():
            test_rate[key]=count/float(simulate_count)
        return sample
    def rpstate(self):
        RPstate = ['On', 'Off']
        RP_state = np.random.choice(RPstate, sample_count, p=[0.7, 0.3])
        return RP_state

    def VMinPM(self):
        onlist=[]
        vminPM=[]
        rp_state=self.rpstate()
        for rp in range(sample_count):
            if rp_state[rp] == 'On':
                onlist.append(rp)
        arr = np.array(range(70))
        newarr = np.array_split(arr, 70)
        # print (newarr)
        for i in range( sample_count):
            vminPM.append('null')
            for j in range(len(onlist)):
                if i==onlist[j]:
                    vminPM[i]=(newarr[j])
        return [rp_state, vminPM]

    # def resource(self):
    #     vm_list=self.VMinPM()
    #     vmList=vm_list[1]
    #     for vml in range(len(vmList)):
    #         if vmList[vml]!='null':
    #             aa=vmList[vml]
    #     print(aa)
    #     engine = create_engine('mysql+pymysql://root:123456@localhost:3306/runoob_db')
    #     # 查询语句，选出employee表中的所有数据
    #     sql = ''' select * from resourcerequest; '''
    #     sql_res=''' select * from resourceprovider; '''
    #     # read_sql_query的两个参数: sql语句， 数据库连接
    #     df = pd.read_sql_query(sql_res, engine)
    #     vminPMlist= df['vminPM']
    #     vminPMlist_dict=vminPMlist.to_dict()
    #     print(vminPMlist_dict)
    #
        # reqSpecList = df['requestSpecification']
        # reqSpecList_dict = reqSpecList.to_dict()
    #     print( reqSpecList_dict )
    #     print(vmList)
    #     print(vmList[2][0])
    #     print(type(vmList))
        vlist=[]

    #             print(aa)
    #             print(aa[1])
    #             for i in range(len(aa)):
    #                 for j in range(len(aa[i])):
    #                     vlist=aa[i]
    #                 vlist.append()




if __name__ == '__main__':

    sample_count=100
    c=Resourceprovider()
    Trait1=c.trait1(sample_count)
    # print (Trait1)
    Trait2=c.trait2(sample_count)
    ResourceSpecification=c.resourceSpecification(sample_count)
    # print (ResourceSpecification[0])
    RP_state=c.rpstate()
# print(RP_state)
    VMlist=c.VMinPM()
    RPstate=VMlist[0]
    vminPM=VMlist[1]
    # resource=c.resource()
    # print(vminPM)
    # print(RPstate)
    # lista = c.resourceSpecification(sample_count)
    # print(len(lista))
    # print("************8")


    data = pd.DataFrame({
                        "id":np.arange(100),
                         "trait1": Trait1,
                         "trait2": Trait2,
                         "resourceSpecification":ResourceSpecification,
                         "resource1":"null",
                         "resource2": "null",
                         "rp_state": RPstate,
                         "vminPM":vminPM
                                        })
    print (data)
    data.to_csv("resourceprovider1.csv")



