# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import random
import copy
import csv
from sqlalchemy import create_engine
import re
class Resourceprovider:
    def getvaildrp(self,resourcerequest):
        requestSpecification = []
        requestSpecification.append(resourcerequest[2].strip('()').split(','))
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column1 = [row[5] for row in reader]
            rp_state=column1[1:]
            # print(rp_state)
            onrplist = []
            for rp in range(len(rp_state)):
                if rp_state[rp] == 'On':
                    onrplist.append(rp)
            # print("onrplist",onrplist)
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column2 = [row[6] for row in reader]
            Trait1=column2[1:]
            # print(Trait1)
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column3 = [row[7] for row in reader]
            Trait2 = column3[1:]
            # print(Trait2)
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column4 = [row[4] for row in reader]
            resourceSpecilist= column4[1:]
            resourceSpeci = []
            for res in range(len(resourceSpecilist)):
                resourceSpeci.append(resourceSpecilist[res].strip('()').split(','))
            # print(resourceSpeci)
        vaildrplist=[]
        for rp in onrplist:  #rrlist的初始放置
            if (resourcerequest[4] == Trait1[rp]) and (resourcerequest[5]== Trait2[rp])\
            and (resourceSpeci[rp][0]>=int(requestSpecification[0][0])) and (resourceSpeci[rp][1]>=int(requestSpecification[0][1])):
                    vaildrplist.append(rp)
        return vaildrplist

    def vminPM(self):
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column5 = [row[8] for row in reader]
            vminPM = column5[1:]
            # print("vminPM",vminPM)
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column6 = [row[2] for row in reader]
            resource1= column6[1:]
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column7 = [row[3] for row in reader]
            resource2 = column7[1:]
            # print("resource2",resource2)
        for i in range(1,40):
            with open('D:\\Program Files\\workspace\\test3\\resourcerequest1.csv', 'rb') as csvfile:
                reader = csv.reader(csvfile)
                rows = [row for row in reader]
                req1=rows[i]
                print(req1)
                print(type(req1))
                requestSpecification = []
                requestSpecification.append(req1[2].strip('()').split(','))
                # print(requestSpecification[0][0])
                vailrplist = self.getvaildrp(req1)
                # print("vailrplist",vailrplist)
                if (len(vailrplist) == 0):
                    continue
                choicerp = random.choice(vailrplist)
                vminPM[choicerp] = [int(s) for s in re.findall(r"\d+\.?\d*", str(vminPM[choicerp]))]
                print(vminPM[choicerp])
                vminPM[choicerp].append(int(req1[1]))
                if (int(resource1[choicerp])>=int(requestSpecification[0][0])) and (int(resource2[choicerp])>=int(requestSpecification[0][1])):
                    resource1[choicerp]=int(resource1[choicerp])-int(requestSpecification[0][0])
                    resource2[choicerp] = int(resource2[choicerp])-int(requestSpecification[0][1])
                # print(vminPM)
                # print("resource1",resource1)
        return [vminPM,resource1,resource2]

    def rp_state(self):
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column = [row[5] for row in reader]
            rp_state = column[1:]
        return rp_state

    def resourceSpecification(self):
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column = [row[4] for row in reader]
            resourceSpecificationlist = column[1:]
        return resourceSpecificationlist

    def trait1(self):
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column = [row[6] for row in reader]
            trait1 = column[1:]
        return trait1

    def trait2(self):
        with open('D:\\Program Files\\workspace\\test3\\resourceprovider3.csv', 'rb') as csvfile:
            reader = csv.reader(csvfile)
            column = [row[7] for row in reader]
            trait2 = column[1:]
        return trait2
if __name__ == '__main__':
    sample_count = 1000
    c = Resourceprovider()
    rp_state=c.rp_state()
    resourceSpecification = c.resourceSpecification()
    trait1= c.trait1()
    trait2= c.trait2()
    vminPM = c.vminPM()
    vminPMlist=vminPM[0]
    resource1 = vminPM[1]
    resource2 = vminPM[2]
    print("vminPM",vminPM)
    data = pd.DataFrame({
        "id": np.arange(1000),
        "trait1": trait1,
        "trait2": trait2,
        "rp_state": rp_state,
        "vminPM": vminPMlist,
        "resourceSpecification": resourceSpecification,
        "resource1": resource1,
        "resource2": resource2,
    })
    print (data)
    data.to_csv("resourceprovider4.csv")