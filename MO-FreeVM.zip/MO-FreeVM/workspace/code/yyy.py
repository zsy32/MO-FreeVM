aa=[]
print(len(aa))