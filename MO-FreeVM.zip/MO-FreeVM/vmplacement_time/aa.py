# coding: UTF-8
import time


class Allocation:

    @classmethod

    def updateMachines(self, current_time):

        machine_empty = True

        for machine in self.cluster:
            if machine.beingUtilized:
                for task in list(machine.runningTasks):
                    if task.placement_time + task.duration <= current_time:
                        machine.removeTask(task, current_time)
                        machine.runningTasks.remove(task)
                        print "delete task", current_time, task.arrival_time, task.placement_time, task.duration, task.cpu, task.mem, "on machine", task.hostMachine

        for machine in self.cluster:
            if machine.beingUtilized:
                if not machine.runningTasks:
                    machine.beingUtilized = False

        for machine in self.cluster:
            if machine.beingUtilized:
                machine_empty = False

        return machine_empty

    def VMplacement(self):
        # self.clearResults()  # clear results directory

        start_time = time.time()
        time.asctime(time.localtime(time.time()))  # 年月日，时分秒
        current_time = 0
        print(start_time)
        return


    # unplaced_tasks = self.tasks[:]
    # backlogged_tasks = []
    #
    # firstFailureAlready = False
    #
    # self.update_ratio()
    #
    # while unplaced_tasks:
    #     machine_empty = self.updateMachines(current_time)
    #     enough_resource = True
    #     task_end_time = 0  # store the latest task coming time
    #
    #     while unplaced_tasks:
    #         if unplaced_tasks[0].arrival_time > task_end_time:
    #             task_end_time = unplaced_tasks[0].arrival_time
    #         if unplaced_tasks[0].arrival_time <= current_time:
    #             backlogged_tasks.append(unplaced_tasks.pop(0))
    #         else:
    #             break
    #
    #     if backlogged_tasks:
    #         for task in backlogged_tasks:
    #             # PM = self.find_best_PM_blw_ratio(task)
    #             # if PM is not None:
    #             #     self.place_task(task, PM, current_time)
    #             #     continue
    #             PM = self.find_best_PM(task)
    #             if PM is not None:
    #                 self.place_task(task, PM, current_time)
    #
    #     else:
    #         if current_time % 1 == 0 or (len(unplaced_tasks) == 0):
    #             self.getResults(current_time)
    #         current_time += 1
    #         continue
    #
    #     for task in backlogged_tasks:
    #         if task.hostMachine == None:
    #             unplaced_tasks.append(task)
    #             enough_resource = False
    #
    #     backlogged_tasks = []
    #
    #     if not enough_resource:
    #         print "Multi-Resource Packing: not enough resource for all tasks, time", current_time
    #         unplaced_tasks.sort(key=getKey, reverse=False)
    #         if not firstFailureAlready:
    #             self.getFirstFailureResult()  # First Failure Utilization Check
    #             firstFailureAlready = True
    #
    #     if current_time % 10 == 0 or (len(unplaced_tasks) == 0):
    #         self.getResults(current_time)
    #     current_time += 1
    #
    #     # if enough_resource and not unplaced_tasks:           #VM placement finished
    #     # if not enough_resource:
    #     if current_time > task_end_time:
    #         end_time = time.time()
    #         print end_time
    #         self.getTimeResult(float(end_time - start_time))
    #         break
    #
    # self.getResourceFragmentation()
    # self.getFailureNum()
    def test1(self):
        aft_k = [[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]]  # resource used after placement in kth cycle
        RELEASE_LIST = []
        REQUEST_LIST = []
        REL_CHANGE_P = [0, 0, 0, 0, 0, 0, 0, 0]
        REQ_CHANGE_P = [0, 0, 0, 0, 0, 0, 0, 0]
        for i in range(400):  # make first few cycle predicable
            RELEASE_LIST.append([[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]])
            REQUEST_LIST.append([[0.0,0.0],[0.0,0.0],[0.0,0.0],[0.0,0.0]])
        Rr_list=[]
        On_rplist=[]
        # rrList=Data_pb2.ResourceRequestListProto()
        for i in range(10):  # 6 days = 8640 min = 1728 5min
            resourceSpecificationList = self.getResourceSpecfication()
            # print("resourceSpecificationList", resourceSpecificationList)
            requestSpecificationList = self.getRequestSpecfication()
            # print(" requestSpecificationList",requestSpecificationList)
            on_rp= self.getRunningResourceProviders()
            # print("on_rp",on_rp)
            on_rplist = on_rp.SerializeToString()
            On_rplist.append([int(s) for s in re.findall(r'\b\d+\b', on_rplist)])
            print("On_rplist", On_rplist)
            vmListDit = self.getvmLists(on_rp)  # { 'id0':[vm1,vm2,...], 'id1':[vm3,vm4,...], ...  } notice it is vm instance  not vm_id
            print("vmListDit",vmListDit)
           # resource used before placement in kth cycle
            bfo_k = self.TotalResUsed(On_rplist, resourceSpecificationList)  # AB[resource1, resource2], Ab[,], aB[,], ab[,]
            # print(" bfo_k",bfo_k)
           # resource remained before placement in kth cycle
            remain_k=self.TotalResRem(On_rplist, resourceSpecificationList)
            # print("rem_k",remain_k)
            delta_t= self.listMinus(remain_k, bfo_k)
            # print("delta_t",delta_t)
            rrList=self.getMission(39+20*i)#
            rrlist = rrList.SerializeToString()
            Rr_list.append([int(s) for s in re.findall(r'\b\d+\b', rrlist)])
            print("rrList",Rr_list[i])
            total = self.listPlus(bfo_k,  remain_k)
            uslization = self.listMultiply(bfo_k, total)
            # print("total", total)
            # print("uslization",uslization)
            # first placement
            self.firstPlacement(Rr_list[i],on_rp, requestSpecificationList, vmListDit)
if __name__=="__main__":
    c = Allocation()

    c.VMplacement()

