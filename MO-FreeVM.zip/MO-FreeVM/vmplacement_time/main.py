
def getClusterFromFile(filename):  # This method reads the "machines" from the given file and output a "cluster"
    cluster = []  # that is a list which includes all information of these machines

    with open(filename, 'r') as f:
        for line in f:
            config = line.strip('\n').split('\t')

            print(config[1])

            # cpu = float(config[1])
            # mem = float(config[2])
            # # cpu = 40
            # # mem = 128
            # # m = Machine(machineID, cpu, mem)
            # cluster.append(cpu)
    # return cluster
    return config
if __name__=="__main__":
    cluster = getClusterFromFile("D:\\TOSC\\google_dataset\\machine.csv")
    print("main")

